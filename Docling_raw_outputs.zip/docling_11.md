Accession #:D987654-25

<!-- image -->

MidwestHeart&amp;Vascular Institute 300CardiovascularCircle Lincolnwood,IL60712

Phone:(312)555-8000

Fax:(312)555-8001

Patient:Robert Chen

DOB:03/12/1948

MRN:135792

Gender:Male

Referring Physician:Dr.Angela

Patel

Visit#:246-810DateofVisit:06/20/2025

## TransthoracicEchocardiogramReport

Procedure:Complete transthoracicechocardiogram(TTE)with 2D,M-mode,and Doppler interrogation.

Clinical Indication:Hypertension,evaluationof leftventricularfunction and diastolic dysfunction.

LeftVentricle:The leftventricle isnormalin size.There is concentricleftventricularhypertrophy.The estimated leftventricularejectionfraction(LVEF) is50-55%.There is Gradell diastolicdysfunction.No regional wall motion abnormalitiesarenoted.

RightVentricle:Therightventricle isnormal in size and systolicfunction.

Valves:The aortic valve is mildly calcified with mild stenosis.Themitral valve shows age-related normal.

Pericardium:Nopericardialeffusion is seen.

Impression:

Preserved left ventricular ejection fraction (50-55%). Concentric left ventricular hypertrophy.

Grade ll diastolic dysfunction.Mild aorticstenosis.

## Scheduled appointments:

A follow-up appointment is scheduled with the referring cardiologist,Dr.Patel,on07/11/2025 to discuss these findings and medication management.

Date ofDictation:06/20/2025

Sonographer:Emily Carter,RDCS

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotected byfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom it isaddressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction takeninrelianceon thecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceived this reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704