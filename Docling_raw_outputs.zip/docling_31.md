<!-- image -->

## Chief Complaints:

DateofVisit:06/21/2025

AttendingProvider:Dr.SarahJenkins,MD

Location:Orthopedic&amp;SportsMedicineCenter

VisitID:ENC-A4B3C2D1

## Dateof Birth:10/30/1952Age:72Sex:Male Address:789 Pine Lane,Lincolnwood,USA54321

## Medical HistorySnapshot:

- Worseningchronicrightkneepain

PrimaryDiagnosis:Severe tricompartmentalosteoarthritisof therightknee

- Difficulty walking and climbing stairs

OtherChronicConditions:Type2DiabetesMellitus,

- Morning stiffness

Hypertension,CoronaryArteryDisease

- Discussion ofsurgical options

Surgical History:Coronaryarterystentplacement(2018),

LaparoscopicCholecystectomy(2005)

Medications:Metformin1000mgdaily,Lisinopril20mgdaily,

Atorvastatin40mgdaily,Aspirin81mgdaily

Allergies:Codeine(nausea andvomiting)

## VisitSummary:

activity.Thepainsignificantlyimpactshismobility,limitinghisabilitytowalkmorethanasingleblock, includingacourseofphysicaltherapyand acorticosteroid injectionadministered8monthsprior. Recent kneeX-raysconfirm severe medial and patellofemoral joint space narrowing.After a thorough discussionoftherisks,benefits,andalternatives,thepatientexpressedaclearunderstandingand desiretoproceedwith surgical intervention.Hehasbeen scheduled fora righttotal knee arthroplasty andreferredforpre-operativemedicalandcardiacclearance.

## Exams:

Vitals,Cardiovascular,Musculoskeletal-RightKnee,Gait&amp;Station

## Findings:

Vitals:BP134/78 mmHg,Pulse72bpm,RR16,Temp98.4°F.

Cardiovascular:Regularrateandrhythm.Distalpulses arestrongandequalinboth lowerextremities.

## Musculoskeletal-RightKnee:

Inspection:A mild effusion ispresent.A notablevarusdeformityisobserved.Noerythemaorwarmth.

Palpation:Palpable crepituswith anyflexion orextension.Point tenderness overthemedialjoint line.

RangeofMotion:Limited activerangeofmotionfrom5to110degreesdue topain.

leg.Heis unable toperform afull squat.