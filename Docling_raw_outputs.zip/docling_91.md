PatientName:CynthiaM.WrightMRN:16180339

<!-- image -->

bloated or have gas pains. walking

<!-- image -->

## Impressions:

by the appendiceal oriliceShe boukl preparalionwasadeauate 00

pyoraywoyamprobnmohmronpo hownofypomngybnropmnoophbla Auoid alcoholic beverades Por 24 hours.

Fgllow-Up: Since this screening examination was normal. your next routine colonoscopy is due in 10 gears. No biopsies were taken.

Warning Signs:Please contact our llice lor non-Brgeptguestions. Goto the nearest-emergency room f youdevelopsevere abdominalpain.aRverbverTO/.chls.orsighilicart-rectal bleeding.

<!-- image -->

This document contains confidentialpatientinformationprotected underapplicableprivacy laws, includingthe Health InsurancePortabilityandAccountabilityAct(HiPAA).

MapleValleyDigestiveHealthClinic 55GreenMountainWayBurlington,VT

05401

Phone:(802)555-6789

Fax:(802)555-6790

ProcedureDate:June21,2025

(a) Normal Colon

<!-- image -->

(b) Colon

<!-- image -->