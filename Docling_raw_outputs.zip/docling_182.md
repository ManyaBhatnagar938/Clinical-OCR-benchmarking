Date:04/18/2026

Patient:Liam C.Thompson

TherapistNames:Mr.Marcus Hall,RBT/Ms.RachelTorres, BCBA

## DAILY REPORT

- [ ] Anxious Calm/Content Frustrated

- [x] Cup

- [ ] AngryCheerful/HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

Came With

- [x] Jacket

- [ ] Loving

- [x] Lunch Box

- [ ] other

## AGGRESSION

STEMMING

NONCOMPLIANCE

OTHER

- [ ] Hitting

- [ ] Thumb Sucking

- [ ] Non Compliance

- [x] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate Touching

- [x] Throwing

- [ ] Flopping

- [ ] Hand Flapping

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [x] Repeating

- [x] Climbing

- [ ] Preservative Manding

- [ ] Pinching

- [x] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] InappropriateDance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Liam ateenthusiasticallyandfinished all food items.Required 2redirectionsfor climbingon chair duringlunch.Acceptedredirectionwithoutescalation.

## ICH

Targets Hit During Lunch:

Manding for items (+5/5).Tact labels (+4/5). Waiting 30 seconds for reinforcer(+3/5—improving from last week).

Today'sStruggles and Strengths:

GROUP CIAL S

High energy throughout thesession-required frequent movementbreaksbetween tasks.Strength: improved turn-takingduringboardgameactivity(+3/3trials).