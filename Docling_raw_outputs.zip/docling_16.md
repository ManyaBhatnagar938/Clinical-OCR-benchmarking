PatientName:JohnSmithMRN:7890123

<!-- image -->

## Grand CityGeneral Hospital

123MainStreetMetropolis,USA 12345Phone:(555)123-4567

Fax:(555)123-4568

AccessionNumber:P2025-54321

DateofCollection:06/18/2025

TimeofCollection:10:30AM

Specimen Type: Colon Biopsy

## Final Diagnosis:

Colon,sigmoid:Adenocarcinoma,moderatelydifferentiated

## Microscopic Description:

Thesections showfragmentsofcolonicmucosawith invasiveglands lined bypleomorphiccolumnar epithelial cellswithhyperchromatic,elongated nuclei andprominentnucleoli.Theglands exhibita cribriform and fusedglandulararchitecture,invadingthe submucosa.Thereisamoderate desmoplasticstromal response.High-grade dysplasiaisnoted in the adjacentflatmucosa.No lymphovascularinvasionisidentified inthesubmittedmaterial.

## Gross Description:

Received fresh,labeled withpatient'sname and"sigmoid colonbiopsy,"aretwopiecesoftan-pink tissue,eachmeasuring0.3cmingreatest dimension.The specimens aresubmitted entirelyin one cassette.

## Comments:

The findings are consistent with an invasive adenocarcinoma.Correlation with imaging studies and clinicalcontext.

## Biomarkers:

MismatchRepair(MMR)ProteinImmunohistochemistry:

- MLH1:Intactnuclearexpression

- MSH2:Intactnuclearexpression

- MSH6:Intactnuclearexpression

- PMS2:Intactnuclearexpression

- Interpretation:Proficient MismatchRepair(pMMR)phenotype.Thisresultsuggestsa lowprobability of Lynch syndrome.

## PATHOLOGYREPORT

831676002937

<!-- image -->

Date of Birth: 05/20/1968

Age:57

Gender:Male

Patient Address: 456 Oak Avenue,

Metropolis,USA12345

OrderingPhysician:Dr.Elizabeth

Warren,MD

Practice:Downtown

Gastroenterology Clinic

Address:789RiverRoad,

Metropolis,USA12345

Phone:(555)987-6543