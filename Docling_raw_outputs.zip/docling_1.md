<!-- image -->

## Lakewood Hospital-Departmentof Anatomic&amp;ClinicalPathology

## PATHOLOGYREPORT

831676002937

<!-- image -->

Patient Name:Peterson,MarkAlan

DateofBirth:March22,1965

MedicalRecordNumber:LH45-67-

89X

Gender:Male

PatientAddress:345MountainView

Ave,Lakewood,CO,80215

9000ForestPineRoad,Lakewood,CO, 80210LaboratoryDirectLine:(303)555- 0100|PathologyFax:(303)555-0102CLIA Number:05D1234567|CAPAccreditation No:8005001

OrderingPhysician:Dr.Sarah

AccessionNumber:LHP-25-78901

Jennings,MD,FAAD

Date Collected:May19,2025

Clinic/Location:Lakewood

TimeCollected:02:15PM

DermatologyCenter

DateReceived:May19,2025

Address:875ProfessionalPark

TimeReceived:03:00PM

Drive,Suite200,Lakewood,CO, 80210

DateReported:May21,2025

TimeReported:12:15PM

Physician Phone:(303)555-0250

SpecimenType:PunchBiopsy,Skin-RightUpperBack

PhysicianNPl:9876543210

## Diagnosis:

WITHSEVEREARCHITECTURALDISORDERANDSEVERECYTOLOGICATYPIA.THEATYPICAL

## Comments:

Thefindings are thoseof aseverely dysplastic nevus.Given thedegree of atypia and the involvement of marginsinthispunchbiopsyspecimen,completere-excisionwithclearmargins（typically5mmoras excision isperformed,submissionof theentirespecimenforhistologicevaluationisadvised.

## Biomarkers:

Immunohistochemical Stains:

- Melan-A(MART-1):Highlights the atypical melanocyticproliferation,confirmingmelanocytic lineage.
- Sox1o:Strongnuclearpositivityinatypicalmelanocytes.
- PRAME:Diffuselypositivewithintheatypical melanocyticproliferation(reportedinapproximately 30-40%ofseverely dysplastic nevi andmelanomas).
- HMB-45:Patchypositivitywithin thejunctional component.
- Ki-67:Proliferationindexisfocallyelevated,upto8-10%inareasofgreatestatypia.

maybeconsideredonsubsequent specimensif featuressuspiciousformelanoma areidentified.