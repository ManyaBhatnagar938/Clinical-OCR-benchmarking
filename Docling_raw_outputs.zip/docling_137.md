<!-- image -->

April1,2026

| SECTION A:Medical History  Yes  No  Congestive HeartFailure(ICD-10:150.9)  AtrialFibrillation(ICD-10:148.91)  X  COPD,Moderate(ICD-10:J44.1)  X  Type2DiabetesMellitus(ICD-10:E11.9)  X  Benign ProstaticHyperplasia (ICD-10:N40.0)  X  Depression(ICD-10:F32.9)  X  CKDStage2(ICD-10:N18.2)  X   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  Warfarin5mg—oncedaily(PM)  X  Digoxin 0.125mg—once daily(AM)  X  Furosemide80mg-oncedaily(AM)  X  Spironolactone25mg-oncedaily  X  Tiotropiuminhaler18mcg-oncedaily  X  Tamsulosin0.4mg-oncedaily  X   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Robert Nakamura

RobertNakamura

Patientsignature

Printname

<!-- image -->

Patient:Robert T.

Nakamura

DOB:11/05/1945

MRN:012-501-88