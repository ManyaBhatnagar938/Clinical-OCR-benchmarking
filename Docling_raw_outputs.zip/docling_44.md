<!-- image -->

## 831676002937

<!-- image -->

| PatientName:JohnathanSmith  OrderingPhysician:Dr.David  DateofBirth:04/12/1971  Chen  MRN:345123  Procedure:  Accession #:SP-25-45678  Esophagogastroduodenoscopy (EGD)withbiopsy  DateofProcedure:06/23/2025  DateofReport:06/25/2025   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Clinical History:54-year-oldmalewith a historyof chronicdyspepsia and epigastricpain.Biopsies takento evaluateforgastritisandruleoutHelicobacterpyloriinfection.

Gross Description:Received in formalin,labeled"gastric antrum"are three tan mucosal fragments,

Diagnosis:GastricAntrum,Biopsy:Mild chronicgastritis,positive for Helicobacterpylori.

MicroscopicDescription:Sections show fragments of gastric antral mucosa.The laminapropria contains a mild increase in chronic inflammatory cells,includinglymphocytes andplasma cells.No significantneutrophilicactivity,intestinalmetaplasia,dysplasia,ormalignancyisidentified.Aspecial stainfororganismshighlightsnumerousspiral-shapedbacteria on thesurfaceofthefoveolar epithelium,morphologicallyconsistentwithHelicobacterpylori.

Helicobacterpylori.

Specimen:Gastric antrum

Pathologist:Dr.Emily Carter

biopsy

Report status:Final