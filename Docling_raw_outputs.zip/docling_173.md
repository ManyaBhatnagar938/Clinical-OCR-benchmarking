Name:Sandra K.Okafor

Age:45

Attend Dr:Dr.Diana Mensah

Acct#:19883-D

Sex:F

Location:Clinic C

Date:02/14/2026

DOB:08/19/1980

SPEC#:S-2026-02-14-019

COLLECTEDTIME:09:00

STATUS:FINAL

ENTERTIME:09:00

REPORTTIME:12:00

REQ#:R-19883

ORDERTIME:08:45

| Test  Result  Flag  Reference  Site  WBC  5.8 x10°/μL  4.5-11.0  CC  REC  3.90 x10/μL  L  4.00-5.20  CC  HGB  10.2g/dL  L  12.0-16.0  CC  HCT  30.8 %  L  36.0-46.0  CC  MCV  78.4fL  L  80.0-100.0  CC  MCH  26.2pg  L  27.0-33.0  CC  MCHC  33.1 g/dL  32.0-36.0  CC  PLT  340x10/μL  150-400  CC   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|