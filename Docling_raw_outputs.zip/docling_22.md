<!-- image -->

You have undergone a colonoscopy,a diagnosticprocedure in whichaflexible,lighted tubewasusedtoexaminetheliningof yourlargeintestine(colon).Thesedationyoureceivedforthe procedurewillcontinueto affectyourjudgmentandcoordination fortherestoftheday.Foryoursafety,itisessentialthatyou carefullyfollowtheseinstructions.

## ImmediatePost-Procedure Care

Transportation:You mustbe discharged into the careofa responsible adultwhowill driveyou home.You are notpermitted todrive,takeataxiorridesharealone,orusepublic transportationby yourself.

DietaryGuidelines

## GastroenterologyAssociatesofNorth America

123HealthDriveSpringfield,IL62704

Phone:(217)555-1212

Fax:(217)555-1213

(a) Normal Colon

<!-- image -->

Restand Supervision:Aresponsible adultmuststaywithyoufor theremainderofthedayandnight.Itisimportanttorestathome fortherestof today.

Beginbydrinkingclearliquids(such aswater,applejuice,ginger ale,orbroth)onceyouarehome.

Ifyoutolerateclearliquidswell,youmayadvancetoalightmeal a fewhours later.Good choices includesoup,toast,crackers,or yogurt.

## Impressions:

Normal Colonoscopy:The entire colon,from the cecum to therectum,wasvisualized and appeared normal.Therewere nopolyps,masses,diverticula,orevidence of inflammation.

Activity: You may feel tired and bloated for the rest of the day. It is important to rest. Do not drive, operate machinery,ormake anyimportantdecisionsforat least24hours.Youmust have a responsibleadultstaywithyoufortheremainderoftheday.You mayresumenormalactivities tomorrow.

Diet:You may resume your normal diet as tolerated.Start with clear liquids and light foods (e.g.,soup, gelatin,crackers)and advancetoaregulardiet ifyou arenotexperiencingnausea orsignificant bloating.Avoid heavy,greasy,orspicy foodsforthe first 24hours.

Follow-up:Based on thenormal findingsofyourcolonoscopy,yournextroutinescreening colonoscopyis recommended in10 years.Wewill send a remindertoyou at that time.lIf you experienceanysevereabdominalpain,persistentnauseaorvomiting,fever,orsignificantrectal bleeding,please contact our office immediately orgo to the nearest emergency room.

This document contains confidential patient informationprotected under applicableprivacy laws, includingtheHealthInsurancePortability and AccountabilityAct(HiPAA).

(b) Colon

<!-- image -->