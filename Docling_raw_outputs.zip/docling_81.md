PatientName:EmilyWhiteMRN:9876543

<!-- image -->

<!-- image -->

<!-- image -->

LAKEWOOD

DateofBirth:/30/1155

## PATHOLOGYREPORT

HOSPITAL

Age:67

831676002937

Gender:

## Coastal Medical Center

456OceanViewDriveSeaside, USA54321

PatientAddress:787

Phone:(555)234-5678

Fax:(555)234-5679

54321

Ordering Physician:

Accession Number:

22025-67810

Date of Collection:

06/20/2025

Practico:

Time of Collection:

0700AN

Specimen Type:

Riskk

Address:

Phone (555)

Final Diagnosis:

ntinkeel

## MicroscopicDescription:

boidL 0.5

## Gross Description:

Raxnix N55×32 mtrrr? 0.8

Comments:

with

N729

grnMainfirn 20, Rog Bene

- nrost

<!-- image -->

<!-- image -->

<!-- image -->