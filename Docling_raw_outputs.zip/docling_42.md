PalmCountyGeneralHospital7750HealthDrive,Miami,FL33139Phone:(305)555-6000

## Chief Complaint

Patient:MarkShapiroMRN:889900DOB:06/15/1999

Itchy,redrash onboth legs and arms,progressivelyworsening over the last three days.

## Care Team

Attending Physician:Dr.Angela Rossi,MD Pager:(305) 555-6020

## Pharmacies

PublixPharmacy1900WestAve,MiamiBeach,FL33139Phone:(305)555-1500

T:99.4F

HR:80bpm

BP:128/80mmHg

RR:16breaths/min

02Sat:99%onro0mair

## Vital sign

## Allergies

AdhesiveTape-ContactDermatitis

## Medications

- Hydrocortisone1% cream,applied twice dailyfor 2 days.

## Vaccines

- Tdap-08/01/2023
- Allotherimmunizationsuptodate.

## Problems

- Pruritic Rash
- Historyofseasonal allergies

## FamilyHistory

Mother:Historyofeczema.

Father:Healthy.

Tobacco:Denies

Alcohol:Socially

Occupation: Landscaper.Reportshiking in a wooded area four days ago.

## Social History