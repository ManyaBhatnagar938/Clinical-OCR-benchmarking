<!-- image -->

m@01

Facility:atutMa

Fax: (555)800-9000

Phone:(555)800-9001

Re:BRGOn

From: So Han. Fp-

Facility:deFulyu

Fax: (555) 400-5000

Phone:(555)400-5001

Date: Zm 25. 2025

Time: 1130Am

Pages: /(l-dog we)

Notes:

SetCltpVollT2t

4G01011611965

HttChiA1981u4nuGlC

<!-- image -->

Theinformationcontainedinthisfacsimilemessageislegallyprivileged and confidentialinformationintendedonlyfortheuseof theindividualorentitynamed above.lfthereaderofthismessageisnottheintendedrecipient,youarehereby prohibited.lfyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus bytelephone andreturn theoriginalmessage tous at theaddress abovevia the U.s. PostalService.Thankyou.

<!-- image -->

## FAX