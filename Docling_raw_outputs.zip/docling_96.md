<!-- image -->

<!-- image -->

DateofVisit:o/2//2025

Attending Provider:t. M

Location:

tDuy

VtIP:nCo-ak

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

HOSPITAL

Date ofBirth:of/12//227

Age:26

Sex:F

Address:10//Ss38765

## ChiefComplaints:

## Medical HistorySnapshot:

- Mt mtttos

Solfftry Calatitrotut (2015)

FfaMt

- ttot

## VisitSummary:

2 Fossicn p ottPRoTotatlttplftttt Sy olltittt 8t Syetttoft

## Exams:

## Findings:

pp

HSS:Jnhclatte