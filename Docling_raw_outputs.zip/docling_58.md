<!-- image -->

To: Dr.Samantha Powell,Dermatology

Facility:Skin Health Specialists,LLC

Fax: (555) 999-8888

Phone:(555) 999-8877

Re:Evaluation of Lesion:MILLER,Robert

From:Dr.James Finch, PA-C

Facility: Bayview Community Health

Fax:(555) 111-2233

Phone:(555) 111-2244

Date:June 25, 2025

Time:11:26 AM

Pages:1 (including cover)

## Notes:

Subject:Urgent Referral for Suspicious Nevus

Dear Dr.Powell,

Iam referring my patient,Robert Mi1ler（D0B:03/12/1971),for evaluation of a changing nevus.

He presents with a 7mm,dark，irregularly bordered lesion on his left scapula thathereportshasgrown overthepast3months.Iam concerned aboutthepossibility ofmelanoma and would appreciateyour urgent assessment for a potential biopsy.

Thank you.

The information contained in this facsimilemessage is legally privileged and confidentialinformationintended onlyfortheuseof theindividualorentitynamed above.lf thereader of this message is not theintended recipient,you are hereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.lf you havereceived thistelecopyinerror,please immediatelynotifyus by telephone and return theoriginal message to us atthe address abovevia theU.s. Postal Service.Thankyou.

<!-- image -->

## FAX