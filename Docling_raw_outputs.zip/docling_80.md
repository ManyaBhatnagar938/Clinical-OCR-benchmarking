PatientName:JohnSmithMRN:7890123

<!-- image -->

LAKEWOOD

## PATHOLOGYREPORT

HOSPITAL

DateofBirth:05/20/7968

831676002937

Age: 2Z

Gender:

Mdle

## Grand CityGeneral Hospital

Patient Address: 456 Dok Arerwe

123MainStreetMetropolis,USA

Meorolis.9S412245

12345Phone:(555)123-4567

Fax:(555)123-4568

OrderingPhysician:

Dr.Sk2cke Warer,9mD

Accession Number:

P2025-54321

Practice: Zeuieut

Date ofCollection:

0611812025

Gestceiledeen Ckirio

Time of Collection:

10:20A9M.

Address:Z89 Riue, Recd

Specimen Type:

Coler Tiersy

meterekis.9S419245

Phone:[555]98f-6543

## Final Diagnosis:

Coler,sigroi: Aderecorcirero, rederele dlfereriofed

## Microscopic Description:

Te secfiors show frognerls ef celoric rucose uafh irtegite glerds bred br plemephic coluuror epillelol cels uafh bsperchrenolie,elergoted rvclei ord prenireif ruvclelk.Te glorods exliki a cribriforn crd fused Jlerdule archafeefune,ircdingHle sukrvcose.Tere is a roderate desmoplostic Tronol sesponse.Higrercde dssylosic is

## Gross Description:

Received bresh,lokeled uafhpofiert's rone ordsieyncid colen kiepss,areTuo pieces elonpiof Tissue,eoch neosuirg OB cn in Jreolee dinensier,Te syecinerg are suknied efirel ir ore cosselle.

## Comments:

Te firdires ore cersistert uafh on irosite cderecorcireno,Corelopien uafh inoging Sfuoies ord chricol fiurdiungs is reconnerded bordefiriiceaging.Fustlerroregeneif slould keguidedbrTe chiricolcoiexl.

## Biomarkers:

Misroteh Repeinr InMSR)Pefeun onuueisteclenists:

MHl:gfoefvcleerexpression MSgt2:foetrvcleer expressien MSHtb:gfoefwcleorexpressien PMS: gtoetrvcleerexpressior

fepretafion:Peficieit9misrolekReein(9m9msR)pheretrre.TisesuisuggeslseleuprobcbitIrch srorene.

<!-- image -->