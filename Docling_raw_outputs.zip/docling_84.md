<!-- image -->

<!-- image -->

<!-- image -->

PatientName:BrendaJohnsonMRN:5551234

LAKEWOOD

## PATHOLOGYREPORT

DateofBirth:O/22/

HOSPITAL

831676002937

Age:y5

## MidwestRegional Hospital

Gender:eve

1000HealthWaySpringfield,IL 62704

Patient Address: a

Phone: (217) 555-1000

Sge0

Fax:(217)555-1001

OrderingPhysician:d

AccessionNumber:258l5

DateofCollection:Q/20/2025

Practice md Qwsoog

TimeofCollection:Qi15om

Address:500m

Uewpd apaU agpol :od uowoods

Sgen o

Phone:21055535

## Final Diagnosis:

tegoid ngt Rode. ne

## MicroscopicDescription:

saaapspsayssaucapsaa Riso notede baehgond is Cean

## GrossDescription:

## Comments:

e papuannoa

Biomarkers:

bawooe mtaon arsisaste

epettn abomsgstdnrst therapeute oplecations.