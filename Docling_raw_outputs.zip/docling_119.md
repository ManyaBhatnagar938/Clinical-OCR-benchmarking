<!-- image -->

## NorthviewEye&amp;VisionCenter

1400 MountainPass Rd. Denver,CO80202

(303)555-1234

PatientName:

MRN:5

MRN:

Accession:s-

DOB:5/1/951

Date:/s/s

Gender:

Age:

Rtlt

fatTopODuafhOsuaf

## IMPRESSION:

<!-- image -->

<!-- image -->

Patient Name:Susan Miller MRN:5592381Age:67

Electronically Signed By:Dr.KevinPeterson,M.D.(Ophthalmology)

Date:06/23/2025Time:09:12