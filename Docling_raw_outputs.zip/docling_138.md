<!-- image -->

February14,2026

| SECTION A:Medical History  Yes  No  SystemicLupusErythematosus(ICD-10:M32.9)  X  Hypertension(ICD-10:110)  X  IronDeficiencyAnemia(ICD-10:D50.9)  X  Raynaud Syndrome(ICD-10:173.00)  X  LupusNephritis ClassIll(ICD-10:N08)  X   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:CurrentMedication  Yes  No  Hydroxychloroquine400mg-oncedaily  X  Prednisone5mg-oncedaily(AM)  X  Amlodipine5mg-oncedaily  X  FerrousSulfate325mg-everyotherday  X  Belimumab200mgSC-onceweekly  X  Mycophenolatemofetil1oo0mg-twicedaily  X  Losartan50mg—oncedaily   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Sandra Okafor

Patientsignature

Printname

<!-- image -->

Patient:SandraK.Okafor

DOB:08/19/1980

MRN:019-883-12