<!-- image -->

<!-- image -->

| PatientName:uaanWalke  OrderingPhysician:  DateofBirth:05/20/1980  Dr.JameaQ'Cennele  MRN:890123  Procedure:wetraaownd-gided  Accession#:Cy-25-77890  Fine-Needle Aapinatien(3NA)  DateofProcedure:O6/23/2025  JhyrsidNodule  DateofReport:06/25/2025   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

clinical History: 45-year-old Pemale witk a 2.5 cm solid, Rypoechoic nodwle intherightealeoethethyraid,diacaveredenuetrasownd.

Diagnosis: Jhyroid,RigRttake,Fine-Needle Aapiratien: BwapiciawaRor Malignancy (Betheada Category V).

Specimen Adequacy: Jhespecimen ia adequateRer evaluatien. Microscopic Description: Jhe aapirate is cellular and shows Crowded clwsters  pallicwlar cells with a microfellicwlar architectwe. The cellaexkieitnucleanenlargement,chrematinpaller,andiegula rclearcentewe.Qccasienalrucleargaeveeandraeintranuclear cytaplaemicpseudeinclwsiene areidentiied.Cellaidisscantinthe background.JheReatwres areRigheysuapiciousRarPapillanyJhyraid

Comment: The cytemorphelegic Reatwes are swapiciaws Rer papillany thyraidcarcinema.PertheBetheadaByatemRerRepartingJhyraid Cytepathelogy,augicaeexciaieniarecemmendedRerdeinitive

Specimen:Fine-Needle

Aapiratien(FNA)o

rightthyroidnadule

Report status: Final

Pathologist:

Dr.KatherineReed