PatientName:Doe,JanePatientID:JG05141985DOB:05/14/1985DateofService:2024-05-18

Accession#:IMG9876543OrderingPhysician:Dr.EmilyCarterReportDate:2024-05-20

<!-- image -->

SpringfieldGeneralHospital ImagingDepartment123Health Way, Springfield, IL, 62704

Phone:(217)555-1212

Fax:(217)555-1213

VisitDate:2024-05-18Reason forExam:Persistent headaches,right-sided,worseningover2 Weeks.ExamID:IMG9876543

## Imaging

## MRIBrainwithoutcontrast

Technique:Multiplanar,multisequencemagneticresonance imagingof thebrainwasperformed without the administrationof intravenous contrast.SequencesincludeT1-weighted,T2-weighted, FLAiR,anddiffusion-weightedimages.

Findings:Theventricularsystem and sulci are normal in size and configurationforthe patient's age.No evidenceofacuteintracranialhemorrhage,masseffect,ormidlineshift.Grey-whitematter differentiation ispreserved.Noacuteterritorialinfarctidentified ondiffusion-weighted imaging.The major dural venous sinuses appearpatent.Visualized portions of the orbits and paranasal sinuses are unremarkable.Thecraniocervicaljunctionisunremarkable.

Impression:NormalMRl studyofthebrain.Noacuteintracranialabnormalityidentified.

## Scheduled appointments:

Follow-up consultation with Dr.Carter on2025-06-01 at 10:00AM to discuss results and further managementofheadaches.

DateReported:2025-05-20

InterpretingRadiologist:Dr.AlanB.Smith,MD,DABRTranscriptionistID:KLP

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom itis addressed.lfyou are not thentendedrecipient,you areherebynotified that anydisclosure,copying,distribution,oraction takeninrelianceonthecontentsof thesedocumentsisstrictlyprohibited.lfyouhavereceived this reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704

PatientName:Doe,Jane Patient

ID:JG05141985

DOB:05/14/1985

Sex:Female