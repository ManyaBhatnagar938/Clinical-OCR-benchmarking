<!-- image -->

HOSPITAL

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  David P.Kowalski  02/07/1962  MRN-023417  Gender:[X]M[]F[]Other  Phone Number:  Today's Date:  (346)555-0617  03/25/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(oF)  SpO2(%)  Weight(lb)  Height(in)  136/82  66  14  98.0  98  185  71   |
|-------------------------------------------------------------------------------------------------------------------------------|

| Medical History  [X]Hypertension  []Diabetes(Typel)  [X]Diabetes(TypelIl)  []Asthma  []COPD  [X]Heart Disease  [X]High Cholesterol  []ThyroidDisorder  []Arthritis  []Cancer  []Depression/Anxiety  [Other:   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  MetoprololSuccinate  50mg  Oncedaily  Aspirin EC  81mg  Once daily  Empagliflozin  10mg  Oncedaily  Rosuvastatin  20mg  Once daily (PM)   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Contrastdye  Anaphylaxis-requirespre-medication   |
|---------------------------------------------------------------------------------------|

| ## Reason for Visit  Post-Ml6-monthfollow-up.Cardiac stress testreviewed.Patientreportsgood exercise tolerance andno angina symptoms.   |
|-----------------------------------------------------------------------------------------------------------------------------------------|

Provider Signature: Kevin Q. Qaei

Date: 03/25/2026