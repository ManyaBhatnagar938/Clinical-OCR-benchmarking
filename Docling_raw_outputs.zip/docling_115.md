<!-- image -->

## Advanced ImagingAssociates

789InnovationWay Phoenix,AZ85004 (602) 555-7890

PatientName: BWuh

MRN:1032547

MRN:1032547

Accession\_R44091-25

DOB: 03/21/1951

Date: 06/23/2025

Gender Fal

Age:Z4

Thelastserene

S

onchanbing

PRCEBUAES

MRRffKfcff

SerereTfouomgnfacafloftoaftnpfe

CmglagefrefarfaposrhornfThemeaeee

Medafeadmfeffn

Nueem Lgamen

<!-- image -->

Patient Name:Brenda WalkerMRN:1032547Age:74

Electronically Signed By:Dr.SamuelJones,M.D.(Radiology)