<!-- image -->

<!-- image -->

<!-- image -->

PatientName:RobertBrownMRN:6543210

LAKEWOOD

## PATHOLOGYREPORT

HOSPITAL

831676002937

DateofBirth:03/12/1950

Age: 75

## NorthStarHealthSystem

Gender:Male

450Northland BlvdAurora,CO 80011

Patient Address:567 Birch Lane,

Aurora,CO80011

Phone:(303)555-1212Fax:(303)

555-1213

OrderingPhysician:

AccessionNumber:200-0/234

Practice:

DateofCollection:06//9/2025

TimeofCollection:22:45P

Address:8001u//

SpecimenType:

14/

SuiL

202

CO-80012

Phone:(303) 555-8800

## Final Diagnosis:

Prastnte.leftlase:Adenseaieinsmn. Gleasan-Scare4+3=7 (gradeGrsup 3)

## Microscopic Description:

ilttine -farmed erifrifarm slands(gleasanpattern indigidunL diserete slands CGlenssn pottern3). Tkemnlisnant Seands ateeined bycellsuitk enlarged nuelei.prsminentnuclesli. andseant eytsplasmo. PesineutaL intasien isidentifiel.Tketumar inkoloes apprsximntely 60%ofthe tissue

## Gross Description:

Reeeived iw bormnlinlabeled prastate, left tan-ukite ylindrieattissue 7.7 7.4 Cmins lemsthglAeesn tissue Comments: tent uitkserunpSA antglersanpatterny

Carrelatian

Tkefindings

dverse inpasian take. lerelyandcliniealstaging supperting Cee stanng kixk malig Car Biamnrker m naKurther andr63 tertiny

magnastiefactsrs.

mended.