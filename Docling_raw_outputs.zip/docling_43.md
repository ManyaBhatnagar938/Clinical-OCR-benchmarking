<!-- image -->

Patient Name:Maria Garcia

Ordering Physician:Dr.Angela

DateofBirth:11/05/1994

Davis

MRN:456789

Procedure:Colposcopywith

Accession#:C25-34567

cervical biopsy

<!-- image -->

DateofProcedure:06/24/2025

DateofReport:06/25/2025

Clinical History:30-year-old female with an abnormal Pap test result of Low-Grade Squamous IntraepithelialLesion(LSIL)andpositiveforhigh-riskHPV.

GrossDescription:Received informalin,labeled"cervix6o'clock,are two fragments of tan-white mucosaltissue,eachmeasuring approximately0.3cm.Submitted entirelyinonecassette.

Diagnosis:Cervix,6o'clock,Biopsy:High-GradeSquamous Intraepithelial Lesion(CIN 2).

MicroscopicDescription:Sections showsquamousmucosa with marked architectural

disorganization.Thereisaproliferationof atypicalbasaloidcellsextendinginto themiddlethird of the epithelialthickness.These cellsexhibitenlarged,hyperchromaticnucleiwith irregularcontours and a high nuclear-to-cytoplasmicratio.Mitoticfigures arenoted above thebasal layer.Thestromalepithelialjunctioniswell-defined.

Comment:Thefindingsare diagnosticof CiN 2,ahigh-gradesquamous intraepithelial lesion. Correlation with colposcopicfindings and appropriate clinical management is advised.

Specimen:Cervicalbiopsyat6

Pathologist: Dr.Mark Jennings

o'clock

Report status:Final