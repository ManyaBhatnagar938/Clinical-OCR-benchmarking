<!-- image -->

To:Dr. Katherine Liu, Rheumatology

Facility:Arthritis and Autoimmune Center

Fax:(555) 234-5678

Phone:(555) 234-5679

Re:Patient Consult:THOMPSON,Patricia

From:Dr. Mark Johnson, Internal Medicine

Facility: Pineview Medical Associates

Fax:(555) 876-5432

Phone:(555) 876-5431

Date:June 25,2025

Time: 11:34 AM

Pages:1 (including cover)

## Notes:

Subject:New Referral for Suspected Rheumatoid Arthritis

Dear Dr.Liu,

Iamreferring Patricia Thompson（DoB:04/11/1980) to your clinic for evaluationofsuspected new-onset inflammatory arthritis.

She presents with a 3-month history of progressive,symmetrical pain and swelling in her wrists and McP joints,with morning stiffness lasting over an hour.Her initial labs are positive for RF and she has an elevated CRP.

I am sending her to you for definitive diagnosis and to discuss initiation of DMARD therapy.Thankyou.

The information contained in thisfacsimile messageislegally privileged and confidentialinformationintendedonlyfortheuseof theindividualorentitynamed above.lf thereaderof thismessageisnottheintendedrecipient,you arehereby prohibited.lfyouhavereceived thistelecopyinerror,pleaseimmediatelynotifyus by telephone andreturn the original message to us at the address abovevia theU.s. Postal Service.Thank you.

<!-- image -->

## FAX