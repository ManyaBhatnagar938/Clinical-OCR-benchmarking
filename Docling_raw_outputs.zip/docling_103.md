PavilionforWomen&amp;ChildrenatMetroHealth101HealthwayDrive,Denver,CO80204

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Patient: Jnica Culiany

MRN:240810

DOB:0791993

## Chief Complaint

finst trinusterwginalpeattinybnme day

CareTeam

hor3033557811

Pharmacies

KingcmpensDharnay350nmainctDounC80205ome30351234 C

Vital sign

史88 pm

BP1875 mmcHy

RRlo huathy min

c&amp;at qon wn air

Allergies

CrdinNogaVonting

## Medications

- Drunatal/tarinnetafitay mnstrdaily

## Vaccines

- Irflunga11 012024

- Taop01152025

- CVDAVaccinweriycomplita

## Problems

- Intraudenin gwakrgitatnymp

## FamilyHistory

mther

Fhir

itoryokhupthezaidigr

Fatheritorykkupetenin

erishadigerdiry

Social History

BeupatianHfighgehalteachenManridFunwth hustand