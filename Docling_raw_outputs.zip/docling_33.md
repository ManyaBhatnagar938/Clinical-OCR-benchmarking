<!-- image -->

HOSPITAL

## Chief Complaints:

## DateofBirth:07/08/1979Age:45Sex:Male Address:221BBakerStreet,Centerville,USA45459

## Medical HistorySnapshot:

- Follow-upvisitforGeneralized AnxietyDisorder

ActiveProblems:Generalized Anxiety Disorder(GAD),Chronic Insomnia

- Difficultyfallingasleep

Surgical History:None

- Medicationmanagement

FamilyHistory:Fatherwitha historyofdepression.

Medications:Escitalopram10mgdaily,Trazodone50mgat bedtime.

Allergies: Sulfa antibiotics (causes hives).

## VisitSummary:

David is a 45-year-old male herefora 3-month follow-uponhis anxietyand insomnia.Hereports significant improvement in his daytime anxiety since starting Escitalopram,with his GAD-7 score onset insomnia,statingitoftentakeshimmore than anhourtofallasleep.The currentdose of Trazodone helpshimstayasleepbutdoesnotaidwith initiation.We discussed reinforcingstrict sleep hygiene principles. Given the persistent symptoms,a decision was made toincrease hisTrazodone dose to 1oomgatbedtime.Hewill continue hiscurrent dose of Escitalopram.Atelephone check-in is scheduledfor 4weeks to evaluate hisresponse tothe newdosage.

## Exams:

Vitals,Constitutional,Psychiatric, Cardiovascular

## Findings:

Vitals:BP122/74mmHg,Pulse68bpm,RR14.

Constitutional:Well-groomed,well-nourished male in no acute distress.

Psychiatric:Mood is euthymic. Affect is appropriate. Thought process is logical and goal-directed.

Denies suicidal ideation.

Cardiovascular:Regularrate and rhythm,no murmursappreciated.

DateofVisit:06/21/2025

AttendingProvider:Dr.SamuelJones,MD

Location:Northside Family Practice

VisitID:ENC-K2L7M1N