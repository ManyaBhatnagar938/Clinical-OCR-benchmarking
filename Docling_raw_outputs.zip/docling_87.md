<!-- image -->

## Cityside Gastroenterology Clinic

4500MetroParkwayMetropolis,CA 90210Phone:(310)555-4321 Fax:(310)555-4322

(a)NormalColon

<!-- image -->

<!-- image -->

(b)Colon

<!-- image -->

<!-- image -->

Impressions:

D

10 y Follow-Up:Gf

Thisdocumentcontainsconfidentialpatientinformationprotected under applicableprivacylaws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).