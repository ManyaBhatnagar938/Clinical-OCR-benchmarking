<!-- image -->

<!-- image -->

Patient Name: lllhe

OrderingPhysician:

DRketAds

DateofBirth:09/01/1956

MRN:Z89321

Procedure:flfasued-wded

Accession#:SU-25-11223

DateofProcedure:26/20/2025

DateofReport:06/25/2025

## Clinical History:

<!-- image -->

Cop-gear-oll male uitran elevated yrumPSAo 9.2 ng/ml Diagnayy

APaotate RyhtBuriBopryBengopatatetoyue

BPastt RytMdBopsy Alenoeanaromei

BPH) CshowftatamallcuedduttedrudpmincleTTavceol KoedHadGeaonptedpy-fmeddadyGeonptAPeuao dentfud ncoeCNoetapratateectengiony sen

## TumorSummary:

Hethr Tre Aeran Alercanainoma

Gleaonw3+4=7

WHOBUPGadeGou2

Coreg /wolved2f12（17x)

TunovEteatCancerwolvey 30x o corieBand 50x of coreC

PeneunalnwaonPaent

taposttetengionNtdertfud

Specimen:Pfec

biopyuy(12corugbopy

Report status:Final

Accession#:SU-25-11223

Pathologist D/wa Mafuny