NorthwoodCommunityHospital789PineStreet,Northwood,CA90210Phone:(310)555-0101

Patient:MichaelJohnsonMRN:456789D0B:11/22/1995

## Chief Complaint

Severerightlowerquadrantabdominalpain,startedyesterday,associatedwithnausea andfever.

## CareTeam

AttendingPhysician:Dr.Emily Chen,MDPager:(310)555-0112

## Pharmacies

CVSPharmacy4500BeverlyBlvd,LosAngeles,CA90022Phone:(323)555-0145

T:101.5F

## Vital sign

HR:110bpm

BP:125/78mmHg

RR:18breaths/min

02Sat:99%onroomair

## Allergies

No KnownDrugAllergies

## Medications

Ibuprofen2o0mgasneededforpain

## Vaccines

All childhood immunizationsuptodate.

## Problems

- AcuteAbdominalPain
- Fever

## FamilyHistory

Father:Healthy

Mother:Historyofmigraineheadaches

PaternalUncle:Had appendectomyatage25.

## Social History

Tobacco:Denies

Alcohol:Denies

Occupation:Graduate student.