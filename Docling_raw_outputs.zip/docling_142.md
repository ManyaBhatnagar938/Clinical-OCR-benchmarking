<!-- image -->

April20,2026

| SECTION A:Medical History  Yes  No  AlzheimerDisease,EarlyStage(ICD-10:G30.0)  X  Hypertension(ICD-10:110)  X  Type2DiabetesMellitus(ICD-10:E11.9)  X  Osteoarthritis,Bilateral Knee(ICD-10:M17.11)  X  UrinaryIncontinence(ICD-10:R32)  X  Depression(ICD-10:F32.9)  X   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  Donepezil 10 mg—once daily(PM)  X  Memantine10mg-twicedaily  X  Amlodipine5mg-oncedaily  X  Metformin500mg-twicedaily  X  Oxybutynin5mg-oncedaily  X  Acetaminophen500mg-PRN(max3g/day)  X  Mirtazapine15mg—once daily(bedtime)  X   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Dorothy Engram

Dorothy Ingram

Patient signature

Printname

<!-- image -->

Patient:DorothyR.

Ingram

DOB:01/17/1938

MRN:045-772-03