NorthwoodCommunityHospital789PineStreet,Northwood,CA90210Phone:(310)555-0101

Patient: //

MRN:456789

DOB:122995

ChiefComplaint

geddd

CareTeam

Attending Physician:DCT/DPager:(310555-011

Pharmacies

CVS Piay 4500 Brely Bad. n Agho CA 9002 Hta:(323)555-0145

Vitalsign

:101：12578 m+9

HtR:10

RR:18 burhbkie

O2Se: 99% m m 1

Allergies

lKue lDiugflings

Medications

Wapo200gndnp

Vaccines

Problems

FamilyHistory

fadn: Hteadiy

SociabHistory