MidwestOrthopedics&amp;SportsMedicineCenter950N.ClarkStreet,Chicago,IL60610

Patient: CherDe

MRN:SSC(77

DOB:60/5/266

ChiefComplaint

ekneemonndinttetgte ingung Irccer Jometrdeg.

CareTeam

AtndingPhgicien:Dn.Aorew Thme,APeger:(312) SS-235S

Pharmacies

Ahme:(312)SS-11

Vital sign

T: 78.(F

P:78

P：14/7

PR:1ereatt/mn

Oat166mmmm Gur

Allergies

m

Mediotens

- Napnzen 226 mg, as needed fr poin

Vaccines

- ·Aeenmnietnuptdate.

Problems

FamilyHistory

Nm-ontrtny. Perent ere i gmrd hceltt.

Social History

Teeoor: Denie

Meahe: Denies

Oooupoten:Celge stwdet plogm the unirentgsrocer tem.