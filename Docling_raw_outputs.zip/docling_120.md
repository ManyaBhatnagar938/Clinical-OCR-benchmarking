<!-- image -->

## HOSPITAL

## MidwestGastroenterologySpecialists

200FirstStreetSW Minneapolis,MN55905 (507)555-6789

PatientName:

lauhaeuank

MRN:2154879

MRN: 2154879

Accession:g25-1123

DOB:10/02/1984

Date:06/23/2025

Gender:femgle

Age: 40

ThepatertioaoyearolkevatewrthaSyoarlibyo gareeroplagealreluw dseae (gerd.sheiscurrentlymanagedwithouepragole20ugdaily.whicyMereportstaling conistently.kenotegoodcontrololertgricalaguptonolearthorwardregurgitationon thsregiveneprerenttodayoaoutinebolourup.Hedeniesanydpagiasdnoplaga suywnintentionalweiglt loss.

## PROCEDURES:

lepatosplenbmegaly.

Plan:guentedratiowolergutouepatiertarllbecheluledbovan epoplagogatroduodlenocopy legellor burtherevaluationard soreing.

## IMPRESSION:

gaotroeopagealedeaegerllcorolleopopupttoay plantoproceewrtrcreengege.