Patient:Mia R.Chen

TherapistNames:Ms.JuliaPark,

BCBA

## DAILY REPORT

- [ ] AnxiousCalm/ContentFrustrated

- [x] Cup

- [ ] AngryCheerful/HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

CameWith

- [ ] Jacket

- [x] Loving

- [ ] Lunch Box

- [ ] Other

## AGGRESSION

STEMMING

## NON COMPLIANCE

OTHER

- [ ] Hitting

- [ ] ThumbSucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [ ] Flopping

- [ ] Hand Flapping

- [ ] Touching

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [ ] Repeating

- [ ] Climbing

- [ ] PreservativeManding

- [ ] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [x] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Mia ate all fooditems and independentlyrequested more strawberries using afull sentence.Excellent lunch behaviorthroughout.

## LUNCH

Targets Hit During Lunch:

Spontaneoussentences(+4/5).Peerplayinvitation(+2unprompted).Toleratingpeerproximity(+5/5).

## Today's Struggles andStrengths:

## GROUP CIAL

Excellentsessionwithzeroproblembehaviors.Miahelpedapeerpickupspilledcrayonswithout prompting—— first observed prosocial behavior of this type.