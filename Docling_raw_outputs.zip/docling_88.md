<!-- image -->

## Tri-County Digestive Health Specialists

789WellnessBoulevard,Suite200 Oakmont,PA15139

Phone:(412)555-3456

Fax:(412)555-3457

ProcedureDate:06/21/2025

<!-- image -->

Thisdocumentcontainsconfidentialpatientinformationprotected underapplicableprivacy laws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).