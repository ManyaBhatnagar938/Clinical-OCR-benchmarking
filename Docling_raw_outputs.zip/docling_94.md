<!-- image -->

HOSPITAL

## Date ofBirth:03/02/1987Age:38Sex:Female Address:456OakAvenue,Springfield,USA67890

## ChiefComplaints:

## Medical HistorySnapshot:

HonDokikd

FaplJay H

- Culepi

## VisitSummary:

mbynhymopyy

Hdl

cAllln

## Exams:

VhalGolHopmnaHEeHHpadEynEnNouKutPlmylChulCndon hn

## Findings:

udbeitad udecoe eevn!

<!-- image -->

DateofVisit:06/21/2025

AttendingProvider:Dr.David Chen,MD

Location:CommunityUrgentCareCenter

VisitID:ENC-135792468