<!-- image -->

<!-- image -->

<!-- image -->

Patient:Mse

MRN:881100

DOB:06/15/1711

ChiefComplaint

CareTeam

benadrpig

- BP:128180 M-g

RR:16 leuotls/huo

2St

Allergles

AllwF-Cttet

Melustary

## Vaccines

- e-08101/2023

- Aeltlekygtptlt

Problems

FamilyHistory

Mtlx Sotrigtgh

Social History