<!-- image -->

<!-- image -->

| PatientName:Sarah Chen  OrderingPhysician:Dr.  DateofBirth:03/15/1997  ElizabethRoss  MRN:667890  Procedure:Left cervical lymph  Accession#:SH-25-55443  nodeexcisional biopsy  DateofProcedure:06/20/2025  DateofReport:06/25/2025   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Diagnosis:LymphNode,LeftCervical,Excision:Classical HodgkinLymphoma,NodularSclerosis Type.

Clinical History:28-year-old femalewith a one-month history ofa painless,enlargingleft-sided neck mass.Associated with nightsweats.Concernfor lymphoma.

GrossDescription:Received fresh,labeledeft neckmass,is anencapsulated lymphnode

Immunohistochemistry:Thelarge,atypical cellsshowthefollowingimmunophenotype:

measuring 2.8x2.1x1.5 cm.The cutsurfaceis tan-white andfirm,with a vaguely nodular appearance. MicroscopicDescription:Sectionsofthe lymphnodeshowcompleteeffacementofthenormal architectureby a nodularinfiltrate.Thenodules are definedbybroadbands ofcollagenousfibrosis. Withinthenodules,thereisamixed inflammatorybackgroundcomposedofsmall lymphocytes, eosinophils,and histiocytes.Scattered throughout this background are large,atypical cells,including classicbinucleated Reed-Sternberg cells and theirmononuclearvariants(Hodgkin cells).These cells have large,vesicularnuclei,prominenteosinophilic nucleoli,and abundant cytoplasm.

CD30:Positive

CD15:Positive

PAX5:Positive(dim)

CD45: Negative

CD20:Negative

CD3:HighlightsthebackgroundT-cell population.

Comment:The morphologicfindings in conjunction with the immunophenotype(CD30+,CD15+,

PAX5+,CD45-)are diagnosticof Classical Hodgkin Lymphoma,NodularSclerosis subtype.Clinical

Specimen:Left cervical lymph

Pathologist:Dr.BenjaminAyers

node

Report status:Final