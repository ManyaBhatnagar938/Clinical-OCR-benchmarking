Accession#:L20250620-1148

<!-- image -->

Patient:JamesPeterson

DOB:07/30/1955

MRN:357159

Gender:Male

ReferringPhysician:Dr.Laura

Fernandez

PremierClinicalLaboratories 1200TechnologyDrive Austin,TX78759

Phone:(512)555-5000

Fax:(512)555-5001

Order#:998123DateCollected:06/20/2025DateRep0rted:06/20/2025

## Clinical Laboratory Report

## Comprehensive MetabolicPanel(CMP)

TheresultsoftheComprehensiveMetabolicPanel showaGlucoselevelthatiselevated at132mg/dL. TheBUN is alsoelevated at22mg/dL.Liverfunctiontests showan elevatedALTof 55IU/L and an elevatedASTof48IU/L.

Thefollowingtestsarewithinnormal limits:Sodiumat140mmol/L,Potassiumat4.1mmol/L,Chloride at101mmol/L,CarbonDioxideat25mmolL,Creatinineat1.2mg/dL,Calciumat9.5mg/dL,Alkaline Phosphataseat110IU/L,TotalProteinat7.2g/dL,Albuminat4.1g/dL,andTotalBilirubinat0.8 mg/dL.

Comment: Mild hyperglycemia and mild elevation in liver transaminases are noted. Clinical correlation is recommended.

Recommendation torepeat liverfunctiontestsand checkHemoglobinA1cin 1-3monthsbased on clinical evaluation forhyperglycemia.Followupwith referringprovider.

DateofReview:06/20/2025

LaboratoryDirector:Dr.CharlesEvans,PhD

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseof theindividualorentitytowhom it isaddressed.lfyou are not theintendedrecipient,youareherebynotified thatanydisclosurecopying,distribution,oraction taken inrelianceon thecontentsof these documentsisstrictlyprohibited.lfyouhavereceived this reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneral HospitalImagingDepartment|123HealthWay,Springfield,IL,62704