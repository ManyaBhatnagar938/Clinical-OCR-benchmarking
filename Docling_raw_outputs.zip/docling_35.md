<!-- image -->

## Chief Complaints:

DateofVisit:06/21/2025

AttendingProvider:Dr.KatherineWhite,MD,

FACOG

Location:Women's Health Associates

VisitID:ENC-OB-2025-445

## DateofBirth:09/10/1992Age:32Sex:Female Address:678GardeniaCourt,Meadowbrook,USA78901

## Medical History Snapshot:

- Routine28-weekprenatalvisit

ObstetricHistory:Gravida 1,ParaO.EstimatedDueDate:

- Reviewoflabresults

09/27/2025.BloodType:O-negative.

- Mildlowerbackpain

Past Medical History:None.

Surgical History:None.

Medications:Prenatalvitamin,1tabletbymouth daily.

Allergies:NoKnownDrugAllergies.

## VisitSummary:

Emily is a32-year-old G1P0femaleat28weeks and 2 daysgestationwhopresentsforaroutine prenatalvisit.Shereportsfeelingfetal movement dailyand deniescontractions,vaginalbleeding,or leakageoffluid.Her1-hourglucosechallengetestresultfromlastweekwasnormal.Todayinthe office,shereceived theTdapvaccine and an injection of RHimmunoglobulin.Fundal height is appropriatefordates,andfetal hearttoneswerestrong.We discussed third-trimesterprecautions and kickcounts.Shewill return intwoweeksforher nextfollow-up.

## Exams:

Vitals,FetalHeartTones,FundalHeight

## Findings:

Vitals:BP118/72mmHg,Weight155lbs.

Fetal HeartTones:145bpmviaDoppler.

Fundal Height:28 cm.

Urine Dipstick:Negative forglucose and protein.

Extremities:Noedema.