<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name:Natalie G.Cruz  Date of Birth:06/25/1985  Proposed Procedure:  Surgeon/Department:  Laparoscopicovariancystectomy  Dr.HannahO.Jacobs,MD-GynecologicSurgery   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/Labs  Test  Result  Test  Result  Test  Result  WBC:  7.1  Hgb:  11.5L  Hct:  34.8L  Na:  140  K:  4.0  Glucose:  90  PT:  12.1  INR:  1.0  PTT:  26   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;PulmonaryRiskAssessment  []HxofMyocardial Infarction  []Congestive HeartFailure  []Arrhythmia/Pacemaker  []Hypertension  []COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []OtherCardiacHistory:   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  PreviousAnesthesia Issues:[]No[X] Yes  FamilyHxMalignantHyperthermia:[X] No[]Yes  MallampatiScore:[X][]l []l[]V  LooseTeeth/Dentures/Caps:[X]No[]Yes  NPO Status(Last MealDrink):  Weight (kg):  NPOaftermidnight  62   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

PONVhistorywithpropofol(2022)—useTIVAprotocol.Ondansetron4mgIV+dexamethasone4mg prophylaxis.lronsupplementation325mgPOpost-opformildanemia.

Evaluating Clinician Signature: aalelfuentea

Date: 04/17/2026