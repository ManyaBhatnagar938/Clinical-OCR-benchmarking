PatientName:EmilyWhiteMRN:9876543

<!-- image -->

## Coastal MedicalCenter

456OceanViewDriveSeaside, USA54321

Phone:(555)234-5678

Fax:(555)234-5679

## PATHOLOGYREPORT

831676002937

<!-- image -->

AccessionNumber:P2025-67890

DateofCollection:06/20/2025

TimeofCollection:09:00AM

SpecimenType:Lung,RightUpperLobe,WedgeResection

## Final Diagnosis:

Lung,rightupperlobe:Adenocarcinoma,lepidicpredominant,well-differentiated.

## Microscopic Description:

Thesectionsdemonstrateaproliferationofatypicalpneumocytesalongthealveolarseptainalepidic growthpattern.The tumor cells arecuboidal to columnarwith mild nuclearatypia and inconspicuous nucleoli.There arefocal areas of invasion measuringless than 0.5 cm.The surroundinglung

## Gross Description:

Received fresh,labeledwith thepatient'sname and"rightupperlobewedge,"is a5.5x3.2x2.1cm wedgeof lungtissuewithasmooth,glisteningpleuralsurface.Sectioningrevealsasolitary,ill-defined

## Comments:

surgicalmarginsarefreeof tumor.Correlationwithpreoperative imagingisrecommended.

## Biomarkers:

PD-L1lmmunohistochemistry: TumorProportionScore(TPS):&lt;1% MolecularTesting:

EGFRMutationAnalysis:Negativeforcommon activatingmutationsinexons18,19,20,and21. ALK Gene Rearrangement(FISH):Negative

ROS1GeneRearrangement(FiSH):Negative

- Interpretation:ThetumorisnegativeforPD-L1expression and lackscommontargetablemutations inEGFR,ALK,andROS1.

DateofBirth: 11/30/1955

Age: 69

Gender:Female

PatientAddress:789PineStreet,

Seaside,USA54321

OrderingPhysician:Dr.Michael

Chen,MD

Associates

Practice:Thoracic Surgery

Address:101MedicalPlaza,

Seaside,USA54321

Phone:(555)876-5432