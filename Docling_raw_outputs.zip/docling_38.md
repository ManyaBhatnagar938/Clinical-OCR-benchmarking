EastsideChildren'sMedicalCenter200Children'sWay,Philadelphia,PA19104Phone:(215)555-6700

Patient:LiamGarciaMRN:987654D0B:04/10/2022

## ChiefComplaint

Fever,persistentcough,andwheezingforthreedays.Poorfeedingfor24hours.

## CareTeam

Attending Physician:Dr.AishaKhan,MD Pager:(215)555-6789

## Pharmacies

RiteAid850NBroadSt,Philadelphia,PA19130Phone:(215)555-9876

## Vital sign

HR:145bpm

T: 102.8°F (Tympanic)

BP: 90/60 mmHg

RR:40breaths/min

02Sat:93%onroomair

## Allergies

Peanuts-Hives

## Medications

- Acetaminophen160mg/5mL,asneededforfever.

## Vaccines

All primaryseriesvaccinations areuptodateforage.

- Influenza-10/30/2024

## Problems

- All primary seriesvaccinations are up to dateforage.
- Influenza-10/30/2024

## Family History

Mother:Historyof seasonal allergies.

Father:History of childhood asthma.

Older sister:Healthy.

## Social History

Attendsdaycarefull-time.

Non-smoking household.No pets.

Lives athomewithparentsand oneolder sibling.