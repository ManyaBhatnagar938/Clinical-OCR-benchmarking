<!-- image -->

<!-- image -->

| PatientName:Brenda Jones  Ordering Physician:Dr.Patricia  DateofBirth:07/16/1996  Wells  MRN:554321  Procedure:Ultrasound-guided  Accession #:SK-25-88765  kidney biopsy  DateofProcedure:06/23/2025  DateofReport:06/25/2025   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Clinical History:29-year-old female with aknown historyof Systemic Lupus Erythematosus(SLE), presentingwithnew-onsetproteinuria and hematuria.Biopsyisperformed toevaluateforlupus nephritis.

Diagnosis: Kidney, native, biopsy: Lupus Nephritis, Class IV-G (A)

Light MicroscopyDescription:The specimen consists of two cores of renal cortex and medulla.Up to 28glomeruli are identified forevaluation.All glomeruli showglobal,diffuse endocapillary and mesangial hypercellularitywithneutrophilicinfiltration.Multipleglomerulicontainwire looplesions. There is moderatetubular atrophy and interstitialfibrosis involvingapproximately 30% of thecortex.No

crescentsorfibrinoid necrosis are seen.

## Immunofluorescence Description:

IgG: 3+granular staining in mesangium and capillary loops (full house pattern).

IgA: 2+ granular staining in mesangium and capillary loops.

IgM:2+granular staining in mesangium and capillary loops.

C3: 3+ granular staining in mesangium and capillary loops.

C1q: 2+ granular staining in mesangium and capillary loops.

Fibrinogen:Negative.

Albumin:Negative.

Electron Microscopy Description:Electron microscopy confirms diffuse subendothelial and mesangialelectron-dense deposits.Tubuloreticularinclusions arepresent within endothelial cells. Thereisapproximately5o%podocytefootprocesseffacement.

Comment:The combined findings are diagnosticof active,diffuseglobal lupus nephritis,ISN/R 2003 Class IV-G (A).

Specimen:Nativekidneybiopsy

Pathologist:Dr.Richard Lee

Report status:Final