PatientName:BrendaJohnsonMRN:5551234

<!-- image -->

## MidwestRegional Hospital

1000 Health Way Springfield,IL 62704

Phone:(217)555-1000

Fax:(217)555-1001

## PATHOLOGYREPORT

831676002937

<!-- image -->

AccessionNumber:P25-88765

DateofCollection:06/20/2025

TimeofCollection:01:15PM

SpecimenType:Thyroid,FineNeedleAspiration(FNA)

## Final Diagnosis:

THYROID,RIGHTLOBE,FNA:

MALIGNANT.PapillaryThyroid Carcinoma.

(BethesdaSystemforReportingThyroid Cytopathology,CategoryVl)

## Microscopic Description:

The smears arecellularand shownumerouspapillary clusters,syncytial-type fragments,and single atypical follicularcells.The tumor cells demonstrateenlarged,overlappingnucleiwith irregular contours,powderychromatin,andprominentintranuclearpseudoinclusions.Psammomabodies are also noted.Thebackground is clean.

## Gross Description:

ReceivedfourPapanicolaou-stained andtwoDiff-Quik-stainedslides,all ofwhicharecellularand adequateforinterpretation.

## Comments:

The cytomorphologicfeatures arediagnosticofPapillaryThyroid Carcinoma.Clinical correlation and surgicalconsultationforthyroidectomyarerecommended.

## Biomarkers:

MolecularTesting(from cell block):

BRAFV600EMutationAnalysis:Positive

Interpretation:A BRAFV6ooEmutationwasdetected.ThisfindingisassociatedwithPapillaryThyroid Carcinomaand may haveprognosticand therapeuticimplications.

DateofBirth:07/22/1979

Age:45

Gender:Female

PatientAddress:987MapleLane,

Springfield, IL 62704

OrderingPhysician:Dr.Richard

Peterson,MD

Practice:Central Illinois

Endocrinology

Address:500MedicalParkDr,

Springfield, IL 62704

Phone: (217) 555-3456