Patient:LucasM.Fontaine

- [x] Cup

- [ ] Anxious Calm/Content Frustrated

- [ ] AngryCheerful/HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

Came With

- [x] Jacket

- [ ] Loving

- [ ] Lunch Box

- [ ] Other

## AGGRESSION

## STEMMING

## NONCOMPLIANCE

OTHER

- [ ] Hitting

- [ ] Thumb Sucking

- [x] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [ ] Flopping

- [ ] Hand Flapping

Touching

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [x] Repeating

- [ ] Climbing

- [ ] PreservativeManding

- [ ] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [x] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Lucas ate all of hislunch independently.Showed preference for apple slices.Nopromptingneeded for utensils.

## LUNCH IME

TargetsHit During Lunch:

Manding for preferred items (+4/5). Tact labels for food (+3/5). Tolerating non-preferred items at table (3/5).

## Today'sStruggles andStrengths:

GROUP CIAL S

Struggledwithturn-takingduringcircletimebutimproved towardend ofsession.Strength: spontaneousgreetingstotwopeerswithout prompting.

## DAILY REPORT

Therapist Names:Ms.Rachel Torres,BCBA