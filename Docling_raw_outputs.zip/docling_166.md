<!-- image -->

## Surgical Pre-Operative Assessment

| DateofBirth:05/30/1955  Patient Name:Helen F.Morrison  Surgeon/Department:  Proposed Procedure:  Dr.FionaK.Reyes,MD-Surgical Oncology  Leftsentinellymphnodebiopsy   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/ Labs  Test  Result  Test  Result  Test  Result  WBC:  5.8  Hgb:  12.4  Hct:  37.2  Na:  140  K:  3.9  Glucose:  98  PT:  12.5  INR:  1.0  PTT:  27   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;PulmonaryRiskAssessment  []HxofMyocardialInfarction  []Congestive Heart Failure  []Arrhythmia/Pacemaker  [X]Hypertension  []COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []Other CardiacHistory:   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  PreviousAnesthesia Issues:[X] No[] Yes  FamilyHxMalignantHyperthermia:[X]No[]Yes  LooseTeeth/Dentures/Caps:[X]No[]Yes  MallampatiScore:[×]I []ll []ll []Iv  NPO Status(Last MealDrink):  Weight(kg):  NPOaftermidnight  68   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

Hold Letrozoleon day of surgery.Levothyroxine with small sip of water AM.Lymphoscintigraphy scheduled pre-op at 07:00.

Final Clearance:[X] CLEAREDFORSURGERY[]NOTCLEARED[]PENDINGLABS