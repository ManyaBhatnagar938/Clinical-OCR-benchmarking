UniversityMedicalCenter456OakAvenue,Springfield,IL62704Phone:(217)555-1234

<!-- image -->

<!-- image -->

JaneSmithMRN:789012DOB:05/15/1968

## ChiefComplaint

Chestpainandshortness of breathfortwo days.

CareTeam

AttendingPhysician:Dr.RobertJones,MDPager:(217)555-5678

Pharmacies

MainStreetPharmacy123MainStreet,Springfield,IL62701Phone:(217)555-8765

Vitalsign

T:98.9.

HR: 98

BP:145/92 *

RR: 20 hntkr/mm

02Sat:942-**

Allergies

P-Rrk

Medications

Mpl 10yy

Vaccines

Jf - 10/15/2024

Fr - 08/ 20/2022 C0VJ0-19

tbtx-12/05/2024

## Problems

- B2Ohtrmutr

## FamilyHistory

Ati Mtka: tomdtyrufty.

## Social History

PRu: Smr I rl  outtr px x  30 xm.

Aakl:Onpindrciadue.

byment: tiud.lf