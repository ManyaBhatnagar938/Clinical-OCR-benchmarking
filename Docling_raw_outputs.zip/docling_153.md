<!-- image -->

| OliviaT.Brennan  DOB:04/12/1995  Acct#:62441-E  PRECISION  Age:31  Physician: Dr. Marcus J.  DIAGNOSTIC  LAB  Sex:F  Cohen, MD  04/18/202609:00  04/18/202609:50  04/18/202611:00  NMRLipoProfile   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## NMR LipoProfile

| Test  Result  Previous  Date  Units  Reflnterval  Result  LDLParticleNumber  620  640  02/20/2026  nmoUL  &lt;1000  LDL-P  620  640  02/20/2026  nmoUL  &lt;1000  Lipids  LDL-C(NIH Clac)  72  76  02/20/2026  mg/dL  &lt;100  HDL-C  72  70  02/20/2026  mg/dL  &gt;=40  Triglycerides  88  92  02/20/2026  mg/dL  &lt;150  Cholesterol,Total  158  164  02/20/2026  mg/dL  &lt;200  LDL and HDL Particles  HDL-P (Total)  36.4  35.8  02/20/2026  nmol/L  &gt;=30.5  Small LDL-P  218  240  02/20/2026  nmolL  &lt;527  LDL Size  21.5  21.2  02/20/2026  nm  &gt;=20.5   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Comment

AllNMRLipoProfilevalueswithinnormalreferenceintervals. Favorableparticlesizedistribution.Nopharmacologic interventionrequiredatthistime.