<!-- image -->

<!-- image -->

Patient Name: ane Dee

OrderingPhysician:

Dr Sarak Jenbins

DateofBirth:08/15/1967

MRN:789012

DateofService:06/15/2025

DateofReport:06/20/2025

Accession#:25-12395

## PathologyFindings:

Clinical Information: S8-yearele Female with a nen-aainful.pigmentel lerian em the eeftchek.Thelesianhasbonpresent For apprnximatelyone gear,with arecentslight inereasein sge.Clinical cancern typicaeneuusussehoheickeratosis.

Comment: rutatiancerrerpanobe to themilde lermal inflammation sonmicrascopically

Clinical cerelationirrecommended. Receivedin submitted entirely in ene cassette.

Eiratinacgtes.Tre architecturesheaprominent acanthari.paplematarr.ane theformationof numernuskeratimflledinvaginatianr andl harur peuolrcgtrTre basalrid celrare uniform in carianal einaphilrThe dopandl peripheralmarginrarefreofthe eerianNeeidlence of dyiplana

Specimen:Qne piece of skin

lramtheeeftchok.

measwring 05x 0.4x02 cm.

Report status:Fira

Accession#:S25-12345

Pathologist:

DrJamer Peteron