Name:Dorothy R.Ingram

Age:88

Attend Dr:Dr.SamuelT.Baines

Acct#:45772-H

Sex:F

Location:Geriatrics

Date:04/20/2026

DOB:01/17/1938

SPEC#:S-2026-04-20-090

COLLECTEDTIME:08:00

STATUS:FINAL

ENTERTIME:08:00

REPORTTIME:10:30

REQ#:R-45772

ORDERTIME:07:50

| Test  Result  Flag  Reference  Site  WBC  9.6 x10/μL  4.5-11.0  GER  REC  3.55 x10%μL  L  4.00-5.20  GER  HGB  10.5g/dL  L  12.0-16.0  GER  HCT  31.8 %  L  36.0-46.0  GER  MCV  89.5fL  80.0-100.0  GER  MCH  29.6pg  27.0-33.0  GER  MCHC  33.0 g/dL  32.0-36.0  GER  PLT  168x10/μL  150-400  GER   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|