<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name:Carlos M.Rivera  DateofBirth:09/14/1990  ProposedProcedure:  Surgeon/Department:  Septoplastyandinferiorturbinatereduction  Dr.MarcusD.Osei,MD-ENTSurgery   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/Labs  Test  Result  Test  Result  Test  Result  WBC:  6.4  Hgb:  15.1  Hct:  44.8  Na:  141  K:  4.2  Glucose:  88  PT:  12.0  INR:  1.0  PTT:  25   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;Pulmonary RiskAssessment  []HxofMyocardialInfarction  []CongestiveHeartFailure  []Arrhythmia/Pacemaker  []Hypertension  [X]COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []OtherCardiacHistory:   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  PreviousAnesthesiaIssues:[X] No[]Yes  FamilyHxMalignantHyperthermia:[X]No[]Yes  MallampatiScore:[]l[X]ll[]l[]Iv  LooseTeeth/Dentures/Caps:[X]No[]Yes  NPO Status(LastMeal/Drink):  Weight(kg):  NPOaftermidnight  78   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

Pre-opnebulisedsalbutamol 2.5mg30minbeforeinduction.Avoid aspirin and NsAlDspost-opfor2weeks. Continuefluticasoneinhalerthroughperioperativeperiod.

Evaluating Clinician Signature: Catherine Park

Date: 01/29/2026