<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

PatientName:

OrderingPhysician:

Date of Birth:03/15/10

MRN:661890

Procedureo

Accession#:925-5543

Date ofProcedure:6/20/2025

Date ofReport:D6/25/2025

Clinical History:28galadkmeaatkRtry malulg lfset py

Diagnosis: lgakNlftCrelEunClel bt gapkmNlaSlss

Aygre up@sh 2.1x15 FRetsufastkdAradkgu DoenptnSotng tkelyaknshe aapldedhrunatit thrrorateerekdida

## nodular:

CD30

CD15:

PAX5:

CD45:

CD20:

CD3:

Comment:

Specimen:left uerkeallgapk

Pathologist:rbnh

Agury

Accession#:SH-25-55443

<!-- image -->