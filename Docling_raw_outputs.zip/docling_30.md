<!-- image -->

## Chief Complaints:

## VisitSummary:

DateofVisit:06/21/2025

AttendingProvider:Dr.David Chen,MD

Location:Community Urgent Care Center

VisitID:ENC-135792468

## Date of Birth:03/02/1987Age:38Sex:Female Address:456OakAvenue,Springfield,USA67890

## Medical History Snapshot:

- Worsening shortness of breath

Asthma:Diagnosed in childhood.

- Audiblewheezing

Seasonal AllergicRhinitis:History of seasonal allergies, particularlyin the spring.

- Chest tightness

- Non-productive cough

Surgical History:None.

FamilyHistory:Motherwithahistoryofasthmaandeczema. Medications:

AlbuterolHFA(ProAir)90mcg/actuationinhaler,2puffs every4-6hoursasneeded.

Fluticasone/Salmeterol(AdvairDiskus9)250/50 mcg,1 inhalationtwicedaily.

Allergies:Penicillin (causes arash).

This38-year-old femalewith aknownhistoryofpersistentasthma presentswith athree-dayhistoryof mild upperrespiratoryinfection aboutoneweekago,which has nowresolved,butherrespiratory symptoms have since escalated. She has increased the use of her rescue Albuterol inhaler to 6-7 times perdaywithonlypartial,temporaryrelief.Examinationrevealedapatientinmildrespiratorydistress withaudiblewheezing.A DuoNeb(ipratropiumbromideand albuterolsulfate)nebulizertreatment wasadministeredintheoffice,whichprovidedsignificantimprovementinherworkofbreathingand reducedwheezingon auscultation.Sheis dischargedwithaprescriptionfora5-day courseoforal Prednisone.Thepatientwaseducatedonherasthmaactionplan,thesignsofasevere exacerbation requiringemergencycare,and theimportanceofadherencetohercontrollermedication.Shewill followupwithherprimary carephysicianin3-5days.

## Exams:

Vitals,GeneralAppearance,HEENT(Head,Eyes,Ears,Nose,Throat),Pumonary/Chest, Cardiovascular,Skin

## Findings:

Vitals:BP128/76mmHg,Pulse95bpm,RR22,Temp98.9°F,Sp0295%onr0omair.

GeneralAppearance:Alert and oriented.Mildly anxious,speakinginfull sentences.Mild tachypnea noted.

HEENT: Mucous membranes are moist.Mild boggy turbinates noted in the nares.Pharynx is non- erythematous.

Pulmonary/Chest:Diffuseexpiratorywheezesheard throughout all lungfieldsbilaterally.Good air