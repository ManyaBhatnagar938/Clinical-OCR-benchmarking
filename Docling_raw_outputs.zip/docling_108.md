<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Patient Name:

OrderingPhysician:

DateofBirth:

MRN: 345/23

Procedure:

Accession#:-25-45679

DateofProcedure:

DateofReport:

25/2025

Clinical History: 5Ayayoldmale ilt a hytoay of chisnu dyppya andepgaslvu pam iopgies BalentoealraleboegastrlyanduleaiteHolbuihadtanpyloeunfetron

Diagnosis:gatuAtunBuopyMed chngatitypytueloHlebadopylo

Gross Description: Duwed in Pormalin labeled gastrw antu aze Pawtan mcsal Ragreny

Microscopic Description ontangamldnanhonunlamatayllnldglyphgyandplaaallNogn nliophlatuilytrtnaltaplaadyplayamalgranydnlfedApealtan gangmyhghegkt ynumeouyspralhapedbaitayaoneufaroaloeolarvpiltelummophologually Helcobailerpgos

Comment:TehytopalloogeFndngrae dagnateoamld chonegasttyapatal gtt

Specimen: Gatru antiw

Pathologist: Dv Culy

Carte

Reportstatus:Final

<!-- image -->