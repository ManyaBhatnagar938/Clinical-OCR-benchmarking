<!-- image -->

## FAX

<!-- image -->

To:Dr.Evelyn Reed,Cardiology Department

Facility:Mercy General Hospital

Fax:(555) 890-1234

Phone:(555) 890-1235

Re:Cardiology Consult for Patient:WILLIAMS,Sarah

From:Dr.Alan Chen,MD,Internal Medicine

Facility: Crestwood Primary Care

Fax:(555) 456-7890

Phone:(555) 456-7891

Date:June 25, 2025

Time:11:15 AM

Pages:1 (including cover)

## Notes:

Subject:Urgent Cardiology Consultation Request

Dear Dr.Reed,

Iam referring my patient,Sarah Wi1liams （D0B:05/22/1960),for an urgentcardiologyevaluation.

History ofPresent Illness:Ms.Williams is a 65-year-old female with a history ofhypertension and hyperlipidemiawhopresented to my clinic todaywitha two-dayhistory of intermittent chest tightness and shortness of breath upon exertion.She describes the tightness as a"pressure"in the center of her chest,which subsides with rest.She denies any radiation of pain,diaphoresis,or nausea.

The information containedin thisfacsimilemessageislegallyprivileged and confidentialinformation intendedonlyfortheuseof the individualorentitynamed above.If thereaderof thismessageisnottheintendedrecipient,you arehereby notifiedthatanydissemination,distribution,orcopyingof thistelecopyisstrictly prohibited.lfyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus bytelephone andreturn the original message to us at the address abovevia the U.s. Postal Service.Thankyou.