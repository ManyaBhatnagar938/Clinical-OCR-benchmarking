<!-- image -->

HOSPITAL

| Full Name:  Dateof Birth(MM/DD/YYYY):  PatientID/MRN:  Maria C.Delgado  03/28/1972  MRN-007214  Gender:[]M[X]F[]Other  Phone Number:(281)555-0376  Today'sDate:03/10/2026   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(oF)  SpO2(%)  Weight(lb)  Height(in)  118/74  68  14  98.6  66  152  64   |
|-------------------------------------------------------------------------------------------------------------------------------|

| Medical History  []Hypertension  [] Diabetes (Type l)  [] Diabetes (TypeIl)  [X]Asthma  []COPD  []Heart Disease  [X] High Cholesterol  [X] Thyroid Disorder  []Arthritis  []Cancer  []Depression/Anxiety  []Other:   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  75mcg  Once daily(fasting)  Levothyroxine  Fluticasoneinhaler  220mcg  Twicedaily  10mg  Once daily (PM)  Rosuvastatin  Cetirizine  10mg  Once daily(PM)   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Latex  Contactdermatitis  Codeine  Nausea/vomiting   |
|------------------------------------------------------------------------------------------|

## Reason for Visit

Annual wellness visit.Asthma well controlled per patient report.Thyroid function recheck and lipid panel ordered.