<!-- image -->

## UniversityDermatologyAssociates

950CampusDrive,Suite210 Durham,NC27708 (919)555-3400

<!-- image -->

<!-- image -->

PatientName:

Lchael

MRN:7256

MRN:732N36

Accession: g 9276

DOB:152002

Date:012025

Gender:

Age: bgktty darkerore the fhepatentonyeos olmalshe uptadforaontneshnnnnateon

## PROCEDURES:

SranBopy lrer Bnck Sntenesyetednt supehaolaspedte scapula uttoanesttpheand e haeopy teln spefoe Fenstaddttlncepenntfo stopatholog necinninataor

IMPRESSION: MICRSCCDtSCRPHN Stseamtu

llreuitedpolferatronestedannglnelesteycnfnedttheeal

epihehaalpunetion

Noritota aetanty ouluationiy identfed

DIAGNOSIS: undtiemal mrelanwagta nevuy benign

Patient Name:MichaelJohnson MRN:7321856Age:22

ElectronicallySigned By:Dr.AngelaDavis,M.D.(Pathology)

Date:06/23/2025Time:09:05