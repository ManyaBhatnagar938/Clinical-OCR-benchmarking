<!-- image -->

To:Dr.David Chen,Gastroenterology

Facility:Metropolitan DigestiveHealth Institute

Fax:(555) 600-7000

Phone:(555) 600-7001

Re:Patient Referral: PETERSON,Emily

From:Dr. Susan Wojcik, MD, General Practice

Facility:Northwood Medical Clinic

Fax:(555) 210-3110

Phone:（555) 210-3111

Date:June 25,2025

Time:11:23AM

Pages:1 (including cover)

## Notes:

Subject:Patient Referral for Endoscopy

Dear Dr.Chen,

Iam referring my patient,Emily Peterson （D0B:09/01/1995),for consultationand probable EGD due to persistent GERD symptomsand newonset dysphagia.

Summary:Ms.Peterson isa 29-year-old female with a 5-year historyof gastroesophageal reflux disease,managed with a daily proton-pump inhibitor （Omeprazole 20mg).For the past month,she has reported that her symptoms of heartburn and regurgitation are no longer wellcontrolled.More concerningly,she has developed a sensation of food "getting stuck"in her lower esophagus.

The information contained in thisfacsimile message islegally privileged and confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.lf thereader of this message is not theintended recipient,you are hereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.lfyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus bytelephone andreturntheoriginal message tous atthe addressabovevia theU.s. Postal Service.Thank you.

<!-- image -->

## FAX