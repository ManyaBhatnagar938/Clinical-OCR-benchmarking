Accession#:C123456-25

<!-- image -->

## CT HeadWithoutContrast

Patient:David Lee

DOB:10/25/1958

MRN:987654

Gender:Male

ReferringPhysician:Dr.Susan

Phone:(555)234-5678

Fax:(555)234-5679

Cho

## Visit #:789-123DateofVisit:06/20/2025

Procedure:Computed tomographyoftheheadwithoutintravenouscontrast. Clinical Indication:Sudden onsetofsevereheadache,rule outintracranialhemorrhage.

Brain Parenchyma: There is no evidene of acute tenitorial infarct.mas elfeit. or midline shift. No abnomal densities are sen to suggest acit intracranial hemonhage.The grag-vhite matter diffrentiation is presened.βBaal ganglia and thalami appear unremarfable.

Ventricular System and Cisterns: The ventricular sgstem is notmal in sige and conliguraltion lor the patient's age. The basal cisterns are clear

Osseous and Soft Tissues: The calvarium is intat vith no evidence of acute paiture. The eparanasalsinusesand mastoidair cells are clarThe viualied portions ofthe orbit andofttiue of the calp are unemarable.

Impression:

Negatire for acut intracanial hemonhage. NCTeridene of other acute intacranial abnomality

## Scheduled appointments:

Follow-upscheduledwiththeNeurologyClinicforfurtherevaluationofheadache.Appointmentwith Dr.Milleron06/27/2025at9:00AM.

DateofDictation:06/20/2025

Technician:JenniferDavis,RT(R)(CT)

andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom itisaddressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction takeninrelianceonthecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

LakesideGeneralHospital 100HospitalWay RiverCity,USA67890 MetroRadiologyAssociates