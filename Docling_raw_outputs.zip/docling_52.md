<!-- image -->

## UniversityDermatologyAssociates

950CampusDrive,Suite210 Durham,NC27708 (919) 555-3400

PatientName:MichaelJohnson

MRN:7321856

MRN:7321856

Accession:P25-9876

DOB:08/15/2002

Date:06/19/2025

Gender:Male

Age: 22

Thepatientisa22-year-oldmalewhopresentedforaroutineskinexamination. Henoted a moleonhisupperbackthat hebelieveshasbecomeslightlydarker over thepastyear.He denies any symptoms of painoritching associated with the lesion.He has a historyof significant sun exposure duringhisteenyears and reports occasional sunburns.

## PROCEDURES:

ShaveBiopsy,UpperBack:A5mmpigmented maculewasidentified onthe superior aspect of theright scapula.Afterobtainingconsent,the areawas anesthetizedwith1%lidocainewithepinephrine,andadeepshavebiopsyofthe lesionwasperformed.Hemostasiswasachievedwith aluminumchloride.The specimenwassent forhistopathologicexamination.

## IMPRESSION:

MICROscOPICDESCRIPTIoN:Sectionsshowa symmetric,well-circumscribed proliferation of nested and singlemelanocytesconfined tothe dermal-epidermal junction.The melanocytes are uniform in size and shape with no significant cytologicatypia.Nomitotic activityorulcerationisidentified. DIAGNosIs:Junctionalmelanocyticnevus,benign.

Patient Name:MichaelJohnson MRN:7321856Age:22

Date:06/23/2025Time:09:05