<!-- image -->

January30,2026

| SECTION A:Medical History  Yes  No  Asthma,ModeratePersistent(ICD-10:J45.40)  AllergicRhinitis(ICD-10:J30.9)  X  ADHD,CombinedType（ICD-10:F90.2)  X  MigrainewithoutAura(ICD-10:G43.009)  X  Eczema/AtopicDermatitis(ICD-10:L20.9)  X   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  Fluticasone/Salmeterol250/50mcg-twicedaily  X  AlbuterolHFA90mcg-PRNevery4-6hrs  X  Montelukast10mg-once daily(PM)  X  Cetirizine 10mg—once daily(PM)  X  Amphetamine saltsXR20mg-once daily(AM)  X  Topiramate50mg-oncedaily(PM)  X   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

Carlos Rivera

CarlosRivera

Patient signature

Printname

<!-- image -->

Patient:CarlosM.Rivera

DOB:09/14/1990

MRN:038-664-19