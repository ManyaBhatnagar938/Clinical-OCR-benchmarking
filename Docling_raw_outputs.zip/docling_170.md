<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name:David P.Kowalski  Date of Birth:02/07/1962  Proposed Procedure:  Surgeon/Department:  Rightcarotidendarterectomy  Dr.BernardT.Huang,MD-VascularSurgery   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-AdmissionTesting/Labs  Test  Result  Test  Result  Test  Result  WBC:  8.8  Hgb:  13.8  Hct:  41.5  Na:  138  K:  4.3  Glucose:  122  PT:  13.5  INR:  1.2  PTT:  31   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;PulmonaryRiskAssessment  [X]Hxof Myocardial Infarction  []Congestive HeartFailure  []Arrhythmia/Pacemaker  [X]Hypertension  []COPD/Asthma  []ObstructiveSleepApnea  [X]SmokingHistory  []ExerciseTolerance&gt;4METs  []Other CardiacHistory:   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia &amp;Airway  PreviousAnesthesia Issues:[X] No[]Yes  FamilyHxMalignantHyperthermia:[X]No[]Yes  MallampatiScore:[]l[X]l[]l[]V  LooseTeeth/Dentures/Caps:[X] No[]Yes  NPO Status(LastMeaVDrink):  Weight (kg):  NPOaftermidnight  96   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

opmonitoringforminimum24h.Glucosemonitoringevery2hpost-op.

Evaluating Clinician Signature: ThomAS OkAfor

Date: 02105/2026