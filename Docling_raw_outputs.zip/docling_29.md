<!-- image -->

## Chief Complaints:

DateofVisit:06/21/2025

AttendingProvider:Dr.EmilyCarter,MD

Location:GeneralInternal Medicine Clinic

VisitID:ENC-987654321

Date ofBirth:05/15/1970Age:55Sex:Male

Address:123MainStreet,Anytown,USA12345

## Medical History Snapshot:

- Headache

Hypertension:Diagnosed 5years ago,previouslymanaged

- Dizziness

with lifestylemodifications.

- Fatigue

Hyperlipidemia:Diagnosed 2years ago,managedwith diet

- Follow-upforhypertension

andexercise.

Surgical History:Appendectomy(2010)

FamilyHistory:Fatherwithahistoryofcoronaryartery

disease.Motherwithtype2diabetes.

Medications:Lisinopril10mgdaily(newprescription).

Allergies:Noknown drug allergies.

## VisitSummary:

Thisisafollow-upvisitformanagementofhypertension.Thepatientreportsintermittentheadaches and dizzinessforthepast three months.He denies chest pain,shortness of breath,or changes in vision.Hehasbeen attemptingtofollow a low-sodium dietbut admitsto inconsistent adherence. Today'sbloodpressurereadingiselevated at152/94mmHg.Athoroughphysicalexaminationwas conducted.Given thepersistentelevation inbloodpressuredespitelifestylemodifications,a new medication,Lisinopril10mgdaily,hasbeenprescribed.Thepatientwascounseled ontheimportance ofmedication adherence,continued dietarysaltreduction,andregularexercise.Hewas also advised tomonitor hisblood pressure at home.A follow-upappointment is scheduled in 4weekstoassess his responsetothenewmedication andfora recheckof hisbloodpressure.

## Exams:

Vitals,HEENT(Head,Eyes,Ears,Nose,Throat),Cardiovascular,Pulmonary/Chest,Abdominal, Neurological,Extremities

## Findings:

Vitals:BP152/94mmHg（rightarm,sitting),Pulse82bpm,RR16,Temp98.6°F.

HEENT:Normocephalic,atraumatic.Sclerae anicteric.No signs of retinopathy onfunduscopic exam.

Cardiovascular:Regularrate and rhythm.No murmurs,gallops,orrubs.No carotid bruits.

Pulmonary/Chest:Lungs clearto auscultationbilaterally.Nowheezes or crackles.

Abdominal:Soft,non-tender,non-distended.Bowel soundsarenormal.No abdominalbruits.

Neurological:Alertand orientedx3.Cranial nerves ll-Xll intact.Strength5/5 throughout.Sensation intact.

Extremities:Noperipheral edema.Pulses 2+and equal bilaterally.

Patient:JohnathanA.DoeMRN:789-01-2345