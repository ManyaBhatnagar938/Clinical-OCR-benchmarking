<!-- image -->

To:Dr. Isabella Rossi,Endocrinology

Facility:Institute for Diabetes &amp; Metabolism

Fax:(555) 800-9000

Phone:(555) 800-9001

Re:Patient Referral:GOMEZ,Luis

From:Sarah Jenkins,FNP-C

Facility:Lakeside Family Health

Fax:(555) 400-5000

Phone:(555) 400-5001

Date:June 25, 2025

Time:11:30 AM

Pages:1 (including cover)

## Notes:

Subject:ConsultforUncontrolled Type2Diabetes

Dear Dr.Rossi,

Iam referring my patient,Luis Gomez（DoB:10/16/1965),for assistance with managing his poorly controlled Type 2 Diabetes.

His most recent HbA1c was 9.8%,despite adherence to maximal doses of Metformin and Glipizide.He is now experiencing symptoms of peripheral neuropathy.I am referring him to you for optimization of his regimen, likely requiring the addition of a newer agent or insulin therapy.

Thankyou for your consultation.

The information contained in thisfacsimile message islegally privileged and confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.If thereaderof this message is not the intended recipient,you arehereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.Ifyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by telephone and return the original message to us at the address above via the U.s. Postal Service.Thankyou.

<!-- image -->

## FAX