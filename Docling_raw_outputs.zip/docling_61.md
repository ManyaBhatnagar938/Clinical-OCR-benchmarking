<!-- image -->

To: Dr. Richard Sato, MD, Nephrology

Facility:Kidney Care Associates

Fax:(555) 717-8181

Phone:(555) 717-8182

Re:Nephrology Consult: BAKER, Helen

From:Dr.Maria Flores,Internal Medicine

Facility:Stone Creek Medical Group

Fax:(555) 616-7171

Phone:(555) 616-7172

Date:June 25,2025

Time:11:32 AM

Pages:1 (including cover)

## Notes:

Subject:Referral for Progressive ChronicKidney Disease

Dear Dr.Sato,

I am referring Helen Baker(DoB:08/21/1955) toyour practice for evaluation of her worsening chronickidney disease.

Ms.Baker has a longstanding history of hypertension and Type 2 Diabetes.Areviewof herlabs shows her eGFR has trended down from 55 to 42 over the past year,and she now has newmicroalbuminuria.Her blood pressure remains difficult to control.

Iam referring her for your expertise in managing her renal function and resistant hypertension.Thankyou for seeing her.

Theinformationcontained inthisfacsimilemessage islegallyprivileged and confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.lf thereaderof thismessageisnottheintendedrecipient,you arehereby notified that any dissemination,distribution,or copyingof thistelecopyisstrictly prohibited.lf youhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by telephone and return the original message to us at the address above via the U.s. Postal Service.Thankyou.

<!-- image -->