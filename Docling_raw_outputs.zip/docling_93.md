<!-- image -->

HOSPITAL

DateofBirth:25/45/1970

Age:

55

Sex:hol

Address:1Z3hi Steet AntronlA A12355

## ChiefComplaints:

## Medical HistorySnapshot:

- Hendache

- Diagies

nodificntione.

HyerlipideniniDigroed?

pedvilkdietardexereice

- Fatigue

Snrgieol Heton:Apdeton (2D10)

- Follow-pfor beertenion

FonilHtedlon:atter nitka biteorfarnang arton dieMeter

itk tipedibitee.

Wedieatone:icinpril Ong dail(reuprnptor).

Allergiec:

o.knev

## VisitSummary:

hirpertensior.The miert psrteisterniertheadachesakd diapikensfor ttepaet-tbreenonthc.fedekies chest breath,orchargesinMicioe bachek pressure reading is elevatedat1S217nng.Attoranghphycicol exonisatior us cordneled.giver t thepersistentelevationin Lailg, bacbeer preseribed.The mtientu coueledrteinporlakceofmedictiradhereke ctiaueddietar collrednetin, andregulr Veeke toassens hicrespokse tothe reu medicotins and for arecheck oflicblaodpressure.

## Exams:

Vtale,HEM(Hleod,ie,areYece,Throat),Cardiovaseular,Palnanar/Chest, Abdoninal,YeuralagicalEtremities

## Findings:

HMTYorplietutSelrietereYigfrtiptrfd

Polnarg/ChedlCorgeeler taseolatin hilatirallYoheneeoreraelee.

Abdenial:Sft on-tander,nen-diteadeadBove souds are sermal.Yoabdeninal bruit

<!-- image -->

DateofVisit:06/21/2025

AttendingProvider:Dr.EmilyCarter,MD

Location:GeneralInternal Medicine Clinic

VisitID:ENC-987654321