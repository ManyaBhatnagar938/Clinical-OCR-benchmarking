Name:Carlos M.Rivera

Age:35

Attend Dr:Dr.Amara O.Diallo

Acct#:38664-G

Sex:M

Location:ClinicA

Date:01/30/2026

DOB:09/14/1990

SPEC#:S-2026-01-30-033

COLLECTEDTIME:09:00

STATUS:FINAL

ENTERTIME:09:00

REPORTTIME:11:45

REQ#:R-38664

ORDERTIME:08:45

| Test  Result  Flag  Reference  Site  WBC  6.4 x10/μL  4.5-11.0  CA  REC  5.10 x10%/μL  4.50-5.90  CA  HGB  15.2 g/dL  13.5-17.5  CA  HCT  45.8 %  41.0-53.0  CA  MCV  89.8fL  80.0-100.0  CA  MCH  29.8 pg  27.0-33.0  CA  MCHC  33.2 g/dL  32.0-36.0  CA  PLT  258 x10/μL  150-400  CA   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|