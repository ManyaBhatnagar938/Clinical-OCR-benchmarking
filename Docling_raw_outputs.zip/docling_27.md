<!-- image -->

MapleValleyDigestiveHealthClinic 55GreenMountainWayBurlington,VT 05401

Phone:(802)555-6789

Fax:(802)555-6790

ProcedureDate:June21,2025

You have undergone a colonoscopy with sedation.The medicationyoureceivedwill impairyourjudgment andreflexes fortheremainderoftheday.Foryoursafety,aresponsibleadult isrequiredtodriveyouhomeandmonitoryou.

Forthenext24hours,youmustnotdriveacar,operate machinery,ormakeanyimportantlegalorfinancialdecisions. Pleaserestathomefortherestoftoday.You mayresumeyour normalscheduletomorrow.Itisnormaltofeel bloatedorhave gaspains;walkingmayhelprelievethis.

## Impressions:

Normal Colonoscopy:Theendoscopewas advancedwithout difficultyto thececum,whichwas identified bythe appendiceal orifice.The bowel preparation was adequate fora completemucosal evaluation.Theentirevisualizedcolonwasfound tobenormal,withnopolyps,inflammation,orother lesionsidentified.

alcoholicbeveragesfor24hours.

Follow-Up:Since this screening examinationwasnormal,your next routine colonoscopy is due in10 years.Nobiopsiesweretaken.

WarningSigns:Please contactouroffice fornon-urgentquestions.Gotothenearestemergencyroom if youdevelopsevere abdominal pain,a feverover101F,chills,orsignificantrectalbleeding.

Thisdocumentcontainsconfidentialpatientinformationprotected underapplicableprivacy laws, includingtheHealth InsurancePortability and AccountabilityAct(HiPAA).

- (a) Normal Colon

<!-- image -->

(b) Colon

<!-- image -->