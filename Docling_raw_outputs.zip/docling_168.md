<!-- image -->

## Surgical Pre-OperativeAssessment

| Patient Name:Kenneth J.Harrington  DateofBirth:09/30/1950  Proposed Procedure:  Surgeon/Department:  Percutaneouscoronaryintervention-RCAstent  Dr.GregoryT.Sullivan,MD-Interventional Cardiology  placement   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/Labs  Test  Result  Test  Result  Test  Result  WBC:  7.4  Hgb:  12.6  Hct:  38.0  Na:  139  K:  4.5  Glucose:  106  PT:  13.0  INR:  1.1  PTT:  30   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;Pulmonary RiskAssessment  [X]Hxof Myocardial Infarction  []CongestiveHeart Failure  []Arrhythmia/Pacemaker  [X]Hypertension  [X]COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []OtherCardiacHistory:   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  PreviousAnesthesia Issues:[X] No[] Yes  FamilyHxMalignantHyperthermia:[X]No[]Yes  MallampatiScore:[]I[X]Il[]ll[]IV  LooseTeeth/Dentures/Caps:[]No[X]Yes  NPO Status(LastMea/Drink):  Weight (kg):  NPO aftermidnight;contrastallergypre-medication  84  (prednisone+diphenhydramine)administeredat  20:00   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

HoldWarfarin;continue aspirinandclopidogrel.Pre-medicatewith steroidsandantihistaminesforcontrast allergy.Partialdenturetoberemovedpre-procedure.

FinalClearance:[X]CLEAREDFORSURGERY[]NOTCLEARED[]PENDINGLABS

Evaluating Clinician Signature: MarCua Q Mel

Date: 02/26/2026