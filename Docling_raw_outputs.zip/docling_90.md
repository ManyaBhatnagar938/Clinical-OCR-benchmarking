<!-- image -->

## Coastal Gastroenterology Institute

200OceanfrontMedicalPlazaCharleston, SC29401

Phone:(843) 555-2000

Fax:(843)555-2001

ProcedureDate:June21,2025

Procedure Findings:

rormafMotaoesamgfey(hopiy/oeyy

Basedorthugnonaf 33 inly a

Follow-UpSchedule:

<!-- image -->

This document contains confidentialpatient informationprotected underapplicableprivacylaws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).