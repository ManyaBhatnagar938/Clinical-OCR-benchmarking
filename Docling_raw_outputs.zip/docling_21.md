PatientName:DanielWilliamsMRN:2345678

<!-- image -->

## BayfrontMedical Center

750WaterfrontAveTampa,FL 33602

Phone:(813)555-7000

Fax:(813) 555-7001

## PATHOLOGYREPORT

831676002937

<!-- image -->

AccessionNumber:S25-11223

DateofCollection:06/20/2025

TimeofCollection:11:30AM

Specimen Type:Stomach Mass,Partial Gastrectomy

## Final Diagnosis:

STOMACH,PARTIALGASTRECTOMY:

GASTROINTESTINALSTROMALTUMOR(GIST),SPINDLECELLTYPE.

Tumorsize:6.5cm.

Mitotic rate: 8 mitoses per 5 mm².

Risk of Progression:High.

Surgicalmarginsarenegativefortumor.

## Microscopic Description:

Sectionsshowa well-circumscribed butunencapsulated tumor composed of intersectingfasciclesof uniformspindlecellswith eosinophilic cytoplasm andovoidnuclei.There ismild tomoderatenuclear atypia.The mitotic activity is brisk, counting up to 8 mitoses per 5 mm². Necrosis is notidentified.

## Gross Description:

Received fresh,labeled with patient's name and"partial gastrectomy,"is a 12.0x8.0x5.0 cm portion ofstomach.Arisingfromthegastricwallisawell-circumscribed,fleshy,tan-whitesubmucosal mass measuring6.5x5.8 x5.5 cm.The tumor is 0.4 cm from the nearest surgical margin.The overlying mucosa isintact.

## Comments:

The combination of tumor size (6.5 cm) and high mitotic rate (8/5 mm²) places this Gastrointestinal Stromal Tumor(GisT) in thehigh-risk categoryforprogressive disease.lmmunohistochemical studies confirm the diagnosis, and moleculartesting results are pending.

## Biomarkers:

Immunohistochemistry:

- CD117(c-kit):Positive(strongand diffuse)

DOG1:Positive(strongand diffuse)

CD34:Positive

- c-kit(KiT)GeneMutationAnalysis:Positive formutation inExon11.

DateofBirth:10/05/1960

Age:64

Gender:Male

PatientAddress:123Palm Tree Ct,

Tampa,FL33605

OrderingPhysician:Dr.Jessica

Martinez, MD

Practice:Gulf Coast Surgical

Oncology

Address:760MedicalTower,

Tampa,FL 33602

Phone:(813) 555-7050