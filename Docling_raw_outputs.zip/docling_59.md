<!-- image -->

To: Dr. Angela Desai, Pulmonology

Facility:Clear Lung &amp; Sleep Center

Fax: (555) 789-0011

Phone:(555) 789-0012

Re:Consult for Patient:DAVIS,Brenda

From:Dr. 0scar Holloway, MD

Facility: Ridgemont Family Medicine

Fax:(555) 567-1122

Phone:(555) 567-1123

Date:June 25,2025

Time:11:28AM

Pages:1 (including cover)

## Notes:

Dear Dr.Desai,

Iam referring my patient,Brenda Davis（D0B:07/19/1978),for evaluationofapersistentdrycough.

Ms.Davis was diagnosed with influenza A seven weeks ago.While her other symptoms have resolved,she is left with a severe,nonproductivecough that disruptsher sleep.

Iwould appreciateyour further evaluation for possiblepost-viral bronchial hyperreactivity.

Thankyou foryour time and consultation.

The informationcontained in thisfacsimile message islegallyprivileged and confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.lf thereaderof thismessage isnotthe intended recipient,you arehereby prohibited.lfyouhavereceived thistelecopyinerror,pleaseimmediatelynotifyus by telephone and return theoriginal message to us atthe address abovevia theU.s. Postal Service.Thank you.

<!-- image -->

## FAX