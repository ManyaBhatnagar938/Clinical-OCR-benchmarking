## Accession#:C123456-25

<!-- image -->

## CT Head WithoutContrast

Procedure:Computed tomographyofthe head withoutintravenous contrast.

Clinical Indication: Sudden onset of severe headache,rule outintracranial hemorrhage.

BrainParenchyma:Thereisnoevidenceofacuteterritorialinfarct,masseffect,ormidlineshift.No abnormaldensitiesareseentosuggestacute intracranialhemorrhage.Thegray-whitematter differentiationispreserved.Basalgangliaandthalami appearunremarkable.

VentricularSystem and Cisterns:Theventricularsystem isnormalinsizeand configurationforthe patient'sage.Thebasalcisternsareclear.

Osseous and Soft Tissues:The calvarium isintactwithnoevidence of acutefracture.Theparanasal sinuses and mastoid air cellsareclear.Thevisualizedportionsof theorbits andsofttissuesof the scalpareunremarkable.

## Impression:

Negative foracute intracranialhemorrhage.No CT evidenceof other acute intracranial abnormality.

## Scheduled appointments:

Follow-upscheduledwiththeNeurologyClinicforfurtherevaluationofheadache.Appointmentwith Dr.Milleron06/27/2025at9:00AM.

DateofDictation:06/20/2025

Technician:JenniferDavis,RT(R)(CT)

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotected byfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom itis addressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction takeninrelianceonthecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704

Lakeside General Hospital 100 Hospital Way RiverCity,USA67890 MetroRadiology Associates

Phone:(555)234-5678

Fax:(555)234-5679

Patient:David Lee

DOB:10/25/1958

MRN:987654

Gender:Male

ReferringPhysician:Dr.Susan

Cho

## Visit#:789-123DateofVisit:06/20/2025