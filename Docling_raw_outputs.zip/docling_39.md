PavilionforWomen&amp;ChildrenatMetroHealth101HealthwayDrive,Denver,CO80204

Patient:JessicaWilliamsMRN:246810D0B:07/19/1993

## ChiefComplaint

First-trimestervaginal spottingforone day.

## CareTeam

AttendingPhysician:Dr.OliviaMartinez,MD,FACOGPager:(303)555-7811

## Pharmacies

KingSoopersPharmacy350N MainSt,Denver,CO80205Phone:(303)555-1234

T:98.7°F

HR: 88 bpm

BP: 118/75 mmHg

RR:16breaths/min

## Vital sign

02Sat:99%onro0m air

## Allergies

## Medications

Codeine-Nausea/Vomiting

- 。 Prenatal Vitaminonetabletbymouthdaily

## Vaccines

- Influenza-11/01/2024
- Tdap-01/15/2025
- COVID-19 Vaccine(series complete)

## Problems

- IntrauterinePregnancy,9weeksgestationbyLMP

## FamilyHistory

- Vaginal SpottinginPregnancy

Mother:History of hypothyroidism.

Father:Historyof hypertension.

No family history of birth defects orgenetic disorders.

## Social History

Tobacco:Denies

Alcohol:Denies use since learningof pregnancy.

Occupation:High school teacher.Married.Lives with husband.