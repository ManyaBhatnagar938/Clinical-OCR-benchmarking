Name:Patricia H.Simmons

Age:60

Attend Dr:Dr.Elena Vasquez

Acct#:88234-A

Sex:F

Location:Main Campus

Date:04/22/2026

DOB:07/22/1965

SPEC#:S-2026-04-22-001

COLLECTEDTIME:07:15

STATUS:FINAL

ENTERTIME:07:15

REPORTTIME:10:45

REQ#:R-88234

ORDERTIME:07:00

| Test  Result  Flag  Reference  Site  WBC  7.2 x10/μL  4.5-11.0  MC  REC  4.55x10°/μL  4.00-5.20  MC  HGB  13.8g/dL  12.0-16.0  MC  HCT  41.2%  36.0-46.0  MC  MCV  90.5fL  80.0-100.0  MC  MCH  30.3pg  27.0-33.0  MC  MCHC  33.5 g/dL  32.0-36.0  MC  PLT  225x10/μL  150-400  MC   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|