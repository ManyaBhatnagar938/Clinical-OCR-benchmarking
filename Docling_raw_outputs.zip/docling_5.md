<!-- image -->

<!-- image -->

Patient Name:Jane Doe

OrderingPhysician:Dr.Sarah

DateofBirth:08/15/1967

Jenkins

MRN:789012

DateofService:06/15/2025

Accession #:S25-12345

DateofReport:06/20/2025

Clinical Information:58-year-oldfemalewith a non-painful,pigmented lesionon theleft cheek.The lesionhasbeenpresentforapproximatelyoneyear,witharecentslightincreaseinsize.Clinical concernfor atypical nevus vs.seborrheickeratosis.

## PathologyFindings:

Gross Description:Received in formalin,labeled with the patient's name and"left cheek,is a single shavebiopsyof skinmeasuring0.5x0.4x0.2cm.The specimenisatan-brown,slightlyverrucous papule. The deep margin is inked black. The specimen is bisected and submitted entirely in one cassette.

MicroscopicDescription:Microscopic examination reveals an exophyticproliferation of benign basaloidkeratinocytes.Thearchitectureshowsprominentacanthosis,papillomatosis,and the formation of numerouskeratin-filled invaginations andhornpseudocysts.Thebasaloid cells are uniform in appearancewithsmall,regularnuclei and nosignificantmitoticactivityorpleomorphism. Withintheunderlyingdermis,thereisamild,patchy,perivascularinfiltratecomposedof lymphocytes and occasional eosinophils.The deepandperipheral margins are free of the lesion.No evidence of dysplasia ormalignancyisidentified.

Diagnosis:Skin,leftcheek,shavebiopsy:Seborrheickeratosis,irritated.

Comment:The histologicfeatures are characteristicofanirritatedseborrheickeratosis.The irritation correspondstothemild dermalinflammationseen microscopically.Clinical correlation is recommended.

Specimen:Onepieceofskin fromtheleftcheek,measuring 0.5x0.4x0.2cm.

Pathologist:Dr.JamesPeterson

Report status:Final