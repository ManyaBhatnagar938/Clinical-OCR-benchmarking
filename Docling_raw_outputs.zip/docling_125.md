<!-- image -->

To:.RhardSa.r Mophrelee

Facility:Kchey eoXfuciatas

Fax: (5.5.5) 717-8181

Phone: (555)717-8182

Re:Nophdeaynutt:BxfKFRXden

From:DMerieFlora.FhtonelMeckcine

Facility: Sane rt elel ee

Fax: (5.5.5)616-7171

Phone: (55.5)616-7172

Date:  25.2025

Time: 11:32 xf

Pages: / (ncludlng cver)

Notes:

<!-- image -->

<!-- image -->

TonforngXfenBao(DB:0812111955)taegur patueforeletuny horworng chreriokicproy kocw

ym rmeinskfficatftecere

<!-- image -->

The informationcontained in thisfacsimilemessageis legallyprivileged and confidentialinformationintendedonlyfortheuseof theindividualorentitynamed above.lf thereaderof thismessageisnottheintendedrecipient,youarehereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.Ifyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by telephone and return theoriginal message to us attheaddressabovevia theU.s. PostalService.Thankyou.

<!-- image -->

## FAX