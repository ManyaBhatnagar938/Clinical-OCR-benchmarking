<!-- image -->

April22,2026

| SECTION A:Medical History  Yes  No  Essential Hypertension(ICD-10:110)  X  Type2DiabetesMellitus(ICD-10:E11.9)  X  Hyperlipidemia(ICD-10:E78.5)  X  ChronicKidneyDisease Stage3(ICD-10:N18.3)  X  PeripheralArteryDisease(ICD-10:173.9)  X  ObstructiveSleepApnea(ICD-10:G47.33)  X   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  Lisinopril 20mg—once daily  X  MetforminHCl10o0mg-twicedailywithmeals  X  Atorvastatin80mg—oncedaily(PM)  X  Furosemide 40mg-once daily(AM)  X  Aspirin81mgEC-oncedaily  X  Carvedilol12.5mg-twicedailywithmeals   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

JameaMRitJield

James Whitfield

Patientsignature

Printname

<!-- image -->

Patient:JamesA. Whitfield

DOB:06/12/1958

MRN:004-738-21