PatientName:EdwardJ.WilliamsMRN:86753091

<!-- image -->

## DesertBloom Gastroenterology

123SonoranHealthCircle,SuiteB Phoenix,AZ85004

Phone:(602)555-7000

Fax:(602)555-7001

ProcedureDate:June21,2025

You have undergone a colonoscopywith intravenoussedation. Themedicationwill remaininyoursystemforseveral hours, affectingyourjudgment and physical coordination.For this reason,youmustbeescortedhomebyaresponsibleadultwho canalsostaywithyou.

Forthenext24hours,yoursafetydependsonfollowingthese rules:

Do notdrive a caroroperateanytypeofmachinery.Yourreaction timeisslowed,makingtheseactivitiesdangerous.

<!-- image -->

Do notconsume any alcoholicbeverages.Alcohol can have an adverseinteractionwiththesedativesyouweregiven.

Do not make anyimportant decisions or sign any legally binding papers.

Restandrelaxfortheremainderoftheday.Youcanreturntoyour normalroutinetomorrow.

Itiscommontofeelbloated andexperiencegasormildcramping aftertheprocedure.This isnormal and shouldresolveasyou passthe airthatwas used duringthe exam.Walkingcanhelp this process.You may startwith clear liquids and lightfoods(like souportoast) and advancetoyourregulardietasyoufeel comfortable.

## Impressions:

Normal Colonoscopy:A complete and successful examinationof the entire colonwasperformed,with the tipof theendoscopereachingthececum.Thebowelpreparation was excellent.The colonic mucosa appeared healthy andnormal throughout.Aretroflexionviewin therectum was alsonormal. Therewasno evidenceofpolyps,diverticulosis,orinflammation.

Findings:Theresults of your examination are normal.No tissue samples or biopsies were required.

Follow-Up:Werecommendrepeatingthisscreeningexamin10years,orsoonerif newsymptoms arise.

Communication:A copyof thisreportwill besenttoyourprimarycarephysician,Dr.Angela Chu.

WhentoSeekCare:Whilecomplications areveryrare,pleasego to thenearestemergency departmentifyoudevelopsevereabdominalpain,afever,significantrectalbleeding,orpersistent vomiting.

This document contains confidentialpatientinformationprotected underapplicableprivacy laws, includingtheHealth InsurancePortabilityandAccountabilityAct(HiPAA).

(a) Normal Colon

(b) Colon

<!-- image -->