<!-- image -->

HOSPITAL

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  11/05/1945  MRN-012501  Robert T.Nakamura  Gender:[X]M[]F[]Other  PhoneNumber:(832) 555-0891  Today'sDate:04/01/2026   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(°F)  SpO2(%)  Weight(b)  Height(in)  158/92  84  18  97.8  94  210  68   |
|------------------------------------------------------------------------------------------------------------------------------|

| Medical History  []Hypertension  [] Diabetes (Type l)  [X] Diabetes (Type Il)]  []Asthma  [X]COPD  [X] Heart Disease  [X]High Cholesterol  []ThyroidDisorder  []Arthritis  []Cancer  []Depression/Anxiety  []Other:   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  5mg  Once daily (PM)  Warfarin  Tiotropiuminhaler  18mcg  +  Once daily  Digoxin  0.125mg  Once daily(AM)  Metformin  500mg  Twicedaily   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Aspirin  Glbleedingrisk  Morphine  Extremenausea   |
|----------------------------------------------------------------------------------------|

## Reason for Visit

COPD exacerbation follow-up.SpO2 trending low at 94%.Patient reports increased dyspnea on exertion over past week.

Date: 04/01/2026

ProviderSignature:JamesR.Sullivan