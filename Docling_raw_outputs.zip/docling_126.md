<!-- image -->

FAX

<!-- image -->

<!-- image -->

Theinformationcontainedinthisfacsimilemessageislegallyprivileged and confidentialinformation intendedonlyfortheuseof theindividualorentitynamed above.If thereaderofthismessageisnotthe intendedrecipient,you arehereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.Ifyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by telephone andreturntheoriginal messageto us atthe address abovevia the U.s. PostalService.Thankyou.