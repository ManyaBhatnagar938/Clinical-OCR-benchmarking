<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name: Sandra K.Okafor  Date ofBirth:08/19/1980  Proposed Procedure:  Surgeon/Department:  Dr.AlanP.Wright,MD-GeneralSurgery  Laparoscopic appendectomy(urgent)   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/ Labs  Test  Result  Test  Result  Test  Result  WBC:  16.8H  Hgb:  12.0  Hct:  36.2  Na:  136  K:  3.8  Glucose:  102  PT:  12.2  INR:  1.0  PTT:  26   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular &amp;Pulmonary Risk Assessment  []HxofMyocardialInfarction  []Congestive Heart Failure  []Arrhythmia/Pacemaker  []Hypertension  []COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []OtherCardiacHistory:   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  FamilyHxMalignant Hyperthermia:[X] No[]Yes  PreviousAnesthesia Issues:[X] No[]Yes  LooseTeeth/Dentures/ Caps:[X]No[]Yes  MallampatiScore:[×]l []ll [] []V  Weight(kg):  NPOStatus(LastMea/Drink):  Urgentcase—lastoral intake5hoursprior(liquids  64  only)   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

Urgent case.AdministerIVmethylprednisolone 40mgintra-opforadrenal suppressioncoverage.Hold Prednisone post-op;resume persurgical team.

Date: 04/01/2 2026