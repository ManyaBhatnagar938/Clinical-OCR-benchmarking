<!-- image -->

<!-- image -->

| PatientName:SusanWalker  Ordering Physician:Dr.James  DateofBirth:05/20/1980  O'Connell  MRN:890123  Procedure:Ultrasound-guided  Accession #:CY-25-77890  Fine-Needle Aspiration(FNA)of  DateofProcedure:06/23/2025  Thyroid Nodule  DateofReport:06/25/2025   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Clinical History:45-year-oldfemalewith a2.5cmsolid,hypoechoicnodule intheright lobeof the thyroid,discoveredonultrasound.

Diagnosis:Thyroid,Right Lobe,Fine-Needle Aspiration:Suspiciousfor Malignancy(Bethesda Category V).

SpecimenAdequacy:Thespecimenis adequateforevaluation.

MicroscopicDescription:The aspirateis cellularand shows crowded clusters of follicular cellswith a microfolliculararchitecture.Thecellsexhibitnuclearenlargement,chromatinpallor,andirregular Carcinoma.

BethesdaSystemforReportingThyroid Cytopathology,surgicalexcisionisrecommended fordefinitive diagnosis.

Specimen:Fine-Needle

Pathologist:Dr.Katherine Reed

Aspiration(FNA)of right thyroid nodule

Report status:Final