Date:03/28/2026

Patient:SophiaA.Martinez

Therapist Names: Ms.Keisha Brown,BCBA

## DAILY REPORT

- [ ] AnxiousCalm/ContentFrustrated

- [x] Cup

- [ ] AngryCheerful /HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

Came With

- [x] Jacket

- [ ] Loving

- [x] Lunch Box

- [ ] Other

## AGGRESSION

## STEMMING

## NONCOMPLIANCE

## OTHER

- [ ] Hitting

- [x] Thumb Sucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [ ] Flopping

- [ ] Hand Flapping

Touching

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [ ] Repeating

- [ ] Climbing

- [ ] Preservative Manding

- [ ] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Sophia ateherentirelunchand attemptedtoshareherapplesliceswithapeer.Usedforkindependently throughout the meal.

## JNCH

Targets Hit During Lunch:

Peer interaction targets(+5/5).Waiting without protest (+4/5). Spontaneous vocalizations (+6 unpromptedinstances).

Today'sStrugglesandStrengths:

GROUP SOCIAL

time-anewmilestone.