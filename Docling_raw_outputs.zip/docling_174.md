Name:David P.Kowalski

Age:64

Attend Dr:Dr.Carolyn T.Nash

Acct#:23417-E

Sex:M

Location:Cardiology

Date:03/25/2026

DOB:02/07/1962

SPEC#:S-2026-03-25-055

COLLECTEDTIME:07:45

STATUS:FINAL

ENTERTIME:07:45

REPORTTIME:10:30

REQ#:R-23417

ORDERTIME:07:30

| Test  Result  Flag  Reference  Site  WBC  8.8x10/μL  4.5-11.0  CARD  REC  4.42 x10%/μL  4.00-5.20  CARD  HGB  13.5 g/dL  13.5-17.5  CARD  HCT  40.8%  41.0-53.0  CARD  MCV  92.3fL  80.0-100.0  CARD  MCH  30.5pg  27.0-33.0  CARD  MCHC  33.1 g/dL  32.0-36.0  CARD  PLT  195 x10/μL  150-400  CARD   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|