PatientName:JaneDoeMRN:987654321

<!-- image -->

## University Medical Center

123HealthSciencesDrive Metropolis,USA12345

Phone:(123)456-7890

Fax:(123)456-7891

## PATHOLOGYREPORT

831676002937

<!-- image -->

Ordering Physician:Dr.John

DateofCollection:2025-06-15

Smith,MD Clinical Practice：

TimeofCollection:09:30AM

MetropolisOncology

SpecimenType:Tissue biopsy,leftbreast

AssociatesAddress:456

Clinical History:Palpablelumpin theupperouterquadrantof theleft breast.Mammogramandultrasoundfindingsaresuspiciousfor malignancy.

CancerCarePlaza,

Metropolis,USA12345

Phone:(123)555-0123

## Gross Description:

Thespecimenisreceived informalin,labeledwith thepatient'sname and medicalrecordnumber,and designated"leftbreastcorebiopsy."Itconsistsof three tan-white,cylindrical tissuefragments, ranginginlengthfrom1.2cmto1.5cm and indiameterfrom0.2cmto0.3cm.Theentirespecimenis submittedinone cassette.

## Microscopic Description:

Histologicsectionsreveal cores of breast tissue with an infiltrative neoplasm.The tumor cells are arranged in irregularnests and single files,infiltratingthe fibrousstroma.Theneoplasticcells are pleomorphicwith enlarged,hyperchromaticnucleiandprominentnucleoli.Mitoticfiguresare frequentlyidentified.Thereisassociatedductalcarcinomainsitu(DciS),solid type,withhigh-grade nuclearfeatures.Noevidenceof lymphovascularinvasionisidentifiedinthesubmittedmaterial.

## Diagnosis:

InvasiveDuctal Carcinoma,Grade3of3.

## Comments:

Thehistomorphologicfeatures are thoseofahigh-gradeinvasiveductal carcinoma.Correlationwith imagingfindings and clinical presentation is recommended.Further evaluation forhormonereceptor status and HER2/neuexpressionispendingandwill bereported in an addendum.

## Biomarkers:

| Biomarker  Result  Interpretation  Estrogen Receptor(ER)  Pending  Progesterone Receptor(PR)  Pending  HER2/neu  Pending   |
|----------------------------------------------------------------------------------------------------------------------------|

Patient Name:Jane Doe

PatientID:987654321

DateofBirth:1970-05-15

Gender:Female

AccessionNumber:P25-12345