Accession #:M789012-25

<!-- image -->

TheRoseWomen'sImaging Center 555HealthPlaza,Suite100 OakBrook,IL60523

Phone:(630)555-1000

Fax:(630)555-1001

Patient:SusanWalker

DOB:02/11/1973

MRN:246801

Gender:Female

Referring Physician:Dr.Brenda

Holloway

## Visit#:357-913DateofVisit:06/20/2025

## ScreeningMammogramReport

Procedure:Bilateral digital mammography with computer-aided detection, craniocaudal and mediolateralobliqueviews.

Clinical Indication:Routine annual screening.

<!-- image -->

<!-- image -->

Impression:

<!-- image -->

## Scheduled appointments:

Recommendation for diagnostic mammogram with spot compression views and a targeted ultrasound of theleftbreast.Ourofficehascontacted thepatienttoschedule thisfollow-up examination.

DateofDictation:06/20/2025

Radiologist:Dr.MarkReynolds,MD

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhomitisaddressed.lfyou are taken inrelianceon the contentsof these documents isstrictlyprohibited.lf you havereceived this reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitallmagingDepartment|123HealthWay,Springfield,IL,62704