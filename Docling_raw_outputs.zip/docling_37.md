MercyGeneralHospital1500MercyLane,Austin,TX78701Phone:（512)555-3400

Patient:EleanorVanceMRN:334561DoB:09/01/1945

## Chief Complaint

Evaluation aftera fall athome thismorning.Complainsof lefthippain.

## CareTeam

AttendingPhysician:Dr.Samuel Peterson,MDPager:(512)555-3422

## Pharmacies

## Vital sign

WalgreensMail OrderPhone:(800)555-1212

T:98.6F

HR:82bpm

BP:150/85mmHg

RR:16breaths/min

02Sat:97%onroomair

## Allergies

Sulfa drugs(Sulfamethoxazole)-Anaphylaxis

## Medications

- Amlodipine 5mg daily
- Atorvastatin20mgdaily
- Alendronate70mgweekly
- Calcium+VitaminD600mg/400lutablettwicedaily

## Vaccines

- High-Dose Influenza-10/02/2024
- Shingrix(2doses)-Completed05/18/2023
- Pneumovax23-09/10/2020

## Problems

- Osteoporosis
- Osteoarthritis
- Hypertension
- GaitInstability

## FamilyHistory

## Social History

Mother:Died atage88fromcomplicationsofa hipfracture.

Sister:Historyofosteoporosis.

Tobacco:Quit 40yearsago.

Alcohol:Rare.

LivingSituation:Widowed, lives alone ina single-story house.Uses a caneforambulation.