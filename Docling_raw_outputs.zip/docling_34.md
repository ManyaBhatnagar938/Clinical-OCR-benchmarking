<!-- image -->

## Chief Complaints:

DateofVisit:06/21/2025

AttendingProvider:Dr.LindaHarris,MD,FAAP

Location:LakesidePediatrics Clinic

VisitID:ENC-PEDS-2025-112

## DateofBirth:05/05/2019Age:6Sex:Female Address:345ElmStreet,Riverdale,USA23456

## Medical History Snapshot:

- Sorethroatfortwodays

PastMedical History:None

- Feverup to102.5F

SurgicalHistory:None

- Headache

Immunizations:Up-to-date

- Decreased appetite

Allergies:NoKnown DrugAllergies

## VisitSummary:

Sophiais a6-year-oldfemalewhopresentswith a two-dayhistoryof sore throatandfever.Themother reports the patient has alsohad a headache andpoor appetite but denies coughor rhinorrhea. Examination wassignificant for tonsillar exudates and tender anteriorcervical lymphadenopathy.A rapid in-officeGroupAStreptestwasperformed and resultedpositive.Basedonthefindings,a diagnosis of Streptococcal Pharyngitiswas made.AprescriptionforAmoxicillin wasprovided,and the importanceofcompletingthefullcourseoftherapywasemphasized to themother.Returntoschool guidelines and supportive care measures were also discussed.

## Exams:

Vitals, General , HEENT, Neck, Lungs

## Findings:

Vitals:Temp:101.8°F,HR: 110,RR:20,SpO2:99% on r00m air.

General:Alert and cooperative,appears uncomfortablebut non-toxic.

HEENT:Oropharynx is erythematouswith 2+tonsillar swelling,white exudates,andpalatal petechiae.

Tympanicmembranes are clear.

Neck:Tender anterior cervical lymphadenopathypresentbilaterally.

Lungs:Clearto auscultationbilaterallywith nowheezes or crackles.