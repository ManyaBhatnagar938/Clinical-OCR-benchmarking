Patient:OliverS.Patel

TherapistNames:Mr.DavidOsei, RBT /Ms.Keisha Brown,BCBA

## DAILY REPORT

- [ ] AnxiousCalm/ContentFrustrated

- [ ] Cup

- [ ] Angry  Cheerful / Happy  Grumpy

- [x] Backpack

MOOD AFFECT

- [ ] Annoyed EnergeticTired

Came With

- [ ] Jacket

- [ ] Loving

- [x] LunchBox

- [ ] Other

## AGGRESSION

## STEMMING

## NONCOMPLIANCE

## OTHER

- [ ] Hitting

- [ ] Thumb Sucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [x] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [x] Flopping

- [ ] Hand Flapping

Touching

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [x] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [ ] Repeating

- [ ] Climbing

- [x] Preservative Manding

- [x] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [x] Biting

- [x] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Oliverrefused all fooditems initially.Acceptedpreferredcrackers aftera15-minute motivating assessment.Ate approximately40%of lunch.Nobitingincidents during themealitself.

## LUNCH TIME

TargetsHit During Lunch:

Manding appropriately (+2/5——dysregulated).Requesting break(+3/5——improved from last session). Following1-stepinstructions(1/5).

## Today'sStrugglesandStrengths:

GROUP SOCIAL

Challenging session; two biting incidents in AM. De-escalation strategies applied successfully both times. Strength:compliedwithpreferredtransitiontoplaygroundwithoutelopement.