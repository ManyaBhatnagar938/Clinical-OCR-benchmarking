<!-- image -->

## DateofBirth:10/30/195

DateofVisit:06/21/2025

AttendingProvider:Dr.SarahJenkins,MD

Location:Orthopedic&amp;SportsMedicineCenter

VisitID:ENC-A4B3C2D1

Age:7

## Address:789Pu85431

## Chief Complaints:

- Werserina chronic ricktknee s
- Merin tilhes
- Aiheata walina and combin tairs
- Aiscusion o surical tions

## VisitSummary:

Mr.Andersen is a7-uearcl mele oresertinalfe-uo oerere rikt knee ostecrthritis. He reocrtsa srceresive worserna inevertheosxmethickhe noratesasan/1sitactiu.The siniintla imnts his mebitothisittamrethnsinceblockndeentitbsissleeHehsetachieve releecnervatetretmeticdinacrse hsathertandacrteterdnetonadmntered mortks sricrRecet kneeX-raus cenhirm severe medi/ and satelelemora icnt sonce narrcina. Ater athoraxch discusinteriss.beneandaterntesthe atentexoresedaclerundertandin and desiretooreeeditt sureiiteehsbherieeedreedreetmed cardie clearance.

## Exams:

htals.Gnrdiovkseuler.Musclosheletal -Riebt Knee.Cat &amp;taten

## Findings:

htals: bP134 178 mmMte. Rele 7 2 hom. R 16. Tem 48.4.

Cardiolaseular: Recalar rale and rhatm. Hital xses are trone and ecual in hatt laver extrenities. Museuloskeletal - Rickt Knee:

Rance oMation: Linited active rance olmdtion hom 5 to110 decrees dueto scin.

Inspection: A mil ehsion is sresent.A natable varus dekerntu is chserved. No eratheme or Warmtt. Plation: Plale cress ikh an Hevion or elersion. Poittenderess overthe meil it e.

Gait &amp; Station: The satied dementrates a sicnihiant antaleic cait. hearina mnima/ Weickt on the rickt ec. is wnable to oeckerm a kal seaat.

## Medical History Snapshot:

PinsruHsSekreTretatettsteritke CtehrisTietesMHten terHe Surei/trorr aRer tet hemet(O8)LasroChestet (2005)

MedieatiensMatfmi10OOmedel.LisinlOmedlAosttn4Omsdk Asirn81maokile

Aeres Crodeine (nse ndta)

Sex:Ma