## DAILY REPORT

TherapistNames:Ms.Priya Nair, BCBA

Patient:AvaJ.Robinson

- [ ] AnxiousCalm/ContentFrustrated

- [ ] Cup

- [ ] AngryCheerful /HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] Annoyed EnergeticTired

Came With

- [ ] Jacket

- [ ] Loving

- [x] Lunch Box

- [ ] other

AGGRESSION

STEMMING

## NONCOMPLIANCE

OTHER

- [ ] Hitting

- [ ] Thumb Sucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [x] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [ ] Flopping

- [ ] Hand Flapping

Touching

- [ ] Pushing

- [x] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [x] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [ ] Scratching

- [ ] Repeating

- [ ] Climbing

- [ ] PreservativeManding

- [ ] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

Eating Report:

Ava ate lunchin thequiet corner with reducedstimulation.Finishedyogurt andcrackers.Refused sandwichdespitepreferredcondimentoffered.

UNCH IME

Targets Hit During Lunch:

Tolerating group settings (+2/5 -- anxiety elevated today). Following visual schedule (+4/5).

Requesting preferred items (+3/5).

## Today'sStrugglesandStrengths:

GROUP SOCIAL

Anxietylevelselevated,possiblyrelated tosubstitutetherapistinmorningslot.Self-regulationimproved significantly aftersensorybreak.Strength:greeted primary therapist spontaneously on arrival.