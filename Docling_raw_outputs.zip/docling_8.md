Patient:JohnSmithDOB:05/20/1965MRN:789012

Accession#:A583920-25

<!-- image -->

Sunrise Diagnostics Phone: North ValleyImaging Center456 OakAvenue,Suite200Anytown, USA12345 (555)123-4567

Patient:JohnSmith

DOB:05/20/1965

MRN:789012

Gender:Male Refering

Physician:Dr.EmilyWhite

## Visit #:456-789Date ofVisit:06/18/2025

## DiagnosticImagingReport-ChestX-ray(2views)

Procedure:Radiography of the chest,posteroanterior and lateral views.

Clinical Indication:Persistentcough and shortnessofbreath.

Findings:Thelungsareclearwithoutevidenceofconsolidation,infiltrate,oreffusion.The cardiomediastinal silhouette iswithin normal limits.Theosseous structuresofthe thoraxare unremarkable.

Impression:No acute cardiopulmonaryprocess.

## Scheduled appointments:

Follow-up appointment with Dr.White scheduled for 06/25/2025 at 11:00AM to discusstheresults and furthermanagement.

Date of Dictation:06/18/2025Technician:SarahJenkins,RT(R)

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom itisaddressed.lfyou are not theintendedrecipient,you areherebynotified thatanydisclosure,copying,distribution,oraction s document.