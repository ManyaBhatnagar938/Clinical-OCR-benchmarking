<!-- image -->

## CitysideGastroenterologyClinic

4500MetroParkwayMetropolis,CA90210 Phone:(310)555-4321

Fax:(310)555-4322

You havehad a colonoscopy under sedation.Because of the medicationyoureceived,itisrequiredthataresponsibleadult drivesyouhomeandstayswithyou.Foryoursafetyoverthenext 24hours,youmustnotdrive,operatemachinery,ormakeany legal decisions.Pleaserest.fortheremainderofthe day.

## Impressions:

Normal Colonoscopy:Theexaminationof the entirecolon,from therectumtothececum,was successfullycompletedandrevealednoabnormalities.Thecolonicmucosawasnormalin appearancethroughout.Nopolyps,masses,orevidenceof inflammationwereidentified.

tolerate it.Donotconsumealcoholicbeveragesforatleast 24 hours.

Activity:You may resumeyour normal activities,includingwork,tomorrow.

Follow-Up:Given the normal findings,yournextscreeningcolonoscopyis due in10years.

WarningSigns:Pleasecontactouroffice orproceedto the nearestemergencyroom ifyou develop severeabdominalpain,significantrectalbleeding,fever,orpersistentnausea.

This document containsconfidential patient informationprotected under applicableprivacy laws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).

(a)Normal Colon

<!-- image -->

(b) Colon

<!-- image -->