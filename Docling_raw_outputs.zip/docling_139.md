<!-- image -->

March25,2026

| SECTION A:Medical History  Yes  No  Post-Myocardial Infarction(ICD-10:125.2)  X  Hypertension(ICD-10:110)  X  Hyperlipidemia(ICD-10:E78.5)  X  Type 2DiabetesMellitus(ICD-10:E11.9)  X  Generalized Anxiety Disorder(ICD-10:F41.1)  X  Gout(ICD-10:M10.9)  X  CKDStage2(ICD-10:N18.2)  X   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:CurrentMedication  Yes  No  Aspirin81mg-once daily  X  Metoprolol Succinate 50 mg —once daily  X  Rosuvastatin20mg—once daily(PM)  X  Ramipril 10mg-oncedaily(AM)  X  Empagliflozin 10 mg—once daily  X   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

David Kowalski

DavidKowalski

Patient signature

Print name

<!-- image -->

Patient:David P.Kowalski

DOB:02/07/1962

MRN:023-417-36