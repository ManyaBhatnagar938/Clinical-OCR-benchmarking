<!-- image -->

## PolysomnographyReport

Procedure:Attended,full-nightdiagnosticpolysomnography.

Clinical Indication:Excessive daytime sleepiness,reported snoring,andwitnessed apneas.

Impression:

<!-- image -->

A follow-up appointment is recommended to discuss treatment options, including positive airwaypressure (PAP)therapy.AsubsequentPAP titration studyunderpolysomnographyis indicated todetermine the optimalpressurefortreatment.

Dateoflnterpretation:06/20/2025

InterpretingPhysician:Dr.SamuelJones,MD,Dipl.ABsm

CONFIDENTIALITYNOTICE:Thisreportcontains confidential patient informationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhomitisaddressed.lfyou are nottheintendedrecipient,youareherebynotified thatanydisclosure,copying,distribution,oraction takeninrelianceonthecontentsofthesedocumentsisstrictlyprohibited.If you havereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704

TheSleepHealthInstitute 400RestfulWay,Suite300 Phoenix,AZ85001

Phone:(602)555-7000

Fax:(602)555-7001

Patient:ElizabethChen

DOB:08/15/1968

MRN:482601

Gender:Female

ReferringPhysician:Dr.Michael

Rivera

Study#:731-004DateofStudy:06/20/2025