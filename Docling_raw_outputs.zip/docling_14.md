## Accession#:PSG20250620-098

<!-- image -->

## PolysomnographyReport

Procedure:Attended,full-nightdiagnosticpolysomnography. Clinical Indication:Excessive daytime sleepiness,reported snoring,andwitnessed apneas.

s minuteswithasleepefficiencyof82%.Sleeparchitecturewasabnormal duetosignificantsleep fragmentation.REMsleepwasreduced,comprisingonly10%oftotal sleeptime.

Frequentrespiratory eventswere noted throughout thenight.The overall Apnea-Hypopnea Index(AHl) was42eventsperhour,whichisinthesevererange.Theseeventswerepredominantlyobstructive apneas and hypopneas,and theyweremoresevereduringREMsleep.Thiswasassociatedwith significantoxygendesaturation,withanadirSpO2of78%.Thepatient'sbaselineoxygensaturation was95%.Nosignificantperiodiclimbmovementswerenoted.

impression:Thefindings are consistent with severe obstructive sleep apnea(OsA).

A follow-up appointment is recommended to discuss treatment options, includingpositive airway pressure(PAP) therapy.A subsequent PAP titration studyunderpolysomnographyisindicated to determinetheoptimalpressurefortreatment.

DateofInterpretation:06/20/2025

InterpretingPhysician:Dr.SamuelJones,MD,Dipl.ABsm

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhom itisaddressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction takeninrelianceonthecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitallmagingDepartment|123HealthWay,Springfield,IL,62704

TheSleepHealthInstitute 400RestfulWay,Suite300 Phoenix,AZ85001

Phone:(602) 555-7000

Fax:(602)555-7001

Patient:Elizabeth Chen

DOB:08/15/1968

MRN:482601

Gender:Female

ReferringPhysician:Dr.Michael

Rivera

## Study#:731-004DateofStudy:06/20/2025