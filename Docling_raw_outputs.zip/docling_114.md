<!-- image -->

## Oakwood Community Clinic

450NorthMainStreet Madison,Wl53703 (608)555-0102

<!-- image -->

<!-- image -->

Patient Name: Ll//

Soreie

MRN 9884021

MRN:9884024

Accession: B-269-25

DOB:/05/4008

Date: 06/ 20/ 2025

Gender\_

Age\_26

Toptat26-arollalwhhtoryp hldhol.Shmpotssasooxarbotrous.topreolly wthosprugodfoll Cnrutmduotosmotoddalyulodteotorddbotro wholorormse uso.whoh honpotssuy8-4tuasperwottdyShho fowllomytodastetsdpllNohatorysot AllorytTtyPosuturtot-trpolloddustts htXAt)looNttte

Sptrdpbdlta)Dditbsttttsttwothoth FEVpumasadbytosktorlotontdnotato

IMPRE8810N:

Modrtprettsthusubptuolytrod bodrturasrsoe whotoruso.

AMllory rhutis