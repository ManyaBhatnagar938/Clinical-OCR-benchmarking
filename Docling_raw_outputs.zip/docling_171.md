Name:Michael B.Torres

Age:67

## Attend Dr:Dr.James R.Allen

Acct#:44712-B

Sex:M

Location:Tower B

Date:03/15/2026

DOB:11/03/1958

SPEC#:S-2026-03-15-044

COLLECTEDTIME:06:30

STATUS:FINAL

ENTERTIME:06:30

REPORTTIME:09:55

REQ#:R-44712

ORDERTIME:06:15

| Test  Result  Flag  Reference  Site  WBC  11.4x10°/μL  H  4.5-11.0  TB  REC  3.80x10/μL  L  4.00-5.20  TB  HGB  11.2 g/dL  L  13.5-17.5  TB  HCT  33.4%  L  41.0-53.0  TB  MCV  87.8fL  80.0-100.0  TB  MCH  29.5pg  27.0-33.0  TB  MCHC  33.5 g/dL  32.0-36.0  TB  PLT  310x10/μL  150-400  TB   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|