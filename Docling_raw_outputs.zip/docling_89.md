PatientName:BrendaK.JohnsonMRN:24681357

<!-- image -->

## UniversityHealth System-Digestive DiseasesCenter

1000AcademicMedical DriveLakeside,MI 48823

Phone:(517)555-8900

Fax:(517)555-8901

ProcedureDate:06/21/2025

## (a)Normal Colon

<!-- image -->

(b) Colon

<!-- image -->

<!-- image -->

Thisdocumentcontainsconfidentialpatientinformationprotected under applicableprivacy laws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).

<!-- image -->