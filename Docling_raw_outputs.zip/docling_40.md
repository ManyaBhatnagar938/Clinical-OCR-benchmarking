BayviewMedicalCenter&amp;NeurologicalInstitute5500OceanfrontAve,SanDiego,CA92109

Patient:DavidChenMRN:778899D0B:03/12/1978

## ChiefComplaint

Sudden onset of severe,"thunderclap"headache that started approximately two hours ago.Rates pain 10/10.

## Care Team

Attending Physician:Dr. Sarah Jenkins, MD Pager: (619) 555-8012

## Pharmacies

CostcoPharmacy8125FletcherPkwy,LaMesa,CA91942Phone:(619)555-4567

T:99.10F

## Vital sign

HR: 95 bpm

BP:165/98mmHg

RR:18breaths/min

02Sat:98%onro0m air

## Allergies

Ciprofloxacin-Tendonitis

## Medications

- Sumatriptan50mg tablet,as needed formigraines

## Vaccines

- Influenza-10/20/2024
- Tdap-06/15/2023
- COVID-19BivalentBo0ster-11/05/2024

## Problems

- SevereHeadache
- History of Migraine with Aura

## Family History

- Hypertension

Mother:Historyofmigraines.

## Social History

MaternalAunt:Diedfromarupturedcerebralaneurysm atage55.

Tobacco:Denies

Alcohol:1-2glassesofwineperweek.

Occupation:SoftwareEngineer,reportshighstress atworkrecently.