<!-- image -->

## NorthviewEye&amp;VisionCenter

1400MountainPassRd. Denver,CO80202 (303)555-1234

PatientName:Susan Miller

MRN:5592381

MRN:5592381

Accession:V25-6678

DOB:05/18/1958

Date:06/23/2025

Gender:Female

Age:67

Thepatientisa67-year-oldfemalewhopresentsforevaluationofagradual, progressive decline in vision in both eyes over the past two years. She reports increasingdifficultywithreadingfineprintandexperiencessignificantglarefrom headlights while driving at night. She denies any eye pain, redness, or discharge. Her lasteye examwasthreeyearsago.

## PROCEDURES:

VisualAcuity(with correction):Right Eye(OD):20/60;Left Eye(OS):20/50. Slit-lamp Examination:Revealed significant nuclear sclerotic and cortical changes in thelenses of both eyes,right greater than left.Cornea and anterior chambersareclear.

Tonometry(IoP):OD:16mmHg;OS:15mmHg

## IMPRESSION:

Bilateral age-related nuclear sclerotic cataracts, visually significant. Presbyopia.

Patient Name:Susan Miller MRN:5592381Age:67

Date:06/23/2025Time:09:12