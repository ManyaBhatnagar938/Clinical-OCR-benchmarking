<!-- image -->

## Coastal GastroenterologyInstitute

200OceanfrontMedical Plaza Charleston, SC29401

Phone:(843) 555-2000

Fax:(843)555-2001

ProcedureDate:June21,2025

You have nowcompletedyourcolonoscopyprocedure,which wasperformedwiththeaidof intravenoussedation.Thesedative medicationsareveryeffectivebuthavelingeringeffectsthatwill impairyourjudgment,motorskills,andmemoryforupto24 hours.Foryourpersonalsafetyandwell-being,itisimperative that you(and your designated escort) carefullyreview and follow thesedetailedpost-procedureinstructions.

## IMMEDIATEPOST-PROCEDURESAFETY(NeXt24HourS)

Theserestrictionsarenotrecommendations;theyaremandatory foryoursafety.

<!-- image -->

Transportation and Escort:Youmust be driven home by a responsible adult.You are strictlyforbiddenfrom drivinga vehicle,operatinga bicycle,ortakingpublictransportation(bus, taxi,rideshare)alone.

ConstantSupervision:Aresponsible adultmustremainwithyou fortheremainderofthedayandovernight.Theeffectsof anesthesiacanincreasetheriskoffalls,confusion,and accidentalinjury.Thisperson'sroleistoassistyou andtoseek medical help should any complications arise.

Restricted Activities:You mustavoid allofthefollowingactivities forafull24hours:

Operatinganymachinery,includingpowertools,kitchen appliances,andlawnequipment.

## Impressions:

NegativeColonoscopy:Successfuland complete colonoscopyto the terminal ileum.Thequalityof the bowelpreparationwas excellent,allowingforfull mucosal visualization.Therewerenopolyps, masses,inflammatorychanges,orotherabnormalitiesnotedthroughoutthecolon.

Procedure Findings:Your colonoscopy was entirely normal.No tissue samples(biopsies) were taken, so therewillbenofollow-uppathologyreport.

Follow-UpSchedule:Based onthesenormalfindings and nationalguidelines,werecommendyou repeata screeningcolonoscopyin10years.

Thisdocumentcontainsconfidentialpatientinformationprotected underapplicableprivacylaws, includingtheHealthInsurancePortabilityand AccountabilityAct(HiPAA).

- (a) Normal Colon

(b) Colon

<!-- image -->