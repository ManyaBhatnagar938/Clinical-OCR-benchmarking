<!-- image -->

DateofVisit:06/21/2025

TimeofVisit:10:30AM

AttendingPhysician:Dr.EmilyCarter,MD

Facility:General Health Clinic

Location:123HealthSt,Anytown,USA12345

## Date of Birth:05/15/1979 Age:46 Gender:Female Contact:(555) 123-4567 Address:456HomeAve,Anytown,UsA 12345

Medical History Snapshot:

## ChiefComplaints:

- Sorethroatforthepastthreedays

Hypertension:Diagnosed in2018,well-controlledwith Lisinopril 10mgdaily.

- Persistentdrycough

- Low-gradefever,upto100.5F (38.1℃)

SeasonalAllergies:Managedwithover-the-counter

antihistaminesasneeded.

- Generalfatigue and bodyaches

Surgical History:Appendectomy(2005).

FamilyHistory:Motherwitha historyof hypertension.Father withahistoryoftype2diabetes.

## VisitSummary:

Thepatientisa46-year-oldfemalewhopresentedtotheclinicwitha three-dayhistoryofsorethroat, dry cough,low-grade fever,and fatigue.She denies any significant shortness of breath,chest pain,r lung sounds bilaterally.Based on the clinical presentation,the patient was diagnosed with anupper patientwasadvised torest,increasefluid intake,anduseover-the-countermedicationsfor symptomaticrelief.Shewas also instructed tofollow up if her symptomsworsen or donotimprove within the next 7-10 days.

## Exams:

Constitutional

Head/Eyes/Ears/Nose/Throat(HEENT)

Respiratory

Cardiovascular

## Findings:

Constitutional:Alert and oriented.Appears fatigued but in no acute distress.Vitals:Temp 100.2°F,BP 128/84mmHg,HR88bpm,RR16breaths/min,Sp0298%onroomair.

HEENT:Head isnormocephalicand atraumatic.Pupilsare equal,round,andreactivetolight.

Tympanic membranes are clear.Nasal mucosa is mildly edematous.Posteriorpharynx is erythematous withnovisibleexudates.Neckissupplewithmild anteriorcervical lymphadenopathy.

Respiratory:Lungs are clear to auscultation bilaterally.No wheezes,rales,orrhonchi.Respiratory effort isnon-labored.

Cardiovascular:Regularrate and rhythm.S1 and S2 are audible.No murmurs,rubs,orgallops.