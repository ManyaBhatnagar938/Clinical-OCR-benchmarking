<!-- image -->

<!-- image -->

| Patient Name: Linda Harris  Ordering Physician: Dr. Sarah  DateofBirth:10/25/1968  Collins  MRN:234567  Procedure:Stereotacticcore  Accession #:SB-25-66778  needlebiopsy,leftbreast  DateofProcedure:06/23/2025  DateofReport:06/25/2025   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Clinical History:56-year-oldfemalewithanew1.2cm clusterofpleomorphicmicrocalcificationsin the leftbreastatthe 10 o'clockposition,identified on screeningmammogram(Bl-RADS 4C).

grade.

GrossDescription:Received informalin,labeled'leftbreastcores，arefivetan-white,firmcore biopsies,ranging from 1.2 cm to 1.5 cm in length.A specimen radiograph confirms the presence of microcalcifications correspondingto the areaof concern.Thecores are submitted entirelyin one cassette.

Microscopic Description:Sections showbreast tissuewith multiple ducts expanded and filled by a monotonouspopulationofatypicalepithelialcells.The architectureispredominantlysolid and cribriform.The cells exhibit moderately enlarged,pleomorphic nuclei with irregular contours.Central necrosis(comedonecrosis) is present within some of theinvolved ducts,associated with psammomatousmicrocalcifications.No evidenceofstromal invasion isidentified in the tissue provided.

Comment: The findings are diagnostic of Ductal Carcinoma in Situ.As this is a core biopsy diagnosis, definitivegradingand assessmentof marginswill beperformed on thesubsequentexcisionspecimen. Radiologic-pathologiccorrelation isrecommended.

Specimen:Left breast core

Pathologist:Dr.AmandaWright

needlebiopsy

Report status: Final