Patient:Ethan C.Brennan

TherapistNames:Mr.David Osei, RBT/Ms.JuliaPark,BCBA

## DAILY REPORT

- [ ] AnxiousCalm/ContentFrustrated

- [ ] Cup

- [ ] AngryCheerful/HappyGrumpy

- [x] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

CameWith

- [ ] Jacket

- [ ] Loving

- [x] LunchBox

- [ ] Other

## AGGRESSION

## STEMMING

## NONCOMPLIANCE

## OTHER

- [x] Hitting

- [ ] Thumb Sucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [ ] Mouthing

- [x] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [x] Flopping

- [ ] Hand Flapping

Touching

- [x] Pushing

- [x] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [x] Verbal Refusal

- [x] Vocal Stereopathy

- [ ] Scratching

- [ ] Repeating

- [ ] Climbing

- [ ] PreservativeManding

- [ ] Pinching

- [ ] Licking

- [ ] Non-responsive

- [ ] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] Inappropriate Dance

- [ ] Spitting

- [ ] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Ethan refused toeatinitially.Accepted preferred crackers after a 10-minute motivating assessment.Ate approximately50%of lunchwithphysicalprompts.

## LUNCH

TargetsHitDuringLunch:

Manding forbreak (+2/5).Tact labels (0/5—highly dysregulated).Following 1-step instructions (1/5).

Today's Struggles and Strengths:

## GROUP OCIAL OS

High aggression in AM session related to schedule change. De-escalation via sensory break was effective. Strength:complied with hand-washing routine independently.