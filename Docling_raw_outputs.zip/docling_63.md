<!-- image -->

To: Dr. Aaron Goldstein, MD, Otolaryngology

Facility:The ENT &amp; Allergy Center

Fax:（555) 303-4040

Phone:(555) 303-4041

Re:Patient Consult:WALKER,David

From:Christine Lee,PA-C

Facility:Westside Family Practice

Fax:(555) 707-6060

Phone:(555) 707-6061

Date:June 25, 2025

Time:11:36 AM

Pages:1 (including cover)

## Notes:

Subject:Referral for Recurrent Sinusitis

Dear Dr.Goldstein,

Iam referring David Walker （D0B:06/15/1990) for evaluation of recurrent acute bacterial sinusitis.

Mr.Walker has experienced four documented episodes requiring antibiotic therapy in the last 12 months.He reports persistent nasal congestion even between acute infections.

Iamreferring him for furtherworkup torule out an underlying anatomicalor chronicinflammatory condition.

Thank you.

The information contained inthisfacsimilemessage islegallyprivileged and confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.lf thereaderof thismessageisnottheintendedrecipient,youarehereby notified that any dissemination,distribution,orcopyingof thistelecopy is strictly prohibited.lf you havereceived thistelecopyinerror,pleaseimmediatelynotifyus by telephone and return the original message to us at the address above via the U.s. Postal Service.Thankyou.

<!-- image -->

## FAX