PatientName:RobertBrownMRN:6543210

<!-- image -->

## NorthStar HealthSystem

450Northland BlvdAurora,CO 80011

Phone: (303) 555-1212 Fax:(303)

555-1213

## PATHOLOGYREPORT

831676002937

<!-- image -->

AccessionNumber:P25-01234

DateofCollection:06/19/2025

TimeofCollection:02:45PM

SpecimenType:Prostate,NeedleCoreBiopsy

## Final Diagnosis:

Prostate,left base:Adenocarcinoma,Gleason Score4+3=7(Grade Group 3)

## Microscopic Description:

Sectionsshowprostatic acinireplaced byinfiltrative,poorly-formed cribriform glands(Gleason pattern 4) and individual discrete glands(Gleason pattern 3).The malignant glands are lined by cells with enlarged nuclei,prominent nucleoli,and scant cytoplasm.Perineural invasion is identified.The

## Gross Description:

Received in formalin labeled"prostate, left base"are four tan-white cylindrical tissue cores,ranging from1.1to1.4cm inlength.All tissuesubmittedinonecassette.

## Comments:

Thefindings areconsistentwithprostaticadenocarcinoma,GleasonScore7.Thepresenceofa dominant Gleason pattern 4 and perineural invasion are adverse prognosticfactors.Correlation with serumPsA levels and clinical stagingisrecommended.

## Biomarkers:

Immunohistochemical stainsforhighmolecularweightcytokeratin(HMwCK) and p63 are negative in themalignantglands,supportingthe diagnosisofadenocarcinoma.Nofurthermolecularbiomarker testingindicatedonthisspecimen.

DateofBirth:03/12/1950

Age:75

Gender:Male

PatientAddress:567Birch Lane,

Aurora,CO80011

OrderingPhysician:Dr.Sarah

Jenkins, MD

Practice:RockyMountainUrology

Address:890WellnessWay,Suite

200,Aurora,CO80012

Phone:(303)555-8800