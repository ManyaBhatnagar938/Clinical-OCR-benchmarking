<!-- image -->

HOSPITAL

| Full Name:  DateofBirth MM/DD/YYYY):  PatientID/MRN:  Sandra K.Okafor  08/19/1980  MRN-019883  Gender:[]M[X]F[]Other  Phone Number:(713)555-1204  Today'sDate:02/14/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(°F)  SpO2(%)  Weight(lb)  Height(in)  124/80  76  15  98.2  98  138  65   |
|-------------------------------------------------------------------------------------------------------------------------------|

| Medical History  [X]Hypertension  []Diabetes(Typel)  [] Diabetes(TypeIl)  []Asthma  []COPD  []Heart Disease  []High Cholesterol  []ThyroidDisorder  [X] Arthritis  []Cancer  []Depression/Anxiety  []Other:   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  Hydroxychloroquine  400mg  Oncedaily  Prednisone  5mg  Once daily(AM)  Amlodipine  5mg  Oncedaily  FerrousSulfate  325mg  Everyotherday   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  NSAIDs  Glupset/renalconcern  Penicillin  Rash   |
|--------------------------------------------------------------------------------------|

## Reason for Visit

Lupus nephritismonitoringvisit.Urinalysis andrenalpanelordered.Patient reports joint pain flareinleft knee this week.

Provider Signature: Prirg S. Mchta

Date: 02/14/ 202l