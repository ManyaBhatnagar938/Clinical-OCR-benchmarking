PatientName:MariaGarciaMRN:4567890

<!-- image -->

## MountainViewMedicalCenter

789Summit LanePine Ridge, USA67890

Phone:(555)345-6789

Fax:(555)345-6790

AccessionNumber:2025-78901

DateofCollection:06/21/2025

TimeofCollection://00-AM

SpecimenType:SlSBua1-

## Final Diagnosis:

DateofBirth:09/10/1985

Age:39

Gender:

PatientAddress:123FDP

RhrNS-A67890

OrderingPhysician:D

MD

PracticeDupAaPRhe

Address2AShCW:PRh

1SA67890

Phone:(555)765-4321

ShinlffMlyoMeMds Beaiemed5meipecepfinaiin

GrossDescription: l

## Comments:

## Biomarkers:

<!-- image -->

Result: Pisfte

Interpretation:BRAF00eFTofyPei BRAFemhefyely

## PATHOLOGYREPORT

831676002937

<!-- image -->