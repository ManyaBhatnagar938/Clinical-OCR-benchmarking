<!-- image -->

## UniversityHealthSystem-Digestive DiseasesCenter

1000AcademicMedicalDriveLakeside,MI 48823

Phone:(517) 555-8900

Fax:(517)555-8901

ProcedureDate:06/21/2025

Youhave undergone acolonoscopytoday.Thesedationyou receivedwillaffectyourcoordinationandjudgmentfortherestof the day.Foryour safety,youmusthave a responsible adult drive youhomeandstaywithyou.Forthenext24hours,donotdrive, operateanyformofmachinery,drinkalcohol,orsignlegal documents.Youshouldrestathomefortheremainderoftheday andcanresumenormalactivitiestomorrow.

## Impressions:

Normal Colonoscopy:Theprocedurewascomplete to the cecum.Bowelpreparationwasexcellent, affordingclearviewsoftheentiremucosalsurface.Thecolonicarchitecturewasnormal,withno evidenceofpolyps,masses,diverticula,orinflammatorychanges.

Diet: You may resume your diet as tolerated. We recommend starting with light foods and liquids and avoidingheavyorgreasymealsforyourfirstmeal.

Activity:Resttoday.You mayreturntoyourusualactivities24 hours afteryourprocedure.

Follow-Up:As the examinationwasnormal,your next routine screening colonoscopyis recommended in 10 years.

Important:Pleaseproceed to thenearestemergencyroom ifyou developsevere abdominalpain,a fever,orsignificantrectal bleeding.

Thisdocumentcontains confidentialpatientinformationprotected underapplicableprivacy laws, including the Health InsurancePortability and Accountability Act (HiPAA).

- (a) Normal Colon

<!-- image -->

(b) Colon

<!-- image -->