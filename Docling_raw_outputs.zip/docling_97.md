<!-- image -->

Date ofVisit:06/2//2025

Attending Provider:Samd Z M

Location: Mlaid Fnl Phae

Visit ID:NCMN

<!-- image -->

Date of Birth:07l0811979

Age:45

Sex:Me

## Address:221BPatCtkSA45459

Chief Complaints:

Medical HistorySnapshot:

AktuePahemsGnealaud Aaxiatyusrge (GAD).Chunic uenie

- FhniltfGenkaud Haius

Sugjial Hfitny Nee

- Mypdiatoe nanagmet

aapdi

icalAh

buat hieag

Exams:

Vt:Cnstatonao.PygchiatieCasdlolas

Findings:

Vhtks A22174 motgPale68 hpm RR14.

Cnitytaeged.mcishedmaleinnone dits

CasdlosulaRgulasaeand het nomaappucikd

<!-- image -->