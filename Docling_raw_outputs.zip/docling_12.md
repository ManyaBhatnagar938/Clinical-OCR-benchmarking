Accession#:M789012-25

<!-- image -->

TheRoseWomen'sImaging Center 555HealthPlaza,Suite100 OakBrook,IL60523

Phone:(630)555-1000

Fax:(630)555-1001

Patient:SusanWalker

DOB:02/11/1973

MRN:246801

Gender:Female

ReferringPhysician:Dr.Brenda

Holloway

Visit#:357-913DateofVisit:06/20/2025

## ScreeningMammogramReport

Procedure:Bilateral digital mammographywith computer-aided detection,craniocaudal and mediolateralobliqueviews.

ClinicalIndication:Routine annualscreening.

Thebreasts areheterogeneouslydense,which mayobscure small masses.

In the upperouterquadrantof the leftbreast,thereisa7mmoval,circumscribed mass.Thisfindingis newwhencomparedto theprior studyfrom06/15/2024.Therearenosuspiciouscalcifications or areasofarchitectural distortion.Therightbreastisunremarkable.

## mpression:

Partiallyobscured7mmoval mass intheupperouterquadrantof the leftbreast,newfromprior.

Bl-RADS Assessment:Category O-Incomplete.Needs additional imagingevaluation.

## Scheduled appointments:

Recommendationfor diagnosticmammogramwithspotcompressionviews and a targetedultrasound of theleftbreast.Ourofficehascontactedthepatienttoschedulethisfollow-upexamination. DateofDictation:06/20/2025

Radiologist:Dr.MarkReynolds,MD

CONFIDENTIALITYNOTICE:Thisreportcontains confidentialpatient informationprotectedbyfederal andstatelaw.Itisintendedonlyfortheuseoftheindividualorentitytowhomitisaddressed.Ifyou are takeninrelianceon thecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704