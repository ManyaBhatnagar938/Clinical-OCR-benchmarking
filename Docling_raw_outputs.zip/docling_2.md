<!-- image -->

Procedure:Colonoscopy

DateofProcedure:May20,2025

Physician:Dr.EleanorVance,MD

## Activity:

Restathomefortheremainderoftoday.Youreceivedsedation and mayfeel sleepyordizzy.Youmustnotdriveacar,operate anymachinery,ormakeanyimportantfinancialorlegal decisionsfor24hours.Strenuousexerciseshouldbeavoidedfor 48hours.

## Diet:

Beginwithclearliquidssuchaswater,broth,orgingeraleforthe next4hours.lf clear liquidsarewell tolerated,you may advance toasoftdiet(e.g.,scrambledeggs,mashedpotatoes,plain chicken).Avoidalcohol,spicyfoods,friedfoods,andhigh-fber foodsfor24hours.ResumeyournormaldietonMay22,2025,as tolerated.Drinkatleast8glassesofwateroverthenext24hours toensureadequatehydration.

## WhattoExpect:

- 1.You may experience some abdominal bloating,gas,or mild crampingforthe next 12-24hours.Passinggas frequently will helptorelievethis.
- 2.A small amountofblood(afewstreaksontoiletpaper)might bepresentwithyourfirstoneortwobowelmovements.Thisis notunusual.

## Findings:

## RiversideHospital

742EvergreenTerraceSpringfield,IL, 62704Main

Phone:(217)555-1212Gastroenterology

Department:(217)555-3434

PatientInformationLine:(217)555-9090

- (a)Normal Colon

<!-- image -->

(b) Colon

<!-- image -->

- 1.The colonoscopywas successfully performed,with scope advancementtothececum.The cecum wasvisualizedandappearednormal.
- 2.The entireexaminedcolon,from thececumto therectum,showed anormalpinkmucosawithusual vascularpatterns.
- 3.Nopolyps,masses,diverticula,inflammation,orotherabnormalitieswereidentified duringthe examination.

The overall impression is a normal colonoscopy.

## Follow-Up:

Asyourcolonoscopywasnormal andnobiopsiesweretaken,noimmediatefollow-upappointmentis requiredregardingthisprocedure.

Youwill receivea lettersummarizingthesefindingsbymail within10businessdays.

This document contains confidential patient informationprotected under applicableprivacy laws, including the Health InsurancePortability and Accountability Act (HiPAA).