<!-- image -->

## Chief Complaints:

DateofVisit:06/21/2025

AttendingProvider:Dr.Angela Patel,MD

Location:UniversityDermatology Clinic

VisitID:ENC-GHI789-JKL

DateofBirth:04/12/1997Age:28Sex:Female

Address:101UniversityAve,College Town,USA98765

- A rash spreading across the back and armsforoneweek.
- Mild itchinessassociatedwiththe rash.
- Concernregardingthe nature and spread of the rash.

## VisitSummary:

began as a singlepatch on herflankand has since spread toherbackand upperarms.Therash is mildly pruritic,but she denies anypain,fever,orotherassociated symptoms.Shehasnot changed any detergents,soaps,or lotions recently.The physical examination is notable fora"herald patch"onher herback,classicfora"Christmas tree"pattern.The clinical presentationis highly consistentwith Pityriasis Rosea.The patient was reassured about the benign,self-limiting nature of the condition.She was counseled that it is not contagious and typically resolves spontaneously in 6-8weeks. Management forsymptomaticrelief of itchingwithgentle moisturizers and over-the-counter antihistamineswas discussed.Shewasadvised toreturn if the condition worsens orfailstoresolve as expected.

## Exams:

Vitals,Integumentary/Skin,HEENT(Head,Eyes,Ears,Nose,Throat)

## Findings:

Integumentary/Skin:Onthebackandproximalarms,therearenumerous,scattered,0.5-1.5cmovalina"Christmas tree"distribution.Asingle,3cmovoidplaquewitha collaretteofscaleispresenton therightflank.Palms and solesare clearof anylesions.

Vitals:Temperature is 98.6°F.Blood pressure,pulse,and respirations are within normal limits.

HEENT:The oropharynxis clearandwithoutlesions.Sclerae are anicteric.

## Medical History Snapshot:

ActiveProblems:Gastroesophageal RefluxDisease(GERD)

SurgicalHistory:Wisdomteethextraction(2015)

FamilyHistory:Motherwithahistoryofeczema.

Medications: Combined oral contraceptive pill(daily),

Famotidine 20mg(as needed for heartburn).

Allergies: No Known Drug Allergies.