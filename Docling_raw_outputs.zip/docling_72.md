Patient:JohnSmithDOB:05/20/1965MRN:789012

Accession#:A583920-25

<!-- image -->

SunriseDiagnosticsPhone: NorthValleylmagingCenter456 OakAvenue,Suite200Anytown, USA12345 (555)123-4567

Patient:John Smith

DOB:05/20/1965

MRN:789012

Gender:Male Referring

Physician:Dr.EmilyWhite

## Visit #:456-789Date ofVisit:06/18/2025

DiagnosticImagingReport-ChestX-ray(2views)

Procedure:Radiography of the chest,posteroanterior and lateralviews.

Clinical Indication:Persistentcough and shortness of breath.

<!-- image -->

Impression

<!-- image -->

## Scheduled appointments:

Follow-upappointment withDr.White scheduled for 06/25/2025 at 11:00AM to discuss theresults and furthermanagement.

DateofDictation:06/18/2025Technician:SarahJenkins,RT(R)

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotected byfederal andstatelaw.Itisintended onlyforthe useofthe individualorentitytowhom itisaddressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction taken inrelianceon thecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.