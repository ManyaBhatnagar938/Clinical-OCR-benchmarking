<!-- image -->

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  Carlos M.Rivera  09/14/1990  MRN-038664  Gender:[X]M[]F[]Other  Phone Number:(832)555-0558  Today'sDate:01/30/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse(bpm)  Resp(rpm)  Temp(°F)  SpO2(%)  Weight(Ib)  Height(in)  118/72  68  15  98.6  66  172  70   |
|------------------------------------------------------------------------------------------------------------------------------|

| Medical History  []Hypertension  [] Diabetes(Type I)  [] Diabetes (Type Il)  [X] Asthma  []COPD  []Heart Disease  []High Cholesterol  []ThyroidDisorder  []Arthritis  []Cancer  [X]Depression/Anxiety  []Other:   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  MedicationName  Dosage  Frequency  Fluticasone/Salmeterol  250/50mcg  Twicedaily  AlbuterolHFA  90 mcg/puff  PRN every4-6hrs  AmphetaminesaltsXR  20 mg  Once daily (AM)  Montelukast  10mg  Once daily (PM)   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Amoxicillin  Hives  Ibuprofen  Gl upset   |
|-------------------------------------------------------------------------------|

## Reason for Visit

Newpatient intake forasthma management and ADHD evaluation.Patientrequests referral forcognitive behavioral therapyforanxiety.

Provider Signature: Samuel Reyes

Date: 01/30/2026