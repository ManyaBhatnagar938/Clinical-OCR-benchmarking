Date:04/07/2026

Patient:NoahT.Williams

Therapist Names:Mr.Carlos Fuentes,RBT/Ms.Amy Chen, BCBA

## DAILY REPORT

- [ ] AnxiousCalm/ContentFrustrated

- [x] Cup

- [x] AngryCheerful/HappyGrumpy

- [ ] Backpack

MOOD AFFECT

- [ ] AnnoyedEnergeticTired

CameWith

- [x] Jacket

- [ ] Loving

- [ ] Lunch Box

- [ ] other

AGGRESSION

STEMMING

NONCOMPLIANCE

OTHER

- [ ] Hitting

- [ ] Thumb Sucking

- [ ] Non Compliance

- [ ] Inappropriate Laughing

- [ ] Kicking

- [x] Mouthing

- [ ] Tantruming

- [ ] Genital Grabbing

- [ ] Hair Pulling

- [ ] Pica

- [ ] Elopting

- [ ] Inappropriate

- [ ] Throwing

- [ ] Flopping

- [x] Hand Flapping

Touching

- [ ] Pushing

- [ ] Screaming

- [ ] Hand Jerks

- [ ] Verbal Aggression

- [ ] Head Banging

- [ ] Crying

- [ ] Verbal Refusal

- [ ] Vocal Stereopathy

- [x] Scratching

- [ ] Repeating

- [ ] Climbing

- [ ] PreservativeManding

- [ ] Pinching

- [ ] Licking

- [x] Non-responsive

- [x] Side-Talk

- [ ] Grabbing

- [ ] Echolalia

- [ ] InappropriateDance

- [ ] Spitting

- [x] Teeth Grinding

- [ ] Biting

- [ ] Vomiting

- [ ] Swiping

- [ ] Self-Hitting

## Eating Report:

Noah ate approximately 30% of lunch. Accepted preferred juice drink. Required 5 verbal prompts to remainseated throughoutthemeal.

## CH

TargetsHitDuring Lunch:

Receptiveidentificationofobjects(+2/5).Imitation targets(+1/5-fatigued).Toleratingtransitions (2/5).

## Today's Struggles and Strengths:

## GROUP CIAL S

respondedtoownnameconsistently(+5/5).