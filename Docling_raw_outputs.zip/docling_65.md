<!-- image -->

## Lakewood Hospital-Departmentof Anatomic&amp;ClinicalPathology

Patient Name:Paeson mak alan

DateofBirth:mah22 1465

Medical Record Number:

LH45.67.84X

Gender:mal

PatientAddress:45moainVew

ave.Lakewood,C0.80215

9000Forest Pine Road,Lakewood,CO, 80210LaboratoryDirect Line:(303) 5550100|PathologyFax:(303)555-0102CLIA Number:05D1234567|CAPAccreditation No:8005001

## PATHOLOGYREPORT

831676002937

<!-- image -->

AccessionNumber:NP.25.7840/

OrderingPhysician:DSaah

DateCollected:may1.2025

Jennings.mD.FaaD

TimeCollected:02.15Pm

Clinic/Location:Lkewood

DateReceived:may1.2025

Dermetology,Certer

TimeReceived:03:00Pm

Address:875PeofesionalPakDeve

DateReported:may2l.2025

Sute 200.Lakewood, C0.80210

TimeReported:/2:15Pm

PhysicianPhone:(303)555.0250

Specimen Type:Punch Biopy.Skin-Rigkt Uppee Back

PhysicianNPl:1276542Q770

Diagnosis: SKIm.RIgHTuPPERBaCK,PUnCHBIOPSy:aTyPICaLmELarbOg nEVUS) wITHSEVERE aRCHITECTURaLDISORDER anDSEVERE CyTOLOGTC aTYPIa.THE aTyPICaLPROLIFERaTTOnEXTEnDSTOTHEPERIPHERaLanDDEEPBIOPSY maRGImS.

Comments: The findings arethoe of a sereely, dsplastre nerus. Given the dere of ypia andthenrtremetof mangiuinthss rcommendedto exclnde the posililty, of an adjacent melanoma andto ensue complte remoral ofthe aMypical lesion. Coretionwthnicalfindnsisenial.Hreeisin is peford, smiin fhe nespemen forhitologi

pspos ospongon

Immumohistochemical Stains:

- SON10: Streong rncleon posituity in atypical melanouftes.
- HtmB-45: Patehy postirty, within the junCtronal component.

N20t0e bppournddo rm ppodn) uorpropyord onyinouopu gordhp yzuyan amprod lpoenlfa3ul0dd

- serecrely daysplastie neri and melanomas).
- Ki67: Prolierotion index is focally clevated, up to &amp;.10% in mros of greatest oMgpia. Futher molenlntestng (eg..for BRaF mtations) isnot roumel penpormed on dyplasreneri ht mag bconsidered on suequentspecimens if fcotures suspicionz formelanoma ae identificd