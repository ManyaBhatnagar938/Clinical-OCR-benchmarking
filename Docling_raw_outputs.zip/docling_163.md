<!-- image -->

HOSPITAL

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  Dorothy R.Ingram  01/17/1938  MRN-045772  Gender:[]M[X]F[]Other  PhoneNumber:(713)555-3301  Today'sDate:04/20/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(°F)  SpO2 (%)  Weight(Ib)  Height(in)  148/86  78  16  97.6  96  148  62   |
|--------------------------------------------------------------------------------------------------------------------------------|

| Medical History  [X]Hypertension  []Diabetes(Type l)  [X] Diabetes(Type Il)  []Asthma  []COPD  []HeartDisease  []High Cholesterol  []ThyroidDisorder  [X]Arthritis  []Cancer  [X] Depression/Anxiety  []Other:   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  Donepezil  10mg  Once daily (PM)  Amlodipine  5mg  Once daily  Metformin  500mg  Twicedaily  Oxybutynin  5mg  Once daily   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Morphine  Extremenausea  Ibuprofen  GI bleeding   |
|---------------------------------------------------------------------------------------|

## Reason forVisit

Geriatric cognitive reassessment.Family reports increasing evening confusion.MMsE declined 2 points since lastvisit.Caregiverpresent.

Provider Signature: Angela M. Forsythe

Date: 04/20/2026