Patient:MariaGarciaDOB:09/15/1992MRN:654321

Accession#:B987654-25

<!-- image -->

## MRI Report-RightKnee

Procedure:MRloftherightkneewithoutcontrast.

MenihT

Ligamnt:AT

<!-- image -->

ArticularCartilageandBone:Teemf chfoahauffktolfemfpafed T

ImpreSSion:FHueerteAh themelehMtet

<!-- image -->

## Scheduledappointments:

UrgentreferraltoOrthopedicSurgeryforconsultation.AppointmentscheduledwithDr.KatherineLee on06/23/2025at2:00PM.

Date ofDictation:06/20/2025Technician:MichaelBrown,ARRT(MR)

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotected byfederal andstatelaw.ltisintended onlyfortheuseofthe individualorentitytowhom itisaddressed.lfyou are nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction takeninreliance on thecontentsof these documentsisstrictlyprohibited.lfyou havereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704

OrthoSport Imaging Center 789WellnessBoulevard Metropolis,USA54321 Precision RadiologyGroup

Phone:(555)876-5432

Fax:(555)876-5433

Patient:Maria Garcia

DOB:09/15/1992

MRN:654321

Gender:FemaleReferring

Physician:Dr.David Chen

## Visit#:123-456DateofVisit:06/19/2025