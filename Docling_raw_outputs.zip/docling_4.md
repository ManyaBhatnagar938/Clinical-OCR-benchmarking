UniversityMedicalCenter456OakAvenue,Springfield,IL62704Phone:(217)555-1234

JaneSmithMRN:789012DOB:05/15/1968

## Chief Complaint

Chestpainandshortnessofbreathfortwodays.

## Care Team

AttendingPhysician:Dr.RobertJones,MDPager:(217)555-5678

## Pharmacies

s

T:98.9F

## Vital sign

HR:98bpm

BP:145/92mmHg

RR:20breaths/min

02Sat:94%onroomair

## Allergies

Penicillin-Rash

## Medications

Lisinopril 10mgdaily

## Vaccines

Influenza-10/15/2024

Tdap-08/20/2022COVID-19

BivalentBo0ster-12/05/2024

## Problems

- Hypertension
- Hyperlipidemia
- Type2DiabetesMellitus

## FamilyHistory

Mother:History of hypertension and type 2 diabetes.

Father:History of coronary artery disease,deceased at age 65frommyocardial infarction.

## Social History

Tobacco:Smokes1packofcigarettesperdayfor30years.

Alcohol:Occasional socialuse.

Employment:Retiredofficemanager.