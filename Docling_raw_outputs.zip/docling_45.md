<!-- image -->

<!-- image -->

| PatientName:WilliamJohnson  OrderingPhysician:Dr.Robert  DateofBirth:09/01/1956  Anderson  MRN:789321  Procedure:Ultrasound-guided  Accession#:SU-25-11223  prostate needlebiopsy  DateofProcedure:06/20/2025  DateofReport:06/25/2025   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

Diagnosis:

Clinical History:69-year-oldmalewithan elevatedserumPSAof9.2ng/mL.

- A)Prostate,RightBase,Biopsy:Benignprostatictissue.
- C)Prostate,RightApex,Biopsy:Adenocarcinoma,GleasonScore3+4=7.
- B)Prostate,RightMid,Biopsy:Adenocarcinoma,GleasonScore3+4=7.
- D-F)Prostate,LeftBase,Mid,Apex,Biopsy:Benignprostatictissuewithfeaturesofbenignprostatic hyperplasia (BPH).

Gross Description:The specimen consists of twelve parts(A-L),each containing one to three tanwhite,threadlike tissuecoresmeasuringfrom1.0 to1.5 cm inlength.All tissue issubmitted.

Microscopic Description:Multiple cores of prostatic tissue are examined.The majority of cores(A,D, E,F,and H-L) showbenignglandswithfeatures of nodular hyperplasia.Cores from the right mid-gland (B)and right apex(C) showinfiltrating,small,crowded glands with enlarged nuclei and prominent nucleoli.Thetumoriscomposed ofwell-formedglands(Gleasonpattern3) andpoorly-formed/fused glands(Gleasonpattern 4).Perineural invasion is identified in core C.No extraprostatic extension is seen.

## TumorSummary:

Histologic Type:Acinar Adenocarcinoma

GleasonScore:3+4=7

WHO/ISUPGradeGroup:2

CoresInvolved:2of12(17%)

TumorExtent:Cancerinvolves30%ofcoreBand50%ofcoreC.

Perineural Invasion:Present

Extraprostatic Extension:Notidentified

Specimen:Prostate,needle

Pathologist:Dr.Olivia Martinez

corebiopsies(12cores)biopsy

Report status:Final