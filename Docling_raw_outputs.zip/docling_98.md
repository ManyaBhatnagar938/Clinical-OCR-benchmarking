<!-- image -->

DateofVisit:06/21/2025

Attending Provider: Pdeis M

FAAP

Location:DelaPdtsOlia

VisitID:NO-S-2025-112

HOSPITAL

## Date ofBirth:05/05/2019Age:6 Sex:Female

## Address:345ElmStreet,Riverdale,USA23456

Medical HistorySnapshot:

PaMediclHitory:None

Lmanion:Up

## ChiefComplaints:

- Soreftrootforfoodoys
- Fr102.5°
- Hadaehe
- hpdtopomm
- pMisitsummd mahprtafodaghitoy hmferpotpofhaalshadahadacandpooroppfehdenicuho Examinationwos signifiantbr fonilar exudotesand fender anferior uroical hinorrhea. Arapid iniceGroupASfrepffooperbormad nd rut lgmphadenopatty posttnBad ofteindingadiagnSfrtreal PharggtsoamadA preeripfonbrAmxiclineprovided.andfheipoancomplfngfhebcous fherapy oesmphailffhmterRtarnfschol guidlineand sppofecremeasurs erv alsodiscased

## Exams:

Vtal.GeneralHEENT.Nck.Qu

Findings:

Vtal:Tmp: 101.8%F. HR: 10. RR: 20. StQ2: 99%

oxie

pefechiae.

Lon: Clfafon btftay t ne hu or erackls.