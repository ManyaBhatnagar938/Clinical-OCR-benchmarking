Name:Helen F.Morrison

Age:70

Attend Dr:Dr.Fiona K.Reyes

Acct#:31928-F

Sex:F

Location:Oncology

Date:04/08/2026

DOB:05/30/1955

SPEC#:S-2026-04-08-074

COLLECTEDTIME:08:30

STATUS:FINAL

ENTERTIME:08:30

REPORTTIME:11:15

REQ#:R-31928

ORDERTIME:08:15

| Test  Result  Flag  Reference  Site  WBC  5.2 x10/μL  4.5-11.0  ONC  REC  3.75x10%/μL  L  4.00-5.20  ONC  HGB  11.0g/dL  L  12.0-16.0  ONC  HCT  33.2%  L  36.0-46.0  ONC  MCV  88.5fL  80.0-100.0  ONC  MCH  29.3pg  27.0-33.0  ONC  MCHC  33.1 g/dL  32.0-36.0  ONC  PLT  142 x10/μL  L  150-400  ONC   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|