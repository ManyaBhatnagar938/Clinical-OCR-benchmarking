<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name:James A.Whitfield  DateofBirth:06/12/1958  Proposed Procedure:  Surgeon/Department:  Dr.Raymond Choi,MD-GeneralSurgery  Laparoscopiccholecystectomy   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/ Labs  Test  Result  Test  Result  Test  Result  WBC:  8.2  Hgb:  13.4  Hct:  40.1  Na:  138  K:  4.1  Glucose:  114  PT:  12.8  INR:  1.1  PTT:  28   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;PulmonaryRiskAssessment  []Hxof Myocardial Infarction  []Congestive Heart Failure  []Arrhythmia/Pacemaker  [X]Hypertension  []COPD/Asthma  []ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []Other CardiacHistory:   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  FamilyHxMalignantHyperthermia:[X] No[]Yes  Previous Anesthesia Issues:[X] No[] Yes  MallampatiScore:[]I []ll[] []V  LooseTeeth/Dentures/Caps:[X]No[]Yes  Weight(kg):  NPOStatus(LastMea/Drink):  92  Clear liquidsuntil04:00;solidsNPOaftermidnight   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/MedicationstoHold:

Hold Metformin on day of surgery. Continue Lisinopril with sip of water.Plan:general anesthesia.

Final Clearance:[X] CLEAREDFORSURGERY[]NOTCLEARED[]PENDINGLABS