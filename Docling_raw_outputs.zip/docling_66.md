<!-- image -->

Procedure:doipcCobe

DateofProcedure:l 20.2025

Physician:D.Eltauuhucem

## RiversideHospital

Phone:(217)555-1212Gastroenterology

Department:(217)555-3434

PatientInformationLine:(217)555-9090

742EvergreenTerraceSpringfield,IL, 62704Main

<!-- image -->