<!-- image -->

<!-- image -->

Patient Name: M

OrderingPhysician:

D.AD.…

DateofBirth:Il/05/199

ProcedureAry

MRN:156789

Accession#:25-31567

DateofProcedure:

06/24/2025

Date of Report: 06/25/2025

Clinicl History: 30M  oatm  C-

7 Dgm C +.B C+ ((CN 2) Gross Description: Rwd  p  6 t: o 4l  m lm,ad mag r 0.3 at t n ait.M ta h  m h k  tgf. M mdpaprr p N m  auouuoo Trpfe dn mg .

Specimen:

Pathologist:

Cl  6 d

+W

Report status:

-in