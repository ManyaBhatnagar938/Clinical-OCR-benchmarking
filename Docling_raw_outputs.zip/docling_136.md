<!-- image -->

March10,2026

| SECTIONA:Medical History  Yes  No  X  RheumatoidArthritis(ICD-10:M06.9)  X  Hypothyroidism(ICD-10:E03.9)  X  MajorDepressiveDisorder(ICD-10:F32.1)  X  Gastroesophageal RefluxDisease(ICD-10:K21.0)  X  Osteoporosis(ICD-10:M81.0)  X  Anemia,IronDeficiency(ICD-10:D50.9)  Fibromyalgia(ICD-10:M79.3)   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  X  Methotrexate 15mg-onceweekly  FolicAcid 1mg-once daily  X  X  Levothyroxine75mcg—oncedaily(fasting)  X  Sertraline50 mg-once daily(AM)  Omeprazole20mg-oncedailybeforemeals  X  Alendronate 70mg-onceweekly  X  Hydroxychloroquine200mg-twicedaily  X   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

MariaDelgado

Patientsignature

Maria Delgado

Print name

<!-- image -->

Patient:Maria C.Delgado

DOB:03/28/1972

MRN:007-214-55