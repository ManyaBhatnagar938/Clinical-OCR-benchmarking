PatientName:DanielWilliamsMRN:2345678

<!-- image -->

## Bayfront Medical Center

750WaterfrontAveTampa,FL 33602

Phone:(813) 555-7000

Fax:(813)555-7001

## PATHOLOGYREPORT

831676002937

<!-- image -->

Accession Number:S2s-11223

DateofCollection:6/2o/2o2s

Time of Collection:/3.M

Specimen Type:StaehMr,putiul

Gnrtlty

## Final Diagnosis:

DateofBirth:/o/os/16

Age: (

Gender: M

PatientAddress:123p

eCt,a,fl3360s

OrderingPhysician:O

mti.mo

Practice:CulCt

Address:Mdien

u.a，Fl3602

Phone:(313) sss-7050

SOMtCH.PtRDtCtSRECOmy: GtSTRonbEsntlsRomtlumoRCs).SpnDlEcEllpE.

datdtuhar

MicroscopicDescriptioniSeetiansshe adnueei.hesildta asinathi

## Gross Description:

eshy,tahuhcte 5.5e.D thrat

## Comments:

Statal Thect disenre.hunahistauhehiuat

## Biomarkers

- CDm(ekt:pesite(stayaddinrure)
- CD3:Perte
- kitkGemutatientalgrrplritileplhutatienn ExanI.

Huh. Surgiel