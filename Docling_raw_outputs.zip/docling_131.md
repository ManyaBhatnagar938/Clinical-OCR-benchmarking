<!-- image -->

HOSPITAL

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  JamesA.Whitfield  06/12/1958  MRN-004738  Gender:[X]M[]F[]Other  PhoneNumber:(713)555-0142  Today'sDate:04/22/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(oF)  Sp02 (%)  Weight(lb)  Height(in)  142/88  72  16  98.4  97  198  70   |
|--------------------------------------------------------------------------------------------------------------------------------|

| Medical History  [X] Hypertension  [] Diabetes (Type l)  [X] Diabetes (Type Il)  []Asthma  []COPD  []Heart Disease  [X] High Cholesterol  [] Thyroid Disorder  []Arthritis  []Cancer  []Depression/Anxiety  []Other:   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  Lisinopril  20mg  Once daily  MetforminHCI  1000mg  Twicedaily  Atorvastatin  80mg  Once daily (PM)  Furosemide  40mg  Once daily(AM)   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Penicillin  Hives/urticaria  Sulfa drugs  Rash   |
|--------------------------------------------------------------------------------------|

## Reason forVisit

Follow-up forhypertension and diabetes glycemic management.Patient reports mild fatigue overpast 2 weeks.A1crecheckordered.