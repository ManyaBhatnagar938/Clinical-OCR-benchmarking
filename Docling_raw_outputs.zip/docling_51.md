<!-- image -->

## Advanced ImagingAssociates

789InnovationWay Phoenix,AZ85004 (602) 555-7890

PatientName:BrendaWalker

MRN:1032547

MRN:1032547

Accession:R44091-25

DOB:03/21/1951

Date:06/23/2025

Gender:Female

Age:74

Thepatientis a74-year-old femalewith a chief complaintof chronic,progressive rightkneepainoverthelastseveralyears.Thepain isexacerbated byweightbearingand activity such aswalkingorclimbingstairs,andshereports morning stiffnessthatlastsforabout30minutes.Shehaspreviouslytriedover-thecounterNSAlDswith partialrelief.There is no historyof acute trauma to theknee.

## PROCEDURES:

MRI Right Knee without contrast:Multiplanar, multisequence magnetic resonanceimagingoftherightkneewasperformed.

## IMPRESSION:

Severe tricompartmentalosteoarthritis,mostpronounced inthe medial femorotibial compartmentwithhigh-gradecartilageloss,subchondralcystic changes,and marginal osteophytes.

No acutefractureor ligamentousruptureidentified.

Complexdegenerativetearoftheposteriorhornof themedial meniscus. Moderate-sized jointeffusion.

Patient Name:Brenda Walker MRN:1032547 Age:74

Electronically Signed By:Dr.SamuelJones,M.D.(Radiology)

Date:06/23/2025Time:09:03