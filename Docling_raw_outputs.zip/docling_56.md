<!-- image -->

## MidwestGastroenterologySpecialists

200FirstStreetSW Minneapolis,MN55905 (507) 555-6789

PatientName:Laura Evans

MRN:2154879

MRN:2154879

Accession:G25-1123

DOB:10/02/1984

Date:06/23/2025

Gender:Female

Age: 40

Thepatientisa 40-year-oldfemalewitha5-yearhistoryofgastroesophageal reflux disease(GERD).Sheis currently managed with omeprazole20 mg daily, which she reports taking consistently.She notesgood control of her typical symptoms of heartburn and regurgitation on this regimen. She presents today for a routine follow-up. She denies any dysphagia,odynophagia,orunintentional weight loss.

## PROCEDURES:

PhysicalExamination:Abdomenissoft,non-tender,andnon-distendedwith normalactivebowel sounds.Nohepatosplenomegaly.

Plan:Given the duration of her symptoms,the patient will be scheduled for an esophagogastroduodenoscopy (EGD)forfurtherevaluation and screening.

## IMPRESSION:

Gastroesophageal reflux disease(GERD),well-controlled on proton pump inhibitor therapy.

Plan to proceed with screening EGD.

Patient Name:Laura Evans MRN:2154879 Age:40