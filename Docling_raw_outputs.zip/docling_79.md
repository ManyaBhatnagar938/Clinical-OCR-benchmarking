PatientName:JaneDoeMRN:987654321

<!-- image -->

## UniversityMedical Center

123HealthSciencesDrive

Metropolis,USA12345

Phone:(123)456-7890

Fax:(123)456-7891

DateofCollection:2025-06-15

Time ofCollection:09:30/n

Specimen Type: . 4e

ultroparfad

## Gross Description:

md,Lflwtkckptut 4f tn k:Jetrftkn tokitr, glodal t 1.2150.20.3R

## Microscopic Description:

gulmstypl,fltnty tkph t.R apdstuullytpemepkutk mak.Mttuunr afputly datfu.Rn antfdtksfmttdmntwid.

## Diagnosis:

GutlCui G3+3

## Comments:

<!-- image -->

## Biomarkers:

| Biomarker  Result  Interpretation  Estrogen Receptor(ER)  Pending  Progesterone Receptor(PR)  Pending  HER2/neu  Pending   |
|----------------------------------------------------------------------------------------------------------------------------|

## PATHOLOGYREPORT

831676002937

<!-- image -->

<!-- image -->

Patient Name:

PatientID:987654321

Date ofBirth:1970-05-15

Gender:

Accession Number:

D25-12345

OrderingPhysician:

23k-sek.mo

ClinicalPractice:

ntrplrOroborrApatrr

Address: 56C..C.D

me. 14 1235 Phone:

(123)555-0123