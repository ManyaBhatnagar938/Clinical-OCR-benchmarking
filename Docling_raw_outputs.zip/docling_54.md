<!-- image -->

## HOSPITAL

## Coastal HeartInstitute

85WaterfrontDrive Charleston,SC29401 (843) 555-2300

PatientName:RobertDavis

MRN:4478102

MRN:4478102

Accession:E25-4511

DOB:09/30/1974

Date:06/23/2025

Gender:Male

Age: 50

Thepatientisa50-year-oldmalewhopresentswithacomplaintofintermittent heartpalpitations overthepastthree months.He describes the episodes asa "fluttering" sensation in his chest that lasts for a few seconds and resolves spontaneously.Episodesoccur2-3timesperweekwithno clear trigger.He reports increasedwork-related stressrecently and consumes3-4cupsofcoffee per day.He denies chest pain, syncope,or shortness of breath.

## PROCEDURES:

12-Lead EKG:Performed in theoffice today.

24-Hour Holter Monitor:Patient was provided with the device and instructed on itsuse.Hewillreturnittotheclinictomorrow.

BloodPressure:128/84mmHg.

## IMPRESSION:

Palpitations,etiology to be determined.Suspect benign premature atrial contractions,potentiallyexacerbatedbycaffeineintake andstress. Normal sinusrhythmwith rarepremature atrial contractionsseenon in-office EKG.

Awaitingresults of 24-hourHoltermonitorforfurtherevaluation.

Patient Name:Robert Davis MRN:4478102 Age:50

Date:06/23/2025Time:09:10