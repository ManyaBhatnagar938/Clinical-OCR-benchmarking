<!-- image -->

Rinsteseactimties

RbeARae me

Retamnd relofpor rovtinetonorral

Impressions:

ovnystartwithy aneet

<!-- image -->

Findings:

D

D

Perelopseretedbd Yonnalpan,a eer,sicwy

<!-- image -->

Thisdocumentcontainsconfidentialpatient informationprotected underapplicableprivacylaws, includingtheHealthInsurancePortabilityandAccountabilityAct(HiPAA).

## DesertBloomGastroenterology

123SonoranHealthCircle,SuiteB Phoenix,AZ85004

Phone:(602)555-7000

Fax:(602)555-7001

ProcedureDate:June21,2025

uitkntrmonovss etine ent

## (a)Normal Colon

(b)Colon

<!-- image -->