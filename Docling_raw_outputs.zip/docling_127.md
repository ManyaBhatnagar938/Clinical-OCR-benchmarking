<!-- image -->

<!-- image -->

To:Wr.AoronGoldtain.M@.Btolaryngology

Facility:TheEMTAllerzyCenter

Fax:(9383-y040

Phone:(c9303-y041

Re:PattentConsult:WA&amp;&amp;R.Wand

From:ChritinePee.PA-C

Facility:edvideFamilyPraotioe

Fax:(9707-606

Phone:()707-6061

Date: Jne 2s.2025

Time: 1136AM

Pages:lincluding cover)

Notes:

Suboot:Referrne forReonrrent-Sinugitty

Wenr Or. Goldstin.

am reforring Wand phalkor(@B:D6/15/19gD) for aynluattor of roourrent-norta baotarnl sinngitiy.

Mr.Palker hayoxprerionoed four doormonted rizodey reguring anttlrotto thorngoy ine tho lat-1 montpr He ryrorty rorrstent nasal songestton ewen Betreon aorta infootiony.

Tam roforring him for burther norkoye to rmle ornt ane mderlying anatemionl or chronia infeammatory conditton.

Thankyyow.

Theinformationcontained in thisfacsimilemessageislegallyprivileged and confidentialinformationintendedonlyfortheuseof theindividualorentitynamed above.lf thereaderofthismessageisnottheintendedrecipient,you arehereby notifiedthatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.Ifyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by telephone and return the original message to us at the address above via the U.s. Postal Service.Thankyou.