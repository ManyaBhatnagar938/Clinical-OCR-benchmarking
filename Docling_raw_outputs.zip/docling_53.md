<!-- image -->

## Children'sHealth Pavilion

Patient Name:Olivia Chen

MRN:6509823

DOB:04/10/2023

Gender:Female

Age: 2

300LongwoodAvenue Boston,MA02115 (617) 555-5437

MRN:6509823

Accession:C89912-25

Date:06/23/2025

Thepatientisa2-year-oldfemalebroughttotheclinicbyhermotherwithatwodayhistoryoffussiness,irritability,andlow-gradefever.Themotherreportsthe child hasbeen pulling at her leftear.Thepatient has also had a decreased appetite.Shehashada concurrentmild clearrhinorrhea.Noknownsick contacts.Vaccinations areuptodate.

## PROCEDURES:

Physical Examination:Temperature 101.4°F(tympanic).Otoscopy:Right tympanicmembrane ispearlygraywith a normal lightreflex.The left tympanic membrane is erythematous,bulging,with loss of landmarks.There is purulent fluid noted behind the membrane.Respiratory Exam:Lungsare clearto auscultationbilaterally.

## IMPRESSION:

Acute otitismedia,leftear. Fever.

PatientName:Olivia Chen MRN:6509823Age:2

Electronically Signed By:Dr.Sarah Miller,M.D.(Pediatrics)

Date:06/23/2025Time:09:08