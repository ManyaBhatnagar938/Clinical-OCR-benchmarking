Accession#:L20250620-1148

<!-- image -->

Patient:JamesPeterson

DOB:07/30/1955

MRN:357159

Gender:Male

Referring Physician:Dr.Laura

Fernandez

PremierClinicalLaboratories 1200TechnologyDrive Austin,TX78759

Phone:(512)555-5000

Fax:(512)555-5001

Order#:998123DateCollected:06/20/2025DateRep0rted:06/20/2025

Clinical Laboratory Report

## Comprehensive Metabolic Panel(CMP)

Theresuetsafthe Campehensiuernetabolicpaneeshawageucase eeneetkatiyeleatedatmg.Jhebunaeaelenate&amp;at mga.Lineigunctiantestsshawaneeerate&amp;ATassueandan elerate&amp;8e

Thefoeeawingtestsaewithinnanmaeeimitsga&amp;iumaeommsee patassiumat4.mmaee.Ckeaideat10mmaee.Caben-biaxi&amp;eat25 mmael.Ceatinineat2mgial.Calciumat95mgiAekaline phasphataseatHeTataepiateinat12gid.Aeuminat.1g an&amp;TetaeBilixukin at 08mgdl.

Cammentrnielkypeig ycemiaandmiedeleuatianineiney

Bansaminasesaienated.Clinicalcaixelatianisecammended

<!-- image -->

DateofReview:06/20/2025

Laboratory Director:Dr.Charles Evans,PhD

CONFIDENTIALITYNOTICE:Thisreport containsconfidential patient informationprotected byfederal andstatelaw.Itisintendedonlyfortheuseoftheindividual orentitytowhom itis addressed.Ifyou are not theintendedrecipient,you areherebynotifiedthatanydisclosure,copying,distribution,oraction taken inrelianceonthecontentsof thesedocumentsisstrictlyprohibited.If you havereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704