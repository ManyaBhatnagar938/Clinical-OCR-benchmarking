<!-- image -->

Fax:(5s5)7s-0011

Phone:(sss)7s1-0012

Re:CumltppatentOts.penda

From:D.Oraflly.MD

Facility:RedyetaneFarclyMediet

Fax:(sss)sc&gt;-1122

Phone:(sss)s6&gt;-1125

Date:2s,202s

Time:2M

## Notes:

<!-- image -->

Theinformationcontained inthisfacsimilemessageislegallyprivilegedand confidentialinformationintendedonlyfortheuseoftheindividualorentitynamed above.Ifthereaderofthismessageisnottheintendedrecipient,youarehereby notified thatanydissemination,distribution,orcopyingofthistelecopyisstrictly prohibited.Ifyouhavereceived thistelecopyinerror,pleaseimmediatelynotifyus bytelephoneandreturntheoriginal messagetousatthe addressaboveviatheU.s. Postal Service.Thankyou.

<!-- image -->

## FAX