<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Patjent Name:

OrderingPhysician:

annir

Date of Birth: 1012511962

Procedure:

MRN:2362

Accession#: 66772

B-25-

DateofProcedure: 061231202年

DateofReport:2612512025

ClinicalHistor

w

1.2

10

Diagnosis

GrossDesc

Microscopic

Comment:

Specimen:

Pathologist:

Accession#:SB-25-66778