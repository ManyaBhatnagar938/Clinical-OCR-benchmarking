<!-- image -->

## Surgical Pre-Operative Assessment

| Patient Name:Robert T.Nakamura  DateofBirth:11/05/1945  Proposed Procedure:  Surgeon/Department:  Dr.KarenM.Levin,MD-OrthopedicSurgery  Righttotalkneearthroplasty   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Pre-Admission Testing/ Labs  Test  Result  Test  Result  Test  Result  WBC:  10.1H  Hgb:  11.8L  Hct:  35.4L  Na:  137  K:  4.4  Glucose:  128  PT:  18.2H  INR:  1.9H  PTT:  34   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Cardiovascular&amp;PulmonaryRiskAssessment  [X]HxofMyocardial Infarction  [X] Congestive Heart Failure  []Arrhythmia/Pacemaker  [X]Hypertension  []COPD/Asthma  [X]ObstructiveSleepApnea  []SmokingHistory  []ExerciseTolerance&gt;4METs  []Other CardiacHistory:   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Anesthesia&amp;Airway  Previous Anesthesia Issues:[] No[X] Yes  FamilyHxMalignantHyperthermia:[X]No[]Yes  MallampatiScore:[]l []ll[×]ll[]IV  Loose Teeth/ Dentures/Caps:[X] No[]Yes  NPO Status(Last Meal/Drink):  Weight(kg):  NPOaftermidnight  88   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Pre-Operative Clearance

Recommendations/Medications toHold:

Hold Warfarin5 daysprior;bridgingper cardiology.Cardiology clearance obtained.CPAP device confirmed forpost-op.Anesthesia:spinalwithsedationpreferred.

Final Clearance:[]CLEAREDFORSURGERY[]NOT CLEARED[X]PENDINGLABS

<!-- image -->

Date:03/28/2026