<!-- image -->

HOSPITAL

| Full Name:  DateofBirth(MM/DD/YYYY):  PatientID/MRN:  Helen F.Morrison  05/30/1955  MRN-031928  Gender:[]M[X]F[]Other  PhoneNumber:(713)555-2288  Today'sDate:04/08/2026   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Vital Signs  BP(mmHg)  Pulse (bpm)  Resp(rpm)  Temp(°F)  SpO2(%)  Weight(lb)  Height(in)  128/76  70  14  98.4  66  162  63   |
|-------------------------------------------------------------------------------------------------------------------------------|

| Medical History  []Hypertension  []Diabetes(Typel)  [] Diabetes (Type Il)  []Asthma  []COPD  []Heart Disease  [X]High Cholesterol  [X]ThyroidDisorder  []Arthritis  [X]Cancer  []Depression/Anxiety  []Other:   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Medications  Medication Name  Dosage  Frequency  Letrozole  2.5mg  Oncedaily  Levothyroxine  88mcg  Once daily (fasting)  Alendronate  70mg  Onceweekly  CalciumCitrate+VitD  500mg/400IU  Twicedaily   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| Allergies  Allergen  Reaction Type  Sulfa drugs  Rash  Codeine  Nausea   |
|--------------------------------------------------------------------------|

## Reason for Visit

Breastcancer survivorship coordination visit.Bone density scan ordered.Reports joint stiffness attributed to aromatase inhibitor use.

Provider Signature: Xinda yamamoto

Date: 04/0x/2026