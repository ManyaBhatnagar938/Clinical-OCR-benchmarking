<!-- image -->

<!-- image -->

PatientName:B

OrderingPhysician:

DateofBirth:07/16/R6

DPtuNee

MRN:51321

Accession#:K-25-8865

py

DateofProcedure:06/23/2025

DateofReport:06/25/2025

Clinical History: 29allpmalrvtlxnhaty +Srta LpErytham SLE)

puuntingupeneumtpufunuunllamtubepyupadtueeatrrepynphutr

Dugmuukdymtaulpy LoprNplutnCemN-g(A)

unetxnlmteeYt-28 HaulrudatudrvwrlatmAlegtauldgle lynndupllaynkmwgl hypunleeutyrpenatphulumulfatommeplgtmuleantrunxuepeunnYey

## ImmunofluorescenceDescription:

mpdryyrdgrrdng

rdgrrdnra

FhungmNgtu

Allm Nt

ElectronMicroscopyDescription:e hmrrmym

Specimen: Nlyly

Pathologist:DuRuhe L

Rpt+uFe

Accession#:SK-25-88765