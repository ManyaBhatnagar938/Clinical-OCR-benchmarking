<!-- image -->

| MichaelB.Torres  DOB:11/03/1958  Acct#:44712-B  PRECISION  Age:67  Physician:Dr.James R.  DIAGNOSTIC  LAB  Sex:M  Allen, MD  03/15/202606:30  03/15/202607:20  03/15/202609:55  NMRLipoProfile   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## NMRLipoProfile

| ## Test  Result  Previous  Date  Units  RefInterval  Result  LDLParticleNumber  1820H  1950H  03/01/2026  nmoUL  &lt;1000  LDL-P  1820H  1950H  03/01/2026  nmoU/L  &lt;1000  Lipids  LDL-C(NIHClac)  138H  148H  03/01/2026  mg/dL  &lt;100  HDL-C  38L  36L  03/01/2026  mg/dL  &gt;=40  Triglycerides  210H  198H  03/01/2026  mg/dL  &lt;150  Cholesterol,Total  248H  260H  03/01/2026  mg/dL  &lt;200  LDLandHDLParticles  HDL-P(Total)  26.0L  25.1L  03/01/2026  nmoUL  &gt;=30.5  SmalLLDL-P  820H  880H  03/01/2026  nmoUL  &lt;527  LDL Size  19.8L  19.5L  03/01/2026  nm  &gt;=20.5   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

## Comment

Markedlyelevated LDL-Pwithpredominanceofsmalldense particles.Stronglyrecommend intensificationof statintherapy andlifestyleintervention.