<!-- image -->

DateofVisit:06/21/2025

AttendingProvider:Kth

WtmgFdeoe

Location: Wemn &amp;Laetk

Maoseiatee

Visit ID: N-QSR-2025-442

HOSPITAL

Date ofBirth:09/lo//992

Age:32

Sex:

Femaer

Address:678

m

eadewkreer

L18901

## ChiefComplaints:

## Medical HistorySnapshot:

- Reutine28weel menataeuiait

Qbstetric aistery rauidaI,Daa atmatedDneDote:0912712025. 0. Paatmedicaealiatery Medicatena:Drenataeuitamin, tabeetbymeuthdaiey. Mlrgiea

- Reuiew f eak reueta

- miedeewebaer

## VisitSummary:

wleela gatctien eaentafer he tofeelinyfetae daiey keeediny,erlentxge penid.aLearhen eaotweelwaa ermueJeda ntheeffice ndan duteo,ndpetaeheaitteneo weetaferher vertpelleuonp.

## Exams:

Vtalo,Fitae Bt Jenen,Fndae Leykt

## Findings:

Votaeo:DDn811ammaly,Weight5sebo. Fetae aLartJeneo  rmuix Derrler

fundaeaLeiyhit:28cm

VineDpitelNeyutuePerereete

rtremitesedemn.

Patient:EmilyJohnsonMRN:555-44-3322

<!-- image -->