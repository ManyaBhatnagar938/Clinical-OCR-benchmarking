<!-- image -->

DateofVisit:06/21/2025

TimeofVisit:10:30AM

AttendingPhysician:Dr.EmilyCarter,MD

Facility:GeneralHealthClinic

Location:123HealthSt,Anytown,USA12345

Date of Birth:05/15/979

Age:

Gender:Fe

Contact:(sss) s-1567

Address:1HA

## Chief Complaints:

## Medical HistorySnapshot:

- Grre thront prteyaet thrularr

Horentenrian:Daprdzot8.vll-ontreiadvith

- Pursturt lry eugk

Vrinpmieyeniey.

- U-ndβa.upt100.50F Vir

Granne Aelurgiy:Morazrdvite nun-the-unter

ntikiytaninytrdad.

- 02 fumtinnt lry uh.e- mrord vitk arupper met tranee.Exn tiatuoy tine murdy bilaterallyBardtaalinieal prutatirn.the Arpid try tytrar rupnaelnl are banery mnirntaryufution.eialy ine imiin. Re atiant vay aduipl trgt.inerarePeuid iatabe.ad uge rwen-the-suater aelicationy fn ttonntue mlinp. Gheway ln ugtoutel tplvu p Rur rttnr trr n lnt iaprwe vitkin thnct7-10larr

## Exams:

Crtitutianne

HaeErrErINorYRntHEENT)

Rorinntory

Brdivarular

ndreaonuteegbt.Yootonie

## Findings:

thenntouyviten aenbnany ane Lan. rilen udatr.Nue urmppeuvita aielaaturinn e Rsrintny:Cnr are lan t arultatinn bieatrally. Nrvbuge. mlur n nkemki.Rsiratny

Aent iy ran- eabrnel.

Cnlirrayeulan Rsular nate al nkatkn. gr ad Ga ane anlilev. No nunmuty. ruby. alltr.