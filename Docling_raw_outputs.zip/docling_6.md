<!-- image -->

## GrandviewMedical Center

123HealthwayDrive Springfield,IL62704 (217)555-1212

PatientName:JohnathanSmith

MRN:8675309

MRN:8675309

Accession:A54892-24

DOB:07/14/1958

Date:06/22/2025

Gender:Male

Age:67

Thepatientisa 67-year-oldmalewitha long-standinghistoryofessential hypertension,diagnosed approximately15years ago.Heisalsobeingmanaged forhyperlipidemia.Thepatientreportsintermittentcompliancewith his antihypertensivemedications.He deniesanyhistoryoftobacco usebutreports occasional social alcohol consumption.Thereis afamilyhistoryofcardiovascular disease;hisfatherhad amyocardialinfarction atage60.

## PROCEDURES:

Electrocardiogram(EcG):Revealed normal sinus rhythm with no acute ST- segmentelevationordepression.

Lipid Panel:Results pending.

BasicMetabolicPanel(BMP):Within normal limits.

Physical Examination:Blood pressurewaselevated at168/94mmHginthe right

arm.

## IMPRESSION:

Uncontrolledessential hypertension,likelyexacerbated bymedicationnoncompliance.

Hyperlipidemia.

Familyhistoryofprematurecardiovasculardisease.

PatientName:Johnathan Smith MRN:8675309 Age:67

Date:06/23/2025Time:08:54