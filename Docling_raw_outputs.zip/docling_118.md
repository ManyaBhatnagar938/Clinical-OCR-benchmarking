<!-- image -->

## HOSPITAL

## Coastal Heart Institute

85WaterfrontDrive Charleston,SC29401 (843)555-2300

Patient Name: RLlt

MRN:470102

MRN:474102

Accession: 725-451

DOB: 09/30/174

Date: 06/23/2025

Gender:

PROCEDURES:

-Lat &amp;rt:Pifemt mTto utity

Han n

IMPRESSION: Aoating lls 2+hoy Httmtefuitevlativ

PlpttiytitltinntSthngrntatialuttatirtrtilly

Patient Name:Robert Davis MRN:4478102Age:50

Date:06/23/2025Time:09:10