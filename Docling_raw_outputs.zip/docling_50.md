<!-- image -->

## Oakwood Community Clinic

450NorthMainStreet Madison,WI53703 (608)555-0102

Patient Name:Isabella Garcia

MRN:9884021

MRN:9884021

Accession:B11269-25

DOB:11/05/1998

Date:06/20/2025

Gender:Female

Age: 26

Thepatient is a 26-year-old femalewith a historyof persistent asthma since childhood.She reports seasonal exacerbations, typically in the spring and fall. Currentmedicationsincludea dailyinhaled corticosteroid and analbuterol inhalerforrescueuse,whichshereportsusing3-4 timesperweekrecently.She has a known allergy to dust mites and pollen. No history of smoking.

## PROCEDURES:

obstructivepattern,consistentwithasthma.FEV1increasedby15%after albuteroladministration.

Allergy Skin Testing:Positive reaction to treepollen and dust mites. Chest X-ray (PA and Lateral):Lungs are clear.No acute infiltrate oredema.

## IMPRESSION:

Moderate persistentasthma,sub-optimallycontrolled basedonrecentincrease inrescue inhaler use.

Allergic rhinitis.

Patient Name:Johnathan Smith MRN:8675309 Age:67

Date:06/23/2025Time:08:56