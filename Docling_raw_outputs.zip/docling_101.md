Patient: leanor Vance

MRN:334561

DOB:09/01/1945

## ChiefComplaint

Eualuation afterafallat home thuymorning. Complan of lefthup pan.

## CareTeam

Attendng PhgrucianDrSamuel Peterson. MD

Pager:(512)555-3422

## Pharmacies

Walgreny Mal Order Phone: (800) 555-1212

## Vitalsign

7:98.6F

HR:82 bpw

BP:150/85 mmg

RR:16 breathg/min

02 Sat: 97% onv roon aur

## Allergies

SufadrugSulfamethoaole)-Araphglary

## Medications

- Amlodipne5mg darly

- Alendrenate 70 ng ueckly

- brpmm4)9NI00h/6v009Cmmmn.mmm

## Vaccines

- Hhgh-Dose Inffuenga - 10/02/2024

- Shungrix (2 does) - Complted 05/18/2023

- Pneumorax23 - 09/10/2020

## Problems

- Bbeodone

- Hgpertengon

- stecarthrty

- gaut Instablity

## FamilyHistory

Mother:Dudatage88fron compluationy of ahep bracture. Syter:Hstory oostoporot.

## Social History

Tobaccoi Qut 40y

yeary ago.

Alcohol: Rare.

Lung Sitration Wedowued.lue alone mn av singlestorg houge. Vser a cane for ambulation.