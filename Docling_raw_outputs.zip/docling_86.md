<!-- image -->

## GastroenterologyAssociatesofNorth America

123HealthDriveSpringfield,IL62704

Phone:(217)555-1212

Fax:(217)555-1213

(a)Normal Colon

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Impressions:

Vetrelen,hwtheyemtethertoupsoel

，好

Activity: taoed ? th

Diet:

Follow-up: LA- Cagecentaet

This document contains confidential patient information protected under applicableprivacy laws, includingthe Health InsurancePortabilityand AccountabilityAct(HiPAA).