<!-- image -->

April8,2026

| SECTIONA:MedicalHistory  Yes  No  Breast CancerStage II ER+(ICD-10:C50.912)  X  Osteoporosis(ICD-10:M81.0)  X  Hypertension(ICD-10:110)  X  Hypothyroidism(ICD-10:E03.9)  X  Insomnia (ICD-10:G47.00)  X   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

| SECTION B:Current Medication  Yes  No  Tamoxifen20mg—once daily(AM)  X  Letrozole 2.5 mg——once daily  X  Alendronate 70 mg—onceweekly  X  Lisinopril 10 mg—once daily  X  Levothyroxine 88 mcg—once daily (fasting)  X  CalciumCitrate500mg+Vit D-twicedaily  ×  Zoledronicacid4mgIV-every12weeks  X   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|

<!-- image -->

elen Morrison

Helen Morrison

Patient signature

Printname

<!-- image -->

Patient:Helen F.Morrison

DOB:05/30/1955

MRN:031-928-74