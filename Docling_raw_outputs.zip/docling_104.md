Patient: Dert Ckn

MRN:778899

DOB:03//2//978

## ChiefComplaint

Sllyonrettrrre.tenbrclpbelrkethttartebpprorumatiy tarhoarr

yRetar pun m.

CareTeam

Attinlny PyruunbrirrkJenlinr.mA

Pygrv:(619) 558012

Pharmacies

CoAerPherrvyvsFletehrPhgyJeTmertCt unPhonen(e) ssn

## Vitalsign

HeR: bpom

BP: ns mng

RRnkrtermn

DSitaovrur

Allergies

Cprpbxur.Trbrtar

nelirtiorr

- uometrytinytillit.erubeforrgruner

## Vaccines

- Tnfbungy.m120124

- Teap -081123

- CettDnBenbntBotay.mses

## Problems

- irerrHalache

- Retyfmgrrurrntekare

- Bypertinror

## FamilyHistory

mthrutymyraner.

matare tantbuefroyvuptarlurkaberayrmtyes

## Social History

Flca Aenuer

Alakabrglarrer ofrrrperruk.

CrepitionftaerEgururyportrbgktirrtrreruenty