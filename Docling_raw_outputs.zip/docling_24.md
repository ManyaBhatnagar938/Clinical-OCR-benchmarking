<!-- image -->

## Tri-CountyDigestiveHealth Specialists

789WellnessBoulevard,Suite200 Oakmont,PA15139

Phone:(412)555-3456

Fax:(412)555-3457

ProcedureDate:06/21/2025

undersedationto examineyourlargeintestine.The anesthetic medications administered during your procedure will continue to significantlyimpairyourreflexes,cognitivefunction,and judgmentforafull24hours.Foryourhealthandsafety,itis absolutelyessentialthatyouandyourdesignatedcaregiverread andstrictlyadheretothefollowingdetaileddischarge instructions.

## CRITICALSAFETYPRECAUTIONS(NeXt24Hours)

Your safety is our primary concern.The sedative effects are longlasting and can create a riskfor accidents and injury.

<!-- image -->

Drivingand Transportation:You are legally and medically prohibitedfromdrivinganytypeofvehicle,includingacar, motorcycle,orevenaridinglawnmower,for24hours.Youmust bedrivenhomebytheresponsibleadultyouhavedesignated. Undernocircumstancesmayyoutake a taxi,bus,orrideshare service alone.

Activity Restrictions:Do notengage in any strenuous or potentiallyhazardous activities.Thisincludes exercising,going tothegym,jogging,or liftingheavyobjects（anythingover10 pounds).Avoidactivitiesthatrequirebalanceandcoordination, suchascookingoverahotstove.

DecisionMaking:Donotmake anyimportantorlegallybinding decisions.This includessigningcontractsordocuments,making significant financial transactions,or engagingin complex workrelated discussions.Yourjudgment is considered impaired.

## Impressions:

Normal Colonoscopy:A complete examination tothececumwasperformed.The colonicmucosa was pinkandhealthy,withanormalvascularpatternthroughoutthevisualizedsegmentsof thelarge intestine.Therewasnoevidenceofpolyps,tumors,diverticulosis,inflammation,orothermucosal abnormalities.

procedure.Therefore,youwill notbereceivingaseparatepathologyreport.

Follow-UpPlan:Basedontoday'snormalfindings,yourriskprofileindicates thatyournextroutine screeningcolonoscopyshould bescheduled in10years.Wewill send aremindertoyou andyour primarycarephysician.

This document containsconfidential patientinformation protected under applicable privacy laws, includingtheHealth InsurancePortability and AccountabilityAct(HiPAA).

## (a) Normal Colon

(b) Colon

<!-- image -->