MidwestOrthopedics&amp;SportsMedicineCenter950N.ClarkStreet,Chicago,IL60610

Patient:ChloeDavisMRN:556677DOB:08/25/2004

## ChiefComplaint

Leftkneepainand instability afteran injuryduringa soccergame today.

## Care Team

Attending Physician:Dr.MarcusThorne,MD Pager:(312)555-2355

## Pharmacies

CVSPharmacy1120S.CanalStreet,Chicago,IL 60607Phone:(312)555-1199

## Vital sign

T:98.6F

HR: 78 bpm

BP:124/76mmHg

RR:16breaths/min

02Sat:100%onroomair

## Allergies

NoKnownDrugAllergies

## Medications

- Naproxen220mg,asneededforpain

## Vaccines

- Allimmunizationsuptodate.

## Problems

- AcuteLeftKneePain
- LeftKneeEffusion

## Family History

Non-contributory.Parents are ingood health.

Tobacco:Denies

Alcohol:Denies

Occupation:College student,plays on the university soccerteam.

## Social History