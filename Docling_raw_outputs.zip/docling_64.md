PatientName:Doe,JanePatientID:JG05141985D0B:05/14/1985DateofService:2024-05-18

Accession#:IMG9876543OrderingPhysician:Dr.EmilyCarterReportDate:2024-05-20

Springfield General Hospital ImagingDepartment123Health Way, Springfield, IL, 62704

<!-- image -->

Visit Date:2024-05-18Reason for Exam:Persistent headaches,right-sided,worseningover2 Weeks.ExamID:IMG9876543

MRIBrainwithoutcontrast

Imaging

<!-- image -->

tinding B vertrclar spstam and oli an namalin gie and conliguratin tun thepatiuntg ag.N widene  acnte intracmnial bomohagp, mas lit,.e min shatngut mattrdetaton s pguved. Nacat tmtral ioparnt idrtpud n dlysim wuihtd imaging.M hmgdaiayapatadp thtandpaaainyaumak. Vecranicunvical punrctin y urrmarkebl.

Impression:Normal MRlstudyof thebrain.Noacuteintracranial abnormalityidentified.

Shdold aynintorurt

DateReported:2025-05-20

Aow-y cngoltaton with Dr.Catr n 20L5:00:01 at 1000 AMt diycays nsolh and buther maragmunt g hadachy.

Interpreting Radiologist:Dr.Alan B.Smith,MD,DABR Transcriptionist ID:KLP

CONFIDENTIALITYNOTICE:Thisreportcontains confidential patient information protected byfederal andstatelaw.Itisintended onlyforthe useofthe individualorentitytowhom itisaddressed.lf youare nottheintendedrecipient,youareherebynotifiedthatanydisclosure,copying,distribution,oraction taken in reliance on the contentsof these documents isstrictlyprohibited.If youhavereceived this reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneral HospitalImagingDepartment|123HealthWay,Springfield,IL,62704

Phone:(217) 555-1212

Fax:(217)555-1213

PatientName:Doe,JanePatient

ID:JG05141985

DOB:05/14/1985

Sex:Female