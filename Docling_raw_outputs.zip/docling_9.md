Patient:MariaGarciaDOB:09/15/1992MRN:654321

Accession#:B987654-25

<!-- image -->

## MRI Report-RightKnee

Procedure:MRl oftherightkneewithoutcontrast. Clinical Indication:Mechanical knee pain and locking sensation following a sports injury.

Menisci:Thereis a complex,displaced tear of theposteriorhorn of the medial meniscus with a large flipped fragmentin theintercondylarnotch.Thelateral meniscusis intact.

Ligaments:The anterior cruciate ligament(ACL) shows high-grade sprainwith fiber discontinuity, consistentwith afull-thicknesstear.Theposteriorcruciateligament(PCL),medial collateral ligament (MCL),and lateral collateral ligament(LCL) complexareintact.

ArticularCartilageandBone:Thereismild chondromalaciaofthepatellofemoral compartment.A fracture,butthereisbonemarrowedemainthelateralfemoral condyleandposteriortibialplateau, suggestiveofapivot-shiftcontusionpattern.

Impression:Full-thicknesstearofthe anteriorcruciateligament(ACL).Complex,displacedtearof the medial meniscuswitha large fragment.Moderate jointeffusion.Bone contusions consistentwith a pivot-shift injury.

## Scheduled appointments:

UrgentreferraltoOrthopedicSurgeryfor consultation.AppointmentscheduledwithDr.KatherineLee on06/23/2025at2:00PM.

DateofDictation:06/20/2025Technician:MichaelBrown,ARRT(MR)

CONFIDENTIALITYNOTICE:Thisreportcontainsconfidentialpatientinformationprotectedbyfederal andstatelaw.Itisintended onlyfortheuseoftheindividualorentitytowhom itis addressed.lfyou are not theintendedrecipient,you areherebynotified thatanydisclosure,copying,distribution,oraction takeninrelianceonthecontentsofthesedocumentsisstrictlyprohibited.lfyouhavereceivedthis reportinerror,pleasenotifythesenderimmediatelybytelephoneat(217)555-1212anddestroythis document.

SpringfieldGeneralHospitalImagingDepartment|123HealthWay,Springfield,IL,62704

OrthoSport ImagingCenter 789WellnessBoulevard Metropolis,USA54321

Precision Radiology Group

Phone:(555)876-5432

Fax:(555)876-5433

Patient:Maria Garcia

DOB:09/15/1992

MRN:654321

Gender:FemaleReferring

Physician:Dr.David Chen

## Visit #:123-456Date ofVisit:06/19/2025