<!-- image -->

<!-- image -->

To:Dv.Tmntk pz

Facility:Tergealtkdraulatr.AAT

Fax(t)

Phone: () -m)

mAddtppeit

From:e.FmFuk.PtT

FacilityBzuuwTrmmtyferlte

Fax: (ut) -

Phone (m) .

Date:,

Hupw.2026

Time:  t/

Notes:

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

lthtk TheinformationcontainedinthisfacsimilemessageisAegallyarvilegedand confdentialinformationintendedonlyfortheuseof theindividualorentitynamed above.lf thereaderofthismessageisnottheintendetrectptent,youarebereby prohibited.Ifyouhavereceivedthistelecopyinerror,pleaseimmediatelynotifyus by tetephoneandreturntheoriginal messagetousattheaddressabovevia theU.s. Postal Serviee.Thankyou.

<!-- image -->

## FAX